# 地震多属性智能分析

## 运行

建议使用 64 位 Python 3.12 或 3.13。CUDA 用户应选择与显卡驱动匹配的 PyTorch。

1. 在本地 Python 环境中安装本文件夹内 `requirements.txt`。可在命令提示符中执行：

   ```bat
   "你的环境路径\Scripts\python.exe" -m pip install -r requirements.txt
   ```

   例如：`D:\AI_Lab\.venv\Scripts\python.exe -m pip install -r requirements.txt`。
2. 双击 `MAMCL_GUI.exe`，在“本地 Python 环境”中选择同一环境里的 `python.exe`。
3. 选择属性、层位和输出位置，先点“检查输入”，检查通过后再运行。

压缩包只含界面程序和 MAMCL 代码，不含 PyTorch、CUDA 或其他 Python 包。单层位支持 ZGY 或 SEG-Y 属性体；层间模式目前只支持 ZGY。层位文件使用 DAT；井位和井相示例模板在 `templates` 文件夹中，输出目录应可写。
