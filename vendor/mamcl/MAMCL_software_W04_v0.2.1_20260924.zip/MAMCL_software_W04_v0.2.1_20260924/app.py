"""Small offline GUI for the standalone MAMCL runner.

The GUI only writes a JSON snapshot and starts runner.py. It does not copy
seismic volumes or horizon files and it keeps the original baseline packages
untouched.
"""
from __future__ import annotations

import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText


# PyInstaller keeps bundled resources under ``sys._MEIPASS``. User data is
# kept beside the executable so configs and results remain writable.
RESOURCE_ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
ROOT = Path(os.environ.get(
    "MAMCL_APP_ROOT",
    Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent,
))
CONFIG_DIR = ROOT / "configs"
RESULTS_DIR = ROOT / "runs"
GUI_SETTINGS_PATH = ROOT / "gui_settings.json"


def _default_python_executable():
    configured = os.environ.get("MAMCL_PYTHON", "").strip()
    if configured:
        return configured
    try:
        settings = json.loads(GUI_SETTINGS_PATH.read_text(encoding="utf-8"))
        saved = str(settings.get("python_executable", "")).strip()
        if saved:
            return saved
    except (OSError, ValueError, AttributeError):
        pass
    if not getattr(sys, "frozen", False):
        return sys.executable
    return shutil.which("python.exe") or shutil.which("python") or ""


class MAMCLApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("地震多属性智能分析")
        self.geometry("1240x820")
        self.minsize(1050, 700)
        self.option_add("*Font", ("Segoe UI", 10))
        # 高分屏修正：ttk 主题控件（按钮/下拉/勾选框）走 TkDefaultFont 等命名
        # 字体，不吃 *Font——统一提到 10pt，与标签同号；可用 MAMCL_FONT_SIZE 覆盖。
        try:
            from tkinter import font as _tkfont
            _size = int(os.environ.get("MAMCL_FONT_SIZE", "10"))
            for _fname in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont",
                           "TkCaptionFont", "TkSmallCaptionFont", "TkIconFont", "TkTooltipFont"):
                _tkfont.nametofont(_fname).configure(size=_size)
        except (tk.TclError, ValueError):
            pass
        style = ttk.Style(self)
        try:
            style.configure("Title.TLabel", font=("Segoe UI", 17, "bold"))
            style.configure("Subtitle.TLabel", foreground="#64748b")
            style.configure("Status.TLabel", font=("Segoe UI", 10, "bold"))
            style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"))
        except tk.TclError:
            pass
        self.process = None
        self.log_queue = queue.Queue()
        self._log_lines = []
        self._path_entries = {}
        self._advanced_visible = False
        self.status_text = tk.StringVar(value="就绪")
        self.log_filter = tk.StringVar(value="全部")
        self.log_autoscroll = tk.BooleanVar(value=True)
        self.vars = {
            "run_name": tk.StringVar(value="mamcl_run"),
            "mode": tk.StringVar(value="interval"),
            "single_horizon": tk.StringVar(),
            "upper_horizon": tk.StringVar(),
            "lower_horizon": tk.StringVar(),
            "well_csv": tk.StringVar(),
            "python_executable": tk.StringVar(value=_default_python_executable()),
            "well_xlsx": tk.StringVar(),
            "well_mode": tk.StringVar(value="关闭"),
            "postprocess_mode": tk.StringVar(value="多数投票"),
            "well_group": tk.StringVar(value="恩平组"),
            "well_segments": tk.StringVar(value="一段"),
            "well_loss_weight": tk.StringVar(value="0.2"),
            "well_sigma_factor": tk.StringVar(value="0.5"),
            "well_min_weight": tk.StringVar(value="0.05"),
            "well_max_neighbors": tk.StringVar(value="3"),
            "well_min_confidence": tk.StringVar(value="0.6"),
            "well_fallback_weight": tk.StringVar(value="0.35"),
            "prob_smoothing_sigma": tk.StringVar(value="1.0"),
            "component_min_size": tk.StringVar(value="0"),
            "result_root": tk.StringVar(value=str(RESULTS_DIR.resolve())),
            "horizon_unit": tk.StringVar(value="ms"),
            "horizon_coords": tk.StringVar(value="world"),
            "plot_coords": tk.StringVar(value="world"),
            "window": tk.StringVar(value="8"),
            "fraction": tk.StringVar(value="0.25"),
            "epochs": tk.StringVar(value="20"),
            "batch": tk.StringVar(value="2048"),
            "feature_batch": tk.StringVar(value="512"),
            "kmeans_cap": tk.StringVar(value="0"),
            "lr": tk.StringVar(value="0.2"),
            "lr_warmup": tk.StringVar(value="10"),
            "lr_t0": tk.StringVar(value="500"),
            "lr_min_factor": tk.StringVar(value="0.25"),
            "noise": tk.StringVar(value="0.1"),
            "train_stride": tk.StringVar(value="4,4"),
            "device": tk.StringVar(value="auto"),
            "clusters": tk.StringVar(value="3,4,5,6,7,8,9"),
            "smooth_kernel": tk.StringVar(value="5"),
            "smooth_iterations": tk.StringVar(value="2"),
            "smooth_votes": tk.StringVar(value="13"),
            "cpu_threads": tk.StringVar(value="4"),
        }
        self._build()
        self.after(100, self._drain_log)

    def _build(self):
        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)
        outer.rowconfigure(1, weight=1)
        outer.columnconfigure(0, weight=1)
        ttk.Label(outer, text="地震多属性智能分析", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(outer, text="属性体 / 层位 / 聚类", style="Subtitle.TLabel").grid(row=0, column=0, sticky="e", pady=(4, 0))

        pane = ttk.Panedwindow(outer, orient="horizontal")
        pane.grid(row=1, column=0, sticky="nsew", pady=(10, 8))
        left = ttk.Frame(pane, padding=(0, 0, 10, 0))
        right = ttk.Frame(pane, padding=(10, 0, 0, 0))
        pane.add(left, weight=4)
        pane.add(right, weight=6)
        left.rowconfigure(0, weight=1)
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)

        canvas = tk.Canvas(left, highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(left, orient="vertical", command=canvas.yview)
        form = ttk.Frame(canvas, padding=(2, 0, 8, 0))
        form_id = canvas.create_window((0, 0), window=form, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        form.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(form_id, width=e.width))
        def scroll_form(event):
            widget = event.widget
            while widget is not None:
                if widget is canvas:
                    canvas.yview_scroll(int(-event.delta / 120), "units")
                    return
                widget = getattr(widget, "master", None)
        canvas.bind_all("<MouseWheel>", scroll_form)
        self.form_canvas = canvas

        base = ttk.LabelFrame(form, text="输入", padding=10)
        base.pack(fill="x", pady=(0, 8))
        base.columnconfigure(1, weight=1)
        ttk.Label(base, text="运行名称").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=3)
        ttk.Entry(base, textvariable=self.vars["run_name"]).grid(row=0, column=1, sticky="ew", pady=3)
        ttk.Label(base, text="模式").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=3)
        mode = ttk.Combobox(base, textvariable=self.vars["mode"], values=("single", "interval"), state="readonly", width=14)
        mode.grid(row=1, column=1, sticky="w", pady=3)
        mode.bind("<<ComboboxSelected>>", lambda _event: self._update_mode())
        ttk.Label(base, text="属性文件").grid(row=2, column=0, sticky="nw", padx=(0, 8), pady=3)
        self.attribute_text = ScrolledText(base, height=4, width=45, wrap="none")
        self.attribute_text.grid(row=2, column=1, sticky="ew", pady=3)
        ttk.Button(base, text="选择属性…", command=self._choose_attributes).grid(row=2, column=2, sticky="ne", padx=(6, 0), pady=3)
        self.single_row = self._path_row(base, 3, "单层位", "single_horizon", self._choose_single)
        self.upper_row = self._path_row(base, 4, "上层位", "upper_horizon", self._choose_upper)
        self.lower_row = self._path_row(base, 5, "下层位", "lower_horizon", self._choose_lower)
        self.well_row = self._path_row(base, 6, "井位 CSV（可选）", "well_csv", self._choose_well)
        self.well_xlsx_row = self._path_row(base, 7, "井相 Excel（约束用）", "well_xlsx", self._choose_well_xlsx)
        ttk.Label(base, text="井约束").grid(row=8, column=0, sticky="w", padx=(0, 8), pady=3)
        well_mode = ttk.Combobox(
            base, textvariable=self.vars["well_mode"],
            values=("关闭", "邻域井约束（硬标签合并）", "概率衰减（软标签）"),
            state="readonly", width=28,
        )
        well_mode.grid(row=8, column=1, sticky="w", pady=3)
        ttk.Label(base, text="空间后处理").grid(row=9, column=0, sticky="w", padx=(0, 8), pady=3)
        postprocess_mode = ttk.Combobox(
            base, textvariable=self.vars["postprocess_mode"],
            values=("关闭", "多数投票", "软概率平滑"), state="readonly", width=28,
        )
        postprocess_mode.grid(row=9, column=1, sticky="w", pady=3)
        ttk.Label(
            base,
            text="CSV必需列：井号、X坐标、Y坐标；Excel首表必需列：井号、组、段、沉积亚相（或沉积相）。",
            foreground="#64748b", wraplength=520, justify="left",
        ).grid(row=10, column=0, columnspan=3, sticky="w", pady=(5, 1))
        ttk.Button(base, text="查看标准模板", command=self._open_well_templates).grid(
            row=11, column=1, sticky="w", pady=(3, 0)
        )
        ttk.Label(base, text="本地 Python 环境").grid(row=12, column=0, sticky="w", padx=(0, 8), pady=3)
        ttk.Entry(base, textvariable=self.vars["python_executable"]).grid(row=12, column=1, sticky="ew", pady=3)
        ttk.Button(base, text="选择 python.exe…", command=self._choose_python).grid(
            row=12, column=2, sticky="e", padx=(6, 0), pady=3
        )

        common = ttk.LabelFrame(form, text="常用参数", padding=10)
        common.pack(fill="x", pady=(0, 8))
        for c in range(3):
            common.columnconfigure(c, weight=1)
        common_fields = [("窗口", "window"), ("层间比例", "fraction"), ("epochs", "epochs"), ("batch", "batch"), ("学习率", "lr"), ("噪声", "noise"), ("训练步长", "train_stride"), ("device", "device"), ("聚类 K", "clusters"), ("采样单位", "horizon_unit"), ("层位坐标", "horizon_coords")]
        self._make_field_grid(common, common_fields, 3)

        toggle = ttk.Button(form, text="高级参数  ▸", command=self._toggle_advanced)
        toggle.pack(fill="x", pady=(0, 4))
        self.advanced_toggle = toggle
        self.advanced_frame = ttk.LabelFrame(form, text="高级参数", padding=10)
        advanced_fields = [("特征批", "feature_batch"), ("K-Means上限", "kmeans_cap"), ("预热轮数", "lr_warmup"), ("余弦周期", "lr_t0"), ("最低LR比例", "lr_min_factor"), ("平滑核", "smooth_kernel"), ("平滑次数", "smooth_iterations"), ("平滑最小票数", "smooth_votes"), ("小斑块最小面积", "component_min_size"), ("概率平滑σ", "prob_smoothing_sigma"), ("CPU线程", "cpu_threads")]
        self._make_field_grid(self.advanced_frame, advanced_fields, 3)
        # Parameters are edited in the dedicated multi-page settings window.
        # Keep the widgets available for compatibility with existing bindings,
        # but leave the main input page focused on data selection.
        common.pack_forget()
        toggle.pack_forget()

        actions = ttk.LabelFrame(form, text="运行", padding=10)
        actions.pack(fill="x", pady=(4, 8))
        self.start_button = ttk.Button(actions, text="▶  开始运行", command=self._start, style="Accent.TButton")
        self.start_button.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(actions, text="检查输入", command=self._check).grid(row=0, column=1, sticky="ew", padx=4)
        self.stop_button = ttk.Button(actions, text="■  停止", command=self._stop, state="disabled")
        self.stop_button.grid(row=0, column=2, sticky="ew", padx=4)
        ttk.Button(actions, text="保存配置", command=self._save_config_dialog).grid(row=0, column=3, sticky="ew", padx=4)
        ttk.Button(actions, text="加载配置", command=self._load_config_dialog).grid(row=0, column=4, sticky="ew", padx=(4, 0))
        ttk.Button(actions, text="参数设置…", command=self._open_settings).grid(row=0, column=5, sticky="ew", padx=(4, 0))
        for c in range(6):
            actions.columnconfigure(c, weight=1)
        ttk.Button(actions, text="打开结果目录", command=self._open_results).grid(row=1, column=0, columnspan=6, sticky="ew", pady=(8, 0))

        software_info = ttk.LabelFrame(left, text="软件信息", padding=(8, 5))
        software_info.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(6, 0))
        software_info.columnconfigure(0, weight=1)
        software_info.rowconfigure(0, weight=1)
        info_center = ttk.Frame(software_info)
        info_center.grid(row=0, column=0)
        ttk.Label(info_center, text="地震多属性智能分析", font=("Segoe UI", 11, "bold")).pack()
        ttk.Label(info_center, text="v0.2.1 W04  ·  ZGY / SEG-Y 属性体  ·  DAT 层位", foreground="#64748b").pack(pady=(5, 0))

        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)
        status_bar = ttk.Frame(right)
        status_bar.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        status_bar.columnconfigure(1, weight=1)
        ttk.Label(status_bar, text="状态：").grid(row=0, column=0, sticky="w")
        ttk.Label(status_bar, textvariable=self.status_text, style="Status.TLabel").grid(row=0, column=1, sticky="w")
        self.progress = ttk.Progressbar(status_bar, mode="indeterminate", length=260)
        self.progress.grid(row=0, column=2, sticky="e")
        log_frame = ttk.LabelFrame(right, text="日志", padding=8)
        log_frame.grid(row=1, column=0, sticky="nsew")
        log_frame.rowconfigure(1, weight=1)
        log_frame.columnconfigure(0, weight=1)
        toolbar = ttk.Frame(log_frame)
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(toolbar, text="级别").pack(side="left")
        level = ttk.Combobox(toolbar, textvariable=self.log_filter, values=("全部", "INFO", "WARNING", "ERROR"), state="readonly", width=10)
        level.pack(side="left", padx=(4, 12))
        level.bind("<<ComboboxSelected>>", lambda _e: self._refresh_log())
        ttk.Checkbutton(toolbar, text="自动滚动", variable=self.log_autoscroll).pack(side="left")
        ttk.Button(toolbar, text="清空", command=self._clear_log).pack(side="right")
        self.log = ScrolledText(log_frame, state="normal", background="#18212f", foreground="#dbe4ee", insertbackground="#ffffff", wrap="none")
        self.log.grid(row=1, column=0, sticky="nsew")
        self.log.tag_configure("error", foreground="#ff8b8b")
        self.log.tag_configure("warning", foreground="#f7d774")
        self.log.tag_configure("success", foreground="#8ee6a8")
        self.log.tag_configure("info", foreground="#dbe4ee")
        output_frame = ttk.LabelFrame(right, text="结果目录", padding=8)
        output_frame.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        output_frame.columnconfigure(0, weight=1)
        ttk.Entry(output_frame, textvariable=self.vars["result_root"]).grid(row=0, column=0, sticky="ew")
        ttk.Button(output_frame, text="设置…", command=self._choose_result_root).grid(row=0, column=1, sticky="e", padx=(6, 0))
        ttk.Button(output_frame, text="打开", command=self._open_results).grid(row=0, column=2, sticky="e", padx=(6, 0))
        self._update_mode()

    def _path_row(self, parent, row, label, key, command):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=3)
        entry = ttk.Entry(parent, textvariable=self.vars[key])
        entry.grid(row=row, column=1, sticky="ew", pady=3)
        button = ttk.Button(parent, text="选择…", command=command)
        button.grid(row=row, column=2, sticky="e", padx=(6, 0), pady=3)
        self._path_entries[key] = (entry, button)
        parent.columnconfigure(1, weight=1)
        return row

    def _make_field_grid(self, parent, fields, columns):
        for index, (label, key) in enumerate(fields):
            row, col = divmod(index, columns)
            ttk.Label(parent, text=label).grid(row=row * 2, column=col, sticky="w", padx=4, pady=(0, 2))
            if key == "horizon_unit":
                widget = ttk.Combobox(parent, textvariable=self.vars[key], values=("samples", "ms", "s"), state="readonly")
            elif key == "horizon_coords":
                widget = ttk.Combobox(parent, textvariable=self.vars[key], values=("world", "inline_crossline"), state="readonly")
            elif key == "plot_coords":
                widget = ttk.Combobox(parent, textvariable=self.vars[key], values=("world", "inline_crossline", "index"), state="readonly")
            elif key == "device":
                widget = ttk.Combobox(parent, textvariable=self.vars[key], values=("auto", "cpu", "cuda"), state="readonly")
            elif key == "well_mode":
                widget = ttk.Combobox(parent, textvariable=self.vars[key], values=("关闭", "邻域井约束（硬标签合并）", "概率衰减（软标签）"), state="readonly")
            elif key == "postprocess_mode":
                widget = ttk.Combobox(parent, textvariable=self.vars[key], values=("关闭", "多数投票", "软概率平滑"), state="readonly")
            else:
                widget = ttk.Entry(parent, textvariable=self.vars[key])
            widget.grid(row=row * 2 + 1, column=col, sticky="ew", padx=4, pady=(0, 7))
            parent.columnconfigure(col, weight=1)

    def _toggle_advanced(self):
        if self._advanced_visible:
            self.advanced_frame.pack_forget()
            self.advanced_toggle.configure(text="高级参数  ▸")
        else:
            self.advanced_frame.pack(fill="x", pady=(0, 8), before=self.advanced_toggle)
            self.advanced_toggle.configure(text="高级参数  ▾")
        self._advanced_visible = not self._advanced_visible

    def _update_mode(self):
        interval = self.vars["mode"].get() == "interval"
        for key in ("upper_horizon", "lower_horizon"):
            self._path_entries[key][0].configure(state="normal" if interval else "disabled")
            self._path_entries[key][1].configure(state="normal" if interval else "disabled")
        self._path_entries["single_horizon"][0].configure(state="disabled" if interval else "normal")
        self._path_entries["single_horizon"][1].configure(state="disabled" if interval else "normal")

    def _choose_attributes(self):
        paths = filedialog.askopenfilenames(
            title="选择属性体",
            filetypes=[("地震属性", "*.zgy *.sgy *.segy"), ("全部文件", "*.*")],
        )
        if paths:
            self.attribute_text.delete("1.0", "end")
            self.attribute_text.insert("1.0", "\n".join(paths))

    def _choose_path(self, key, title):
        path = filedialog.askopenfilename(title=title, filetypes=[("层位文件（DAT）", "*.dat"), ("全部文件", "*.*")])
        if path:
            self.vars[key].set(path)

    def _choose_single(self): self._choose_path("single_horizon", "选择单层位文件")
    def _choose_upper(self): self._choose_path("upper_horizon", "选择上层位文件")
    def _choose_lower(self): self._choose_path("lower_horizon", "选择下层位文件")

    def _choose_well(self):
        path = filedialog.askopenfilename(
            title="选择井位 CSV（可选）",
            filetypes=[("CSV", "*.csv"), ("全部文件", "*.*")],
        )
        if path:
            self.vars["well_csv"].set(path)

    def _choose_well_xlsx(self):
        path = filedialog.askopenfilename(
            title="选择井相 Excel（.xlsx）",
            filetypes=[("Excel 工作簿", "*.xlsx"), ("全部文件", "*.*")],
        )
        if path:
            self.vars["well_xlsx"].set(path)

    def _open_well_templates(self):
        template_dir = RESOURCE_ROOT / "templates"
        if not template_dir.is_dir():
            template_dir = ROOT / "templates"
        if not template_dir.is_dir():
            messagebox.showerror("模板不存在", f"未找到输入模板目录：\n{template_dir}")
            return
        try:
            os.startfile(str(template_dir))
        except OSError as error:
            messagebox.showerror("无法打开模板目录", f"{template_dir}\n\n{error}")

    def _choose_result_root(self):
        current = self.vars["result_root"].get().strip() or str(RESULTS_DIR)
        path = filedialog.askdirectory(title="选择结果输出目录", initialdir=current)
        if path:
            self.vars["result_root"].set(str(Path(path).expanduser().resolve()))

    def _choose_python(self):
        current = self.vars["python_executable"].get().strip()
        initialdir = str(Path(current).expanduser().parent) if current else str(Path.home())
        path = filedialog.askopenfilename(
            title="选择虚拟环境中的 python.exe",
            initialdir=initialdir,
            filetypes=[("Python解释器", "python.exe"), ("可执行文件", "*.exe")],
        )
        if path:
            self.vars["python_executable"].set(str(Path(path).resolve()))

    def _selected_python(self):
        raw_path = self.vars["python_executable"].get().strip().strip('"')
        if not raw_path:
            raise ValueError("请先选择本地 Python 环境中的 python.exe。")
        python_path = Path(raw_path).expanduser()
        if not python_path.is_file():
            raise ValueError(f"找不到所选 Python 解释器：\n{python_path}")
        if python_path.name.lower() != "python.exe":
            raise ValueError("请选择虚拟环境 Scripts 文件夹中的 python.exe。")
        runner_path = ROOT / "runner.py"
        if not runner_path.is_file():
            raise ValueError(f"当前软件目录缺少 runner.py：\n{runner_path}")
        return str(python_path.resolve()), str(runner_path.resolve())

    def _save_python_setting(self, python_path):
        try:
            GUI_SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
            GUI_SETTINGS_PATH.write_text(
                json.dumps({"python_executable": str(python_path)}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as error:
            self._log(f"WARNING: 无法保存 Python 环境选择：{error}")

    def _open_settings(self):
        dialog = tk.Toplevel(self)
        dialog.title("参数设置")
        dialog.geometry("760x640")
        dialog.minsize(660, 520)
        dialog.transient(self)
        snapshot = {key: value.get() for key, value in self.vars.items()}
        body = ttk.Frame(dialog, padding=12)
        body.pack(fill="both", expand=True)
        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=1)
        notebook = ttk.Notebook(body)
        notebook.grid(row=0, column=0, sticky="nsew")

        common_page = ttk.Frame(notebook, padding=14)
        advanced_page = ttk.Frame(notebook, padding=14)
        output_page = ttk.Frame(notebook, padding=14)
        well_page = ttk.Frame(notebook, padding=14)
        notebook.add(common_page, text="常用参数")
        notebook.add(advanced_page, text="高级参数")
        notebook.add(well_page, text="井约束与后处理")
        notebook.add(output_page, text="输出与运行")
        self._make_field_grid(
            common_page,
            [("窗口", "window"), ("层间比例", "fraction"), ("epochs", "epochs"),
             ("batch", "batch"), ("学习率", "lr"), ("噪声", "noise"),
             ("训练步长", "train_stride"), ("device", "device"),
             ("聚类 K", "clusters"), ("采样单位", "horizon_unit"),
             ("层位坐标", "horizon_coords")],
            2,
        )
        self._make_field_grid(
            advanced_page,
            [("特征批", "feature_batch"), ("K-Means上限", "kmeans_cap"),
             ("预热轮数", "lr_warmup"), ("余弦周期", "lr_t0"),
             ("最低LR比例", "lr_min_factor"), ("平滑核", "smooth_kernel"),
             ("平滑次数", "smooth_iterations"), ("平滑最小票数", "smooth_votes"),
             ("绘图坐标", "plot_coords"), ("小斑块最小面积", "component_min_size"), ("概率平滑σ", "prob_smoothing_sigma"),
             ("CPU线程", "cpu_threads")],
            2,
        )
        self._make_field_grid(
            well_page,
            [("井约束模式", "well_mode"), ("井约束损失权重", "well_loss_weight"),
             ("井间衰减尺度", "well_sigma_factor"), ("最小井权重", "well_min_weight"),
             ("参与邻井数", "well_max_neighbors"), ("最低标签置信度", "well_min_confidence"),
             ("CSV备用标签权重", "well_fallback_weight"), ("地层组筛选", "well_group"),
             ("层段筛选（逗号分隔）", "well_segments"), ("空间后处理", "postprocess_mode")],
            2,
        )
        ttk.Label(
            well_page,
            text="井位CSV用于坐标定位；井相Excel用于提供组、段和沉积相标签。两份文件的井号必须一致。",
            foreground="#64748b", wraplength=650, justify="left",
        ).grid(row=10, column=0, columnspan=4, sticky="w", padx=4, pady=(14, 0))
        output_page.columnconfigure(1, weight=1)
        ttk.Label(output_page, text="结果根目录").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=6)
        ttk.Entry(output_page, textvariable=self.vars["result_root"]).grid(row=0, column=1, sticky="ew", pady=6)
        ttk.Button(output_page, text="选择…", command=self._choose_result_root).grid(row=0, column=2, sticky="e", padx=(6, 0), pady=6)
        ttk.Label(output_page, text="实际输出为：结果根目录 / 运行名称").grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 12))
        ttk.Label(output_page, text="配置保存位置").grid(row=2, column=0, sticky="w", padx=(0, 10), pady=6)
        ttk.Label(output_page, text=str(CONFIG_DIR), foreground="#64748b").grid(row=2, column=1, columnspan=2, sticky="w", pady=6)
        ttk.Label(output_page, text="日志和结果写入该目录。", foreground="#64748b").grid(row=3, column=0, columnspan=3, sticky="w", pady=(16, 6))

        footer = ttk.Frame(body)
        footer.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        footer.columnconfigure(0, weight=1)
        ttk.Label(footer, text="修改后点击“应用”；取消会恢复打开窗口前的值。", foreground="#64748b").grid(row=0, column=0, sticky="w")

        def cancel():
            for key, value in snapshot.items():
                self.vars[key].set(value)
            self._update_mode()
            dialog.destroy()

        def apply_and_close():
            self._update_mode()
            dialog.destroy()

        ttk.Button(footer, text="取消", command=cancel).grid(row=0, column=1, padx=(8, 0))
        ttk.Button(footer, text="应用", command=apply_and_close, style="Accent.TButton").grid(row=0, column=2, padx=(8, 0))
        dialog.protocol("WM_DELETE_WINDOW", cancel)
        dialog.grab_set()

    def _parse_ints(self, text, name):
        try:
            values = [int(v.strip()) for v in text.replace("，", ",").split(",") if v.strip()]
        except ValueError as error:
            raise ValueError(f"{name}必须是整数列表") from error
        if not values:
            raise ValueError(f"{name}不能为空")
        return values

    def _config(self):
        paths = [line.strip() for line in self.attribute_text.get("1.0", "end").splitlines() if line.strip()]
        if not paths:
            raise ValueError("至少选择一个属性文件")
        interval = self.vars["mode"].get() == "interval"
        if interval and (not self.vars["upper_horizon"].get() or not self.vars["lower_horizon"].get()):
            raise ValueError("层间模式需要上层位和下层位")
        if not interval and not self.vars["single_horizon"].get():
            raise ValueError("单层位模式需要层位文件")
        unsupported = []
        missing = []
        suffixes = set()
        for value in paths:
            path = Path(value).expanduser()
            suffix = path.suffix.lower()
            suffixes.add(suffix)
            if suffix not in {".zgy", ".sgy", ".segy"}:
                unsupported.append(f"{value}（只支持 .zgy/.sgy/.segy）")
            if not path.is_file():
                missing.append(f"属性文件不存在：{value}")
        if unsupported:
            raise ValueError("属性文件格式错误：\n" + "\n".join(unsupported))
        if missing:
            raise ValueError("输入文件检查失败：\n" + "\n".join(missing))
        families = {"zgy" if suffix == ".zgy" else "segy" for suffix in suffixes}
        if len(families) != 1:
            raise ValueError("属性文件不能混用 ZGY 和 SEG-Y，请统一格式")
        if interval and suffixes != {".zgy"}:
            raise ValueError("层间模式目前要求属性体全部使用 .zgy；.sgy/.segy 仅支持单层位模式")
        horizon_paths = []
        if interval:
            horizon_paths.extend([self.vars["upper_horizon"].get(), self.vars["lower_horizon"].get()])
        else:
            horizon_paths.append(self.vars["single_horizon"].get())
        missing_horizons = [value for value in horizon_paths if not Path(value).expanduser().is_file()]
        if missing_horizons:
            raise ValueError("层位文件不存在：\n" + "\n".join(missing_horizons))
        horizon_formats = [Path(value).suffix.lower() for value in horizon_paths]
        non_dat = [value for value, suffix in zip(horizon_paths, horizon_formats) if suffix != ".dat"]
        if non_dat:
            raise ValueError("层位文件必须使用 .dat 格式：\n" + "\n".join(non_dat))
        well_csv = self.vars["well_csv"].get().strip()
        if well_csv and not Path(well_csv).expanduser().is_file():
            raise ValueError("井位 CSV 不存在：" + well_csv)
        well_xlsx = self.vars["well_xlsx"].get().strip()
        if well_xlsx:
            if Path(well_xlsx).suffix.lower() != ".xlsx":
                raise ValueError("井相表必须是 .xlsx 文件")
            if not Path(well_xlsx).expanduser().is_file():
                raise ValueError("井相 Excel 不存在：" + well_xlsx)
        well_mode_display = self.vars["well_mode"].get()
        well_mode_map = {
            "关闭": (False, "probability_decay"),
            "邻域井约束（硬标签合并）": (True, "neighbor_merge"),
            "概率衰减（软标签）": (True, "probability_decay"),
        }
        if well_mode_display not in well_mode_map:
            raise ValueError("请选择有效的井约束模式")
        well_supervision_enabled, well_decay_mode = well_mode_map[well_mode_display]
        plot_coords = self.vars["plot_coords"].get().strip()
        if plot_coords not in {"world", "inline_crossline", "index"}:
            raise ValueError("绘图坐标必须选择world、inline_crossline或index")
        if well_csv and plot_coords != "world":
            raise ValueError("井位CSV使用物理X/Y坐标；选择井位文件时，绘图坐标必须设为world")
        if well_supervision_enabled:
            if plot_coords != "world":
                raise ValueError("井约束按物理X/Y坐标计算；启用井约束时绘图坐标必须设为world")
            if not well_csv or not well_xlsx:
                raise ValueError("启用井约束时，必须同时选择井位CSV和井相Excel")
        postprocess_map = {
            "关闭": "none",
            "多数投票": "majority_vote",
            "软概率平滑": "probability_smoothing",
        }
        postprocess_display = self.vars["postprocess_mode"].get()
        if postprocess_display not in postprocess_map:
            raise ValueError("请选择有效的空间后处理模式")
        result_root_text = self.vars["result_root"].get().strip() or str(RESULTS_DIR)
        result_root = Path(result_root_text).expanduser()
        if result_root.exists() and not result_root.is_dir():
            raise ValueError("结果输出路径不是目录：" + str(result_root))
        run_name = self.vars["run_name"].get().strip() or "mamcl_run"
        if run_name in {".", ".."} or Path(run_name).name != run_name or not re.fullmatch(r"[A-Za-z0-9._-]+", run_name):
            raise ValueError("运行名称只能包含字母、数字、下划线、短横线和点，不能包含路径分隔符")
        stride = self._parse_ints(self.vars["train_stride"].get(), "训练步长")
        if len(stride) != 2 or min(stride) < 1:
            raise ValueError("训练步长格式应为 r,c")
        clusters = self._parse_ints(self.vars["clusters"].get(), "聚类 K")
        if len(set(clusters)) != len(clusters) or any(value < 2 for value in clusters):
            raise ValueError("聚类 K 必须是互不重复且不小于2的整数")
        def positive_int(key, label, allow_zero=False):
            try:
                value = int(self.vars[key].get())
            except ValueError as error:
                raise ValueError(f"{label}必须是整数") from error
            invalid = value < 0 if allow_zero else value < 1
            if invalid:
                raise ValueError(f"{label}必须{'大于等于0' if allow_zero else '大于0'}")
            return value
        def positive_float(key, label, allow_zero=False):
            try:
                value = float(self.vars[key].get())
            except ValueError as error:
                raise ValueError(f"{label}必须是数字") from error
            invalid = value < 0 if allow_zero else value <= 0
            if invalid:
                raise ValueError(f"{label}必须{'大于等于0' if allow_zero else '大于0'}")
            return value
        smooth_votes_text = self.vars["smooth_votes"].get().strip()
        smooth_votes = None if not smooth_votes_text else positive_int("smooth_votes", "平滑最小票数", allow_zero=False)
        result = {
            "RUN_NAME": run_name,
            "OUTPUT_ROOT": str(result_root.resolve()),
            "INPUT_PATHS": paths,
            "INTERVAL_MODE": interval,
            "HORIZON_FILE": self.vars["single_horizon"].get() if not interval else self.vars["upper_horizon"].get(),
            "UPPER_HORIZON_FILE": self.vars["upper_horizon"].get() if interval else None,
            "LOWER_HORIZON_FILE": self.vars["lower_horizon"].get() if interval else None,
            "INTERVAL_FRACTION": float(self.vars["fraction"].get()),
            "INTERVAL_CENTER_MODE": "fraction",
            "INTERVAL_WINDOW_MODE": "fixed",
            "WINDOW": int(self.vars["window"].get()),
            "GAUSSIAN_SIGMA": 1.5,
            "GAUSSIAN_PEAK_MODE": "center",
            "TRAIN_STRIDE": stride,
            "PREDICTION_STRIDE": [1, 1],
            "HORIZON_INTERPOLATION": True,
            "HORIZON_INTERPOLATION_METHOD": "linear_nearest",
            "HORIZON_CROP_TO_COMMON": interval,
            "HORIZON_FILL_NANS": True,
            "HORIZON_COORDINATES": self.vars["horizon_coords"].get().strip(),
            "PLOT_COORDINATES": plot_coords,
            "HORIZON_UNIT": self.vars["horizon_unit"].get().strip(),
            "BATCH_SIZE": positive_int("batch", "batch"),
            "FEATURE_BATCH": positive_int("feature_batch", "特征批"),
            "KMEANS_MAX_FIT_SAMPLES": positive_int("kmeans_cap", "K-Means上限", allow_zero=True),
            "EPOCHS": positive_int("epochs", "epochs"),
            "NOISE_STD": positive_float("noise", "噪声", allow_zero=True),
            "LR": positive_float("lr", "学习率"),
            "LR_WARMUP_EPOCHS": positive_int("lr_warmup", "预热轮数"),
            "LR_SCHEDULER_T0": positive_int("lr_t0", "余弦周期"),
            "LR_MIN_FACTOR": positive_float("lr_min_factor", "最低LR比例", allow_zero=True),
            "SEED": 42,
            "DEVICE": self.vars["device"].get().strip() or "auto",
            "PREDICTION_CLUSTERS": clusters,
            "SMOOTHING_KERNEL_SIZE": positive_int("smooth_kernel", "平滑核"),
            "SMOOTHING_ITERATIONS": positive_int("smooth_iterations", "平滑次数", allow_zero=True),
            "SMOOTHING_MIN_VOTES": smooth_votes,
            "SMOOTHING_COMPONENT_MIN_SIZE": positive_int("component_min_size", "小斑块最小面积", allow_zero=True),
            "SMOOTHING_COMPONENT_CONNECTIVITY": 8,
            "CPU_THREADS": positive_int("cpu_threads", "CPU线程"),
            "RUN_PREFLIGHT_CHECK": True,
            "CLEAN_RUN_DIR": True,
            "WELL_CSV_PATH": self.vars["well_csv"].get().strip() or None,
            "WELL_XLSX_PATH": well_xlsx or None,
            "WELL_GROUP": self.vars["well_group"].get().strip(),
            "WELL_SEGMENTS": [value.strip() for value in self.vars["well_segments"].get().replace("，", ",").split(",") if value.strip()],
            "WELL_SUPERVISION_ENABLED": well_supervision_enabled,
            "WELL_DECAY_MODE": well_decay_mode,
            "WELL_LOSS_WEIGHT": positive_float("well_loss_weight", "井约束损失权重", allow_zero=True),
            "WELL_SIGMA_FACTOR": positive_float("well_sigma_factor", "井间衰减尺度"),
            "WELL_MIN_WEIGHT": positive_float("well_min_weight", "最小井权重", allow_zero=True),
            "WELL_MAX_NEIGHBORS": positive_int("well_max_neighbors", "参与邻井数"),
            "WELL_MIN_CONFIDENCE": positive_float("well_min_confidence", "最低标签置信度", allow_zero=True),
            "WELL_FALLBACK_WEIGHT": positive_float("well_fallback_weight", "CSV备用标签权重", allow_zero=True),
            "WELL_CSV_ENCODING": "gbk",
            "WELL_X_COLUMN": "X坐标",
            "WELL_Y_COLUMN": "Y坐标",
            "WELL_NAME_COLUMN": "井号",
            "POSTPROCESS_MODE": postprocess_map[postprocess_display],
            "PROBABILITY_SMOOTHING_SIGMA": positive_float("prob_smoothing_sigma", "概率平滑σ"),
            "SEGY_INLINE_FIELD": 9,
            "SEGY_CROSSLINE_FIELD": 21,
            "SEGY_SOURCE_X_FIELD": 73,
            "SEGY_SOURCE_Y_FIELD": 77,
            "SEGY_COORDINATE_SCALAR_FIELD": 71,
        }
        if result["SMOOTHING_KERNEL_SIZE"] < 3 or result["SMOOTHING_KERNEL_SIZE"] % 2 == 0:
            raise ValueError("平滑核必须是大于等于3的奇数")
        if smooth_votes is not None and smooth_votes > result["SMOOTHING_KERNEL_SIZE"] ** 2:
            raise ValueError("平滑最小票数不能超过平滑核覆盖的像素数")
        if result["EPOCHS"] < 1 or result["BATCH_SIZE"] < 1:
            raise ValueError("epochs和batch必须为正数")
        if result["LR_WARMUP_EPOCHS"] < 1 or result["LR_SCHEDULER_T0"] < 1:
            raise ValueError("学习率预热轮数和余弦周期必须为正数")
        if not 0.0 <= result["LR_MIN_FACTOR"] <= 1.0:
            raise ValueError("最低LR比例必须在0到1之间")
        if not 0.0 < result["INTERVAL_FRACTION"] < 1.0:
            raise ValueError("层间比例必须在0和1之间")
        for key, label in (("WELL_MIN_WEIGHT", "最小井权重"), ("WELL_MIN_CONFIDENCE", "最低标签置信度"), ("WELL_FALLBACK_WEIGHT", "CSV备用标签权重")):
            if not 0.0 <= result[key] <= 1.0:
                raise ValueError(f"{label}必须在0到1之间")
        if result["WELL_GROUP"] and not result["WELL_SEGMENTS"]:
            raise ValueError("填写地层组筛选时，层段筛选也必须至少填写一个值")
        if result["HORIZON_COORDINATES"] not in {"world", "inline_crossline"}:
            raise ValueError("层位坐标必须是world或inline_crossline")
        if result["HORIZON_UNIT"] not in {"samples", "ms", "s"}:
            raise ValueError("采样单位必须是samples、ms或s")
        return result

    def _save_config(self, data):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        path = CONFIG_DIR / f"{data['RUN_NAME']}.json"
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def _save_config_dialog(self):
        try:
            path = filedialog.asksaveasfilename(initialdir=CONFIG_DIR, defaultextension=".json", filetypes=[("JSON", "*.json")])
            if path:
                Path(path).write_text(json.dumps(self._config(), ensure_ascii=False, indent=2), encoding="utf-8")
                self._log("配置已保存: " + path)
        except Exception as error:
            messagebox.showerror("配置错误", str(error))

    def _load_config_dialog(self):
        path = filedialog.askopenfilename(initialdir=CONFIG_DIR, filetypes=[("JSON", "*.json"), ("全部文件", "*.*")])
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            self._apply_config(data)
            self._log("配置已加载: " + path)
        except Exception as error:
            messagebox.showerror("配置错误", f"无法加载配置：\n{error}")

    def _apply_config(self, data):
        scalar_keys = {
            "RUN_NAME": "run_name", "INTERVAL_FRACTION": "fraction", "WINDOW": "window",
            "BATCH_SIZE": "batch", "FEATURE_BATCH": "feature_batch", "KMEANS_MAX_FIT_SAMPLES": "kmeans_cap",
            "EPOCHS": "epochs", "NOISE_STD": "noise", "LR": "lr", "LR_WARMUP_EPOCHS": "lr_warmup",
            "LR_SCHEDULER_T0": "lr_t0", "LR_MIN_FACTOR": "lr_min_factor", "DEVICE": "device",
            "SMOOTHING_KERNEL_SIZE": "smooth_kernel", "SMOOTHING_ITERATIONS": "smooth_iterations",
            "SMOOTHING_MIN_VOTES": "smooth_votes", "CPU_THREADS": "cpu_threads",
            "HORIZON_UNIT": "horizon_unit", "HORIZON_COORDINATES": "horizon_coords",
            "PLOT_COORDINATES": "plot_coords",
            "OUTPUT_ROOT": "result_root",
        }
        for source, target in scalar_keys.items():
            if source in data and data[source] is not None:
                self.vars[target].set(str(data[source]))
        self.vars["mode"].set("interval" if data.get("INTERVAL_MODE", False) else "single")
        self.vars["single_horizon"].set(data.get("HORIZON_FILE") or "")
        self.vars["upper_horizon"].set(data.get("UPPER_HORIZON_FILE") or "")
        self.vars["lower_horizon"].set(data.get("LOWER_HORIZON_FILE") or "")
        self.vars["well_csv"].set(data.get("WELL_CSV_PATH") or "")
        self.vars["well_xlsx"].set(data.get("WELL_XLSX_PATH") or "")
        self.vars["well_mode"].set(
            "邻域井约束（硬标签合并）" if data.get("WELL_SUPERVISION_ENABLED") and data.get("WELL_DECAY_MODE") == "neighbor_merge"
            else "概率衰减（软标签）" if data.get("WELL_SUPERVISION_ENABLED")
            else "关闭"
        )
        self.vars["postprocess_mode"].set({
            "none": "关闭", "majority_vote": "多数投票", "probability_smoothing": "软概率平滑",
        }.get(str(data.get("POSTPROCESS_MODE", "majority_vote")), "多数投票"))
        well_scalar_keys = {
            "WELL_GROUP": "well_group", "WELL_LOSS_WEIGHT": "well_loss_weight",
            "WELL_SIGMA_FACTOR": "well_sigma_factor", "WELL_MIN_WEIGHT": "well_min_weight",
            "WELL_MAX_NEIGHBORS": "well_max_neighbors", "WELL_MIN_CONFIDENCE": "well_min_confidence",
            "WELL_FALLBACK_WEIGHT": "well_fallback_weight", "PROBABILITY_SMOOTHING_SIGMA": "prob_smoothing_sigma",
            "SMOOTHING_COMPONENT_MIN_SIZE": "component_min_size",
        }
        for source, target in well_scalar_keys.items():
            if source in data and data[source] is not None:
                self.vars[target].set(str(data[source]))
        if "WELL_SEGMENTS" in data:
            self.vars["well_segments"].set(",".join(map(str, data["WELL_SEGMENTS"] or [])))
        stride = data.get("TRAIN_STRIDE", [4, 4])
        self.vars["train_stride"].set(",".join(map(str, stride)))
        clusters = data.get("PREDICTION_CLUSTERS", [3, 4, 5, 6, 7, 8, 9])
        self.vars["clusters"].set(",".join(map(str, clusters)))
        self.attribute_text.delete("1.0", "end")
        self.attribute_text.insert("1.0", "\n".join(map(str, data.get("INPUT_PATHS", []))))
        self._update_mode()

    def _start(self):
        if self.process is not None:
            return
        try:
            self._selected_python()
        except Exception as error:
            messagebox.showerror("Python 环境错误", str(error))
            return
        try:
            data = self._config()
            config_path = self._save_config(data)
        except Exception as error:
            messagebox.showerror("配置错误", str(error))
            return
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.status_text.set("运行中")
        self.progress.configure(mode="indeterminate")
        self.progress.start(12)
        self._launch(self._runner_with_args(["--config", str(config_path)]), "启动")

    def _check(self):
        if self.process is not None:
            return
        try:
            self._selected_python()
        except Exception as error:
            messagebox.showerror("Python 环境错误", str(error))
            return
        try:
            data = self._config()
            config_path = self._save_config(data)
        except Exception as error:
            messagebox.showerror("配置错误", str(error))
            return
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.status_text.set("检查中")
        self.progress.configure(mode="indeterminate")
        self.progress.start(12)
        self._launch(self._runner_with_args(["--config", str(config_path), "--check-only"]), "检查")

    def _runner_command(self):
        python_path, runner_path = self._selected_python()
        self._save_python_setting(python_path)
        return python_path, runner_path

    def _runner_with_args(self, args):
        command = self._runner_command()
        base = list(command) if isinstance(command, tuple) else [command]
        return base + list(args)

    def _launch(self, command, label):
        self._log(label + ": " + " ".join(map(str, command)))
        try:
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            env = os.environ.copy()
            env["MAMCL_APP_ROOT"] = str(ROOT)
            env["MAMCL_RESOURCE_ROOT"] = str(ROOT)
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUNBUFFERED"] = "1"
            self.process = subprocess.Popen(
                command,
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                creationflags=flags,
                env=env,
            )
        except OSError as error:
            self.process = None
            self.progress.stop()
            self.start_button.configure(state="normal")
            self.stop_button.configure(state="disabled")
            messagebox.showerror("无法启动", f"无法启动 Python 子进程：\n{error}")
            return
        threading.Thread(target=self._read_process, daemon=True).start()

    def _read_process(self):
        assert self.process is not None
        for line in self.process.stdout:
            self.log_queue.put(line.rstrip())
        code = self.process.wait()
        self.log_queue.put(f"[完成] exit={code}")
        self.log_queue.put(("done", code))

    def _drain_log(self):
        try:
            while True:
                item = self.log_queue.get_nowait()
                if isinstance(item, tuple) and item[0] == "done":
                    code = int(item[1])
                    self.process = None
                    self.progress.stop()
                    self.progress.configure(mode="indeterminate")
                    self.start_button.configure(state="normal")
                    self.stop_button.configure(state="disabled")
                    self.status_text.set("已完成" if code == 0 else "失败")
                    if code != 0:
                        if code == 2:
                            messagebox.showerror("Python 环境依赖", "所选环境缺少依赖或依赖无法加载。请按右侧日志提示安装 requirements.txt。")
                            continue
                        run_name = self.vars["run_name"].get().strip() or "mamcl_run"
                        result_root = Path(self.vars["result_root"].get().strip() or str(RESULTS_DIR)).expanduser()
                        run_path = result_root / run_name
                        messagebox.showerror(
                            "流程失败",
                            f"流程退出码：{code}\n\n请查看 {run_path}/run_*.log 和 result_summary.txt。\n输入检查失败时，先修正日志中第一条错误。",
                        )
                else:
                    self._log(item)
        except queue.Empty:
            pass
        self.after(100, self._drain_log)

    def _log(self, text):
        for line in str(text).splitlines() or [""]:
            self._log_lines.append(line)
        match = re.search(r"(?:epoch|Epoch)[ =:]+(\d+)", str(text))
        if match:
            try:
                epochs = max(1, int(self.vars["epochs"].get()))
                self.progress.stop()
                self.progress.configure(mode="determinate", maximum=100)
                self.progress["value"] = min(100.0, 100.0 * int(match.group(1)) / epochs)
            except (ValueError, tk.TclError):
                pass
        self._refresh_log()

    def _refresh_log(self):
        if not hasattr(self, "log"):
            return
        selected = self.log_filter.get()
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        for line in self._log_lines:
            low = line.lower()
            if selected == "ERROR" and not any(token in low for token in ("error", "traceback", "failed", "失败")):
                continue
            if selected == "WARNING" and "warning" not in low and "warn" not in low:
                continue
            if selected == "INFO" and any(token in low for token in ("error", "traceback", "failed", "warning", "warn")):
                continue
            if any(token in low for token in ("error", "traceback", "failed", "失败")):
                tag = "error"
            elif "warning" in low or "warn" in low:
                tag = "warning"
            elif any(token in low for token in ("pass", "finished", "completed", "success", "完成", "通过")):
                tag = "success"
            else:
                tag = "info"
            self.log.insert("end", line + "\n", tag)
        if self.log_autoscroll.get():
            self.log.see("end")
        self.log.configure(state="disabled")

    def _clear_log(self):
        self._log_lines.clear()
        self._refresh_log()

    def _stop(self):
        if self.process is not None:
            self.process.terminate()
            self.status_text.set("正在停止")
            self._log("已请求停止当前运行")

    def _open_results(self):
        try:
            result_root = Path(self.vars["result_root"].get().strip() or str(RESULTS_DIR)).expanduser()
            result_root.mkdir(parents=True, exist_ok=True)
            os.startfile(str(result_root.resolve()))
        except OSError as error:
            messagebox.showerror("无法打开目录", str(error))


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        app = MAMCLApp()
        app.withdraw()
        app.update_idletasks()
        app.destroy()
    else:
        MAMCLApp().mainloop()
