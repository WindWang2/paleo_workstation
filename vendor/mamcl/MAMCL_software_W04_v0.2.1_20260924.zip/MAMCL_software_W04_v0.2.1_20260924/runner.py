"""Run the standalone MAMCL pipeline from a JSON configuration.

The runner changes only the copied package's run_all module in memory. The
original server packages are never imported or modified.
"""
from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
from pathlib import Path


RESOURCE_ROOT = Path(os.environ.get(
    "MAMCL_RESOURCE_ROOT",
    getattr(sys, "_MEIPASS", Path(__file__).resolve().parent),
))
ROOT = Path(os.environ.get(
    "MAMCL_APP_ROOT",
    Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent,
))
GENERIC = RESOURCE_ROOT / "tools" / "generic"
TOOLS = RESOURCE_ROOT / "tools"
for item in (GENERIC, TOOLS):
    if str(item) not in sys.path:
        sys.path.insert(0, str(item))


def _parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Standalone MAMCL runner")
    parser.add_argument("--config", required=True, help="JSON configuration path")
    parser.add_argument("--from-step", type=int, default=0, choices=range(8))
    parser.add_argument("--check-only", action="store_true", help="只做输入和环境检查")
    return parser.parse_args(argv)


def _load_config(path: str | Path) -> dict:
    config_path = Path(path).expanduser().resolve()
    data = json.loads(config_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("配置文件必须是 JSON 对象")
    data["_config_path"] = str(config_path)
    return data


class DependencyError(RuntimeError):
    pass


def _check_dependencies(data: dict) -> None:
    paths = data.get("INPUT_PATHS") or []
    if not isinstance(paths, (list, tuple)):
        raise ValueError("INPUT_PATHS必须是属性文件路径数组")
    required = [
        "numpy", "torch", "torchvision", "sklearn", "matplotlib",
        "scipy", "einops", "transforms3d", "tqdm", "kmeans_pytorch", "segyio",
    ]
    suffixes = {Path(str(path)).suffix.lower() for path in paths}
    if bool(data.get("INTERVAL_MODE")) or ".zgy" in suffixes:
        required.extend(("pyzgy", "openzgy"))
    failed = []
    for name in required:
        try:
            importlib.import_module(name)
        except Exception as error:
            reason = " ".join(str(error).split())[:180]
            failed.append(f"{name}: {type(error).__name__}: {reason}")
    if failed:
        install = f'"{sys.executable}" -m pip install -r "{ROOT / "requirements.txt"}"'
        raise DependencyError(
            "所选Python环境无法加载所需依赖：\n"
            + "\n".join(failed)
            + "\n请在该环境安装requirements.txt；命令：\n"
            + install
        )


def _apply_overrides(run_all, data: dict):
    protected = {"ROOT", "TOOLS", "GENERIC", "_config_path", "CPU_THREADS", "RUN_PREFLIGHT_CHECK", "CLEAN_RUN_DIR"}
    for key, value in data.items():
        if key.startswith("_") or key in protected:
            continue
        if not key.isupper():
            continue
        if not hasattr(run_all, key):
            raise ValueError(f"未知配置项：{key}")
        if key in {"TRAIN_STRIDE", "PREDICTION_STRIDE"}:
            value = tuple(int(v) for v in value)
            if len(value) != 2 or min(value) < 1:
                raise ValueError(f"{key}必须是两个正整数")
        if key in {"INPUT_PATHS", "PREDICTION_CLUSTERS"}:
            if not isinstance(value, (list, tuple)):
                raise ValueError(f"{key}必须是数组")
            value = list(value)
        setattr(run_all, key, value)


def main(argv=None):
    args = _parse_args(argv)
    data = _load_config(args.config)
    # These limits are deliberately conservative and can be raised in JSON.
    os.environ.setdefault("OMP_NUM_THREADS", str(int(data.get("CPU_THREADS", 4))))
    os.environ.setdefault("MKL_NUM_THREADS", str(int(data.get("CPU_THREADS", 4))))
    os.environ.setdefault("NUMEXPR_NUM_THREADS", str(int(data.get("CPU_THREADS", 4))))

    _check_dependencies(data)
    import run_all

    _apply_overrides(run_all, data)
    run_all.RUN_PREFLIGHT_CHECK = bool(data.get("RUN_PREFLIGHT_CHECK", True))
    run_all.CLEAN_RUN_DIR = bool(data.get("CLEAN_RUN_DIR", True))
    run_all.apply_config()
    print("standalone data root:", ROOT)
    print("standalone resource root:", RESOURCE_ROOT)
    print("config:", Path(args.config).resolve())
    print("run name:", run_all.RUN_NAME)
    print("device request:", run_all.DEVICE)
    if args.check_only:
        import check_all
        check_all.main()
        return
    run_all.main(["--from-step", str(args.from_step)])


if __name__ == "__main__":
    try:
        main()
    except DependencyError as error:
        print(error, file=sys.stderr)
        raise SystemExit(2) from None
