from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def plot_spatial_attribute_attention(
    attention,
    positions,
    spatial_shape,
    attribute_names,
    output_dir,
    coordinates=None,
):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    attention = np.asarray(attention, dtype=np.float32)
    positions = np.asarray(positions, dtype=np.int64)
    spatial_shape = tuple(int(value) for value in spatial_shape[:2])
    names = [str(name) for name in attribute_names]
    if attention.ndim != 2 or attention.shape[1] != len(names):
        raise ValueError("attention必须是[N,M]，且M必须等于属性名数量")
    if positions.shape != (attention.shape[0], 2):
        raise ValueError("positions必须是[N,2]")

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    maps = np.full((attention.shape[1], *spatial_shape), np.nan, dtype=np.float32)
    maps[:, positions[:, 0], positions[:, 1]] = attention.T
    np.save(output_dir / "attribute_attention_maps.npy", maps)
    if coordinates is None:
        from plot_coordinates import load_plot_coordinates

        coordinates = load_plot_coordinates(None, spatial_shape, mode="index")
    else:
        if not isinstance(coordinates, dict) or "x" not in coordinates or "y" not in coordinates:
            raise ValueError("coordinates必须包含x和y二维坐标网格")
        if np.asarray(coordinates["x"]).shape != spatial_shape or np.asarray(coordinates["y"]).shape != spatial_shape:
            raise ValueError("coordinates与spatial_shape不一致")
    coordinate_x = np.asarray(coordinates["x"], dtype=float)
    coordinate_y = np.asarray(coordinates["y"], dtype=float)

    finite = attention[np.isfinite(attention)]
    vmax = float(np.max(finite)) if finite.size else 1.0
    vmin = 0.0
    if vmax <= vmin:
        vmax = 1.0
    with (output_dir / "attribute_attention_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "attention_shape": list(attention.shape),
                "map_shape": list(maps.shape),
                "spatial_shape": list(spatial_shape),
                "attribute_names": names,
                        "definition": "CLS query attention averaged over Transformer layers and heads, then summed over each attribute's eight tokens; dense prediction uses no attribute mask",
                "display": {"colormap": "viridis", "vmin": vmin, "vmax": vmax},
                "coordinate": {
                    "mode": str(coordinates.get("mode", "index")),
                    "xlabel": str(coordinates.get("xlabel", "X coordinate")),
                    "ylabel": str(coordinates.get("ylabel", "Y coordinate")),
                    "source": coordinates.get("source"),
                },
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )
    rows = int(np.ceil(len(names) / 3))
    figure, axes = plt.subplots(rows, 3, figsize=(13, 4.0 * rows), squeeze=False, constrained_layout=True)
    image = None
    for index, name in enumerate(names):
        axis = axes.flat[index]
        image = axis.pcolormesh(
            coordinate_x,
            coordinate_y,
            np.ma.masked_invalid(maps[index]),
            shading="auto",
            edgecolors="none",
            linewidth=0.0,
            antialiased=False,
            cmap="viridis",
            vmin=vmin,
            vmax=vmax,
        )
        axis.set_title(name)
        axis.set_xlabel(str(coordinates.get("xlabel", "X coordinate")))
        axis.set_ylabel(str(coordinates.get("ylabel", "Y coordinate")))
        axis.set_aspect("equal", adjustable="box")
    for axis in axes.flat[len(names):]:
        axis.axis("off")
    figure.colorbar(image, ax=axes.ravel().tolist(), shrink=0.85, label="CLS attention")
    figure.savefig(output_dir / "attribute_attention_maps.png", dpi=220)
    plt.close(figure)

    means = np.nanmean(maps.reshape(maps.shape[0], -1), axis=1)
    order = np.argsort(means)[::-1]
    figure, axis = plt.subplots(figsize=(10, 5), constrained_layout=True)
    axis.bar(np.arange(len(names)), means[order], color=plt.get_cmap("viridis")(np.linspace(0.1, 0.9, len(names))))
    axis.set_xticks(np.arange(len(names)))
    axis.set_xticklabels([names[index] for index in order], rotation=35, ha="right")
    axis.set_ylabel("attribute-summed CLS attention")
    axis.set_xlabel("attributes")
    axis.set_title("Feature attention")
    figure.savefig(output_dir / "feature_attention_bar.png", dpi=220)
    plt.close(figure)

    return maps, means
