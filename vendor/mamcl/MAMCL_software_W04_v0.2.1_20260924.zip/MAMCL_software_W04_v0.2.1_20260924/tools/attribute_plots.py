from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from plot_styles import crop_2d, display_bbox
from well_overlay import scatter_wells


def _display_limits(values):
    finite = np.asarray(values, dtype=np.float32)
    finite = finite[np.isfinite(finite)]
    if finite.size == 0:
        return -1.0, 1.0
    lower, upper = np.percentile(finite, [1.0, 99.0])
    if not np.isfinite(lower) or not np.isfinite(upper) or lower == upper:
        lower = float(np.min(finite))
        upper = float(np.max(finite))
    if lower == upper:
        delta = max(abs(float(lower)) * 0.01, 1.0)
        lower -= delta
        upper += delta
    return float(lower), float(upper)


def _paper_colormap():
    from matplotlib.colors import LinearSegmentedColormap

    return LinearSegmentedColormap.from_list(
        "paper_attribute",
        ["#8ce6ea", "#2448ad", "#f1f1f1", "#b22e2e", "#ffe91b"],
        N=256,
    )


def _load_horizon_surface(bundle, spatial_shape):
    metadata = bundle.get("metadata", {})
    parameters = metadata.get("parameters", {}) if isinstance(metadata, dict) else {}
    horizon_file = parameters.get("horizon_file")
    config_parameters = {}
    if not horizon_file:
        try:
            import config

            horizon_file = getattr(config, "HORIZON_FILE", None)
            config_parameters = {
                "horizon_shape": getattr(config, "HORIZON_SHAPE", None),
                "horizon_dtype": getattr(config, "HORIZON_DTYPE", None),
                "horizon_endian": getattr(config, "HORIZON_ENDIAN", None),
                "horizon_order": getattr(config, "HORIZON_ORDER", None),
                "horizon_key": getattr(config, "HORIZON_NPZ_KEY", None),
            }
        except Exception:
            horizon_file = None
    if not horizon_file:
        return np.zeros(spatial_shape, dtype=np.float32), "flat fallback (no horizon_file)"
    try:
        from read_volume import read_surface

        horizon_kwargs = {}
        for parameter, keyword in (
            ("horizon_shape", "shape"),
            ("horizon_dtype", "dtype"),
            ("horizon_endian", "endian"),
            ("horizon_order", "order"),
            ("horizon_key", "key"),
        ):
            value = parameters.get(parameter, config_parameters.get(parameter))
            if value is not None:
                horizon_kwargs[keyword] = tuple(int(item) for item in value) if parameter == "horizon_shape" else value
        surface = np.asarray(read_surface(horizon_file, **horizon_kwargs), dtype=np.float32)
        if surface.shape != spatial_shape:
            return (
                np.zeros(spatial_shape, dtype=np.float32),
                f"flat fallback (horizon shape {surface.shape} != {spatial_shape})",
            )
        return surface, str(Path(horizon_file).resolve())
    except Exception as exc:
        return np.zeros(spatial_shape, dtype=np.float32), f"flat fallback ({type(exc).__name__}: {exc})"


def plot_horizon_attribute_slices(bundle, spatial_shape, output_dir, coordinates=None, well_points=None, well_style=None):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize, TwoSlopeNorm

    samples = np.asarray(bundle["samples"], dtype=np.float32)
    positions = np.asarray(bundle["positions"], dtype=np.int64)
    names = [str(name) for name in bundle["attribute_names"]]
    if samples.ndim != 4 or samples.shape[2] != 1 or samples.shape[3] % 2 != 1:
        raise ValueError("samples必须是[N,M,1,奇数窗口]数组")
    if positions.shape != (samples.shape[0], 2):
        raise ValueError("positions必须是[N,2]")
    if len(names) != samples.shape[1]:
        raise ValueError("属性名数量与samples不一致")

    spatial_shape = tuple(int(value) for value in spatial_shape[:2])
    if len(spatial_shape) != 2 or any(value <= 0 for value in spatial_shape):
        raise ValueError("spatial_shape必须是两个正整数")
    if np.any(positions < 0) or np.any(positions[:, 0] >= spatial_shape[0]) or np.any(positions[:, 1] >= spatial_shape[1]):
        raise ValueError("positions超出空间网格范围")

    metadata = bundle.get("metadata", {})
    parameters = metadata.get("parameters", {}) if isinstance(metadata, dict) else {}
    interval_mode = str(parameters.get("interval_window_mode", "")).lower()
    one_sided_modes = {"upper_anchor_coverage", "upper_anchor_down", "downward_coverage"}
    if interval_mode in one_sided_modes:
        sample_index = 0
        sample_reference = "upper horizon anchor plus interval_anchor_offset"
    else:
        sample_index = samples.shape[-1] // 2
        sample_reference = "sequence center"
    central = samples[:, :, 0, sample_index]
    normalization = metadata.get("normalization") if isinstance(metadata, dict) else None
    value_space = "normalized sample values"
    if normalization is not None:
        center = np.asarray(normalization.get("center"), dtype=np.float32)
        scale = np.asarray(normalization.get("scale"), dtype=np.float32)
        if center.shape != (samples.shape[1],) or scale.shape != center.shape:
            raise ValueError("归一化参数数量与属性数量不一致")
        central = central * scale[None, :] + center[None, :]
        value_space = "raw attribute values reconstructed from stored normalization"

    maps = np.full((samples.shape[1], *spatial_shape), np.nan, dtype=np.float32)
    maps[:, positions[:, 0], positions[:, 1]] = central.T
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    np.save(output_dir / "attribute_horizon_slices.npy", maps)
    display_crop = display_bbox(np.isfinite(maps).any(axis=0))
    maps_display = np.stack([crop_2d(values, display_crop) for values in maps], axis=0)
    if coordinates is None:
        from plot_coordinates import load_plot_coordinates, crop_coordinates

        coordinates = load_plot_coordinates(None, spatial_shape, mode="index")
    else:
        if not isinstance(coordinates, dict) or "x" not in coordinates or "y" not in coordinates:
            raise ValueError("coordinates必须包含x和y二维坐标网格")
        if np.asarray(coordinates["x"]).shape != spatial_shape or np.asarray(coordinates["y"]).shape != spatial_shape:
            raise ValueError("coordinates与spatial_shape不一致")
        from plot_coordinates import crop_coordinates
    display_coordinates = crop_coordinates(coordinates, display_crop)
    x_display = np.asarray(display_coordinates["x"], dtype=float)
    y_display = np.asarray(display_coordinates["y"], dtype=float)

    paper_cmap = _paper_colormap()
    rows = int(np.ceil(len(names) / 3))
    figure, axes = plt.subplots(
        rows,
        3,
        figsize=(20.0, 5.0 * rows),
        squeeze=False,
    )
    figure.subplots_adjust(left=0.012, right=0.988, bottom=0.025, top=0.94, wspace=0.035, hspace=0.14)
    for index, name in enumerate(names):
        axis = axes[index // 3, index % 3]
        values = maps_display[index]
        valid = np.isfinite(values)
        vmin, vmax = _display_limits(values)
        image = axis.pcolormesh(
            x_display,
            y_display,
            np.ma.masked_invalid(values),
            shading="auto",
            edgecolors="none",
            linewidth=0.0,
            antialiased=False,
            cmap=paper_cmap,
            vmin=vmin,
            vmax=vmax,
        )
        axis.set_title(name, fontsize=14, pad=3)
        axis.set_xlabel(str(coordinates.get("xlabel", "X coordinate")), fontsize=8)
        axis.set_ylabel(str(coordinates.get("ylabel", "Y coordinate")), fontsize=8)
        axis.tick_params(labelsize=7, pad=1)
        axis.set_aspect("equal", adjustable="box")
        scatter_wells(
            axis,
            well_points,
            display_coordinates,
            valid_mask=valid,
            **dict(well_style or {}),
        )
        colorbar = figure.colorbar(image, ax=axis, orientation="horizontal", fraction=0.045, pad=0.025)
        colorbar.ax.tick_params(labelsize=9)
        if not valid.any():
            axis.text(
                0.5,
                0.5,
                "no valid sample",
                transform=axis.transAxes,
                ha="center",
                va="center",
            )
    for index in range(len(names), rows * 3):
        axes[index // 3, index % 3].set_axis_off()
    figure.suptitle("ZGY attributes at target horizon", fontsize=17)
    figure.savefig(output_dir / "zgy_horizon_slices_2d.png", dpi=300, facecolor="white")
    plt.close(figure)

    surface, surface_source = _load_horizon_surface(bundle, spatial_shape)
    surface_display = crop_2d(surface, display_crop)
    display_shape = maps_display.shape[1:]
    x_grid = x_display
    y_grid = y_display
    finite_surface = surface_display[np.isfinite(surface_display)]
    surface_fill = float(np.median(finite_surface)) if finite_surface.size else 0.0
    surface_for_plot = np.where(np.isfinite(surface_display), surface_display, surface_fill).astype(np.float32)

    from matplotlib import cm

    paper_cmap = _paper_colormap()
    limits = []
    rows = int(np.ceil(len(names) / 3))
    figure = plt.figure(figsize=(20.0, 5.2 * rows), constrained_layout=False)
    figure.subplots_adjust(left=0.005, right=0.995, bottom=0.015, top=0.97)
    outer_grid = figure.add_gridspec(
        rows, 3, left=0.005, right=0.995, bottom=0.015, top=0.97,
        wspace=0.008, hspace=0.06,
    )
    x_limits = (float(np.nanmin(x_grid)), float(np.nanmax(x_grid)))
    y_limits = (float(np.nanmin(y_grid)), float(np.nanmax(y_grid)))
    z_limits = (float(np.nanmin(surface_for_plot)), float(np.nanmax(surface_for_plot)))
    if z_limits[0] == z_limits[1]:
        delta = max(abs(z_limits[0]) * 0.01, 1.0)
        z_limits = (z_limits[0] - delta, z_limits[1] + delta)
    for index, name in enumerate(names):
        cell = outer_grid[index // 3, index % 3].subgridspec(
            2, 1, height_ratios=(0.92, 0.08), hspace=0.0,
        )
        axis = figure.add_subplot(cell[0], projection="3d")
        colorbar_axis = figure.add_subplot(cell[1])
        values = maps_display[index]
        valid = np.isfinite(values)
        vmin, vmax = _display_limits(values)
        limits.append({"vmin": vmin, "vmax": vmax})
        if vmin < 0.0 < vmax:
            norm = TwoSlopeNorm(vmin=vmin, vcenter=0.0, vmax=vmax)
        else:
            norm = Normalize(vmin=vmin, vmax=vmax)

        colors = paper_cmap(norm(np.nan_to_num(values, nan=vmin)))
        colors[..., 3] = np.where(valid, 1.0, 0.0)
        axis.plot_surface(
            x_grid,
            y_grid,
            surface_for_plot,
            facecolors=colors,
            rstride=max(1, display_shape[0] // 240),
            cstride=max(1, display_shape[1] // 240),
            linewidth=0,
            antialiased=False,
            shade=False,
        )
        axis.set_xlim(*x_limits)
        axis.set_ylim(*y_limits)
        axis.set_zlim(*z_limits)
        axis.view_init(elev=42, azim=-55)
        try:
            axis.set_proj_type("persp", focal_length=1.0)
        except TypeError:
            axis.set_proj_type("persp")
        axis.dist = 2.5
        axis.set_axis_off()
        axis.text2D(
            0.5,
            0.98,
            name,
            transform=axis.transAxes,
            ha="center",
            va="top",
            fontsize=16,
        )
        try:
            axis.set_box_aspect((1.6, 1.0, 0.08), zoom=1.35)
        except TypeError:
            axis.set_box_aspect((1.6, 1.0, 0.08))
        mapper = cm.ScalarMappable(norm=norm, cmap=paper_cmap)
        mapper.set_array(values[np.isfinite(values)])
        colorbar = figure.colorbar(mapper, cax=colorbar_axis, orientation="horizontal")
        colorbar.ax.tick_params(labelsize=9, pad=1, length=3)
        colorbar.outline.set_linewidth(0.45)
    for index in range(len(names), rows * 3):
        cell = outer_grid[index // 3, index % 3].subgridspec(
            2, 1, height_ratios=(0.91, 0.09), hspace=0.0,
        )
        figure.add_subplot(cell[0], projection="3d").set_axis_off()
        figure.add_subplot(cell[1]).set_axis_off()

    figure.savefig(output_dir / "attribute_horizon_slices.png", dpi=300, facecolor="white")
    plt.close(figure)

    with (output_dir / "attribute_horizon_slices_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "attribute_names": names,
                "map_shape": list(maps.shape),
                "spatial_shape": list(spatial_shape),
                "display_crop": list(display_crop),
                "display_shape": list(display_shape),
                "center_index": int(sample_index),
                "sample_index": int(sample_index),
                "sample_reference": sample_reference,
                "value_space": value_space,
                "missing_value": "NaN shown transparent outside valid sample coverage",
                "display_limits": limits,
                "display_percentiles": [1.0, 99.0],
                "surface_source": surface_source,
                "surface_space": "horizon file values; real X/Y coordinates used for the surface grid",
                "plot_type": "oblique 3D horizon surface with attribute-colored faces",
                "two_dimensional_slice": "zgy_horizon_slices_2d.png",
                "colormap": "paper_attribute",
                "coordinate": {
                    "mode": str(coordinates.get("mode", "index")),
                    "xlabel": str(coordinates.get("xlabel", "X coordinate")),
                    "ylabel": str(coordinates.get("ylabel", "Y coordinate")),
                    "source": coordinates.get("source"),
                    "display_x_range": [float(np.nanmin(x_display)), float(np.nanmax(x_display))],
                    "display_y_range": [float(np.nanmin(y_display)), float(np.nanmax(y_display))],
                },
                "source_bundle": bundle.get("path"),
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )
    return maps

