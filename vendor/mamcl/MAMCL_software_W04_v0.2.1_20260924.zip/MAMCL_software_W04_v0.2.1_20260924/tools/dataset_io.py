from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def validate_bundle(samples, positions, attribute_names):
    samples = np.asarray(samples)
    positions = np.asarray(positions)
    names = [str(name) for name in attribute_names]
    if samples.ndim != 4:
        raise ValueError(f"samples必须是[N,M,ext,L]四维数组，实际为{samples.shape}")
    if samples.shape[2] != 1:
        raise ValueError(f"当前MAMCL适配器要求ext=1，实际为{samples.shape[2]}")
    if positions.shape != (samples.shape[0], 2):
        raise ValueError(f"positions必须是[N,2]，实际为{positions.shape}")
    if len(names) != samples.shape[1]:
        raise ValueError("attribute_names数量必须等于samples的属性数M")
    if not np.issubdtype(samples.dtype, np.number) or not np.isfinite(samples).all():
        raise ValueError("samples必须是有限数值数组")
    if not np.issubdtype(positions.dtype, np.number) or not np.isfinite(positions).all():
        raise ValueError("positions必须是有限数值数组")
    if np.unique(positions, axis=0).shape[0] != positions.shape[0]:
        raise ValueError("positions包含重复空间位置")
    return samples.astype(np.float32, copy=False), positions.astype(np.int64, copy=False), names


def save_bundle(path, samples, positions, attribute_names, metadata=None):
    samples, positions, names = validate_bundle(samples, positions, attribute_names)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    meta = dict(metadata or {})
    meta["sample_shape"] = list(samples.shape)
    meta["attribute_names"] = names
    np.savez_compressed(
        path,
        samples=samples,
        positions=positions,
        attribute_names=np.asarray(names),
        metadata=np.asarray(json.dumps(meta, ensure_ascii=False)),
    )
    return path


def load_bundle(path):
    path = Path(path)
    if path.suffix.lower() != ".npz":
        raise ValueError("MAMCL样本包必须是.npz文件")
    if not path.exists():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as archive:
        required = {"samples", "positions", "attribute_names"}
        missing = required.difference(archive.files)
        if missing:
            raise ValueError(f"样本包缺少字段：{sorted(missing)}")
        samples = np.asarray(archive["samples"])
        positions = np.asarray(archive["positions"])
        names = [str(x) for x in np.asarray(archive["attribute_names"]).tolist()]
        metadata = {}
        masks = {}
        for key in archive.files:
            if key.startswith("mask_"):
                name = key[5:]
                value = np.asarray(archive[key], dtype=bool)
                if value.shape != (samples.shape[0],):
                    raise ValueError(f"样本mask形状错误：{key}={value.shape}")
                masks[name] = value
        if "metadata" in archive.files:
            raw = np.asarray(archive["metadata"]).item()
            if raw:
                metadata = json.loads(str(raw))
        if "normalization" not in metadata and {"normalization_center", "normalization_scale"}.issubset(archive.files):
            method = "zscore"
            if "normalization_method" in archive.files:
                method = str(np.asarray(archive["normalization_method"]).item())
            metadata["normalization"] = {
                "method": method,
                "center": np.asarray(archive["normalization_center"], dtype=np.float32).tolist(),
                "scale": np.asarray(archive["normalization_scale"], dtype=np.float32).tolist(),
            }
            for key in ("lower", "upper"):
                archive_key = f"normalization_{key}"
                if archive_key in archive.files:
                    metadata["normalization"][key] = np.asarray(
                        archive[archive_key], dtype=np.float32
                    ).tolist()
    samples, positions, names = validate_bundle(samples, positions, names)
    return {
        "samples": samples,
        "positions": positions,
        "attribute_names": names,
        "metadata": metadata,
        "masks": masks,
        "path": str(path.resolve()),
    }
