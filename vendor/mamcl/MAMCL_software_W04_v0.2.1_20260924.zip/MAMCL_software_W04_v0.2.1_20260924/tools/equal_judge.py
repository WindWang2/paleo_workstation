import numpy as np


def equal_or_not(positions_1, positions_2):
    positions_1 = np.asarray(positions_1)
    positions_2 = np.asarray(positions_2)
    aligned = np.array_equal(positions_1, positions_2)
    if not aligned:
        raise ValueError("position的空间位置不一致")
    return True
