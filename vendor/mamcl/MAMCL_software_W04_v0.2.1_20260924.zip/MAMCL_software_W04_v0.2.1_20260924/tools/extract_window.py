import numpy as np


def _horizon_map(horizon, spatial_shape):
    horizon = np.asarray(horizon, dtype=np.float64)
    if horizon.ndim == 0:
        return np.full(spatial_shape, float(horizon), dtype=np.float64)
    if horizon.shape != spatial_shape:
        raise ValueError(
            f"horizon shape必须是{spatial_shape}，实际为{horizon.shape}"
        )
    return horizon


def _stride_pair(stride):
    if isinstance(stride, (int, np.integer)):
        if stride <= 0:
            raise ValueError("stride必须大于0")
        return int(stride), int(stride)
    if len(stride) != 2 or any(int(value) <= 0 for value in stride):
        raise ValueError("stride必须是正整数或两个正整数")
    return int(stride[0]), int(stride[1])


def extract_window(volume, inline, crossline, center, window, sampling="integer"):
    volume = np.asarray(volume)
    if volume.ndim != 3:
        raise ValueError(f"volume必须是三维数组，实际为{volume.ndim}维")
    if window < 0:
        raise ValueError("window不能小于0")
    if sampling not in {"integer", "linear"}:
        raise ValueError("sampling必须是integer或linear")

    offsets = np.arange(-window, window + 1, dtype=np.float64)
    indices = float(center) + offsets
    if indices[0] < 0 or indices[-1] >= volume.shape[2]:
        raise ValueError("窗口超出垂向范围")

    if sampling == "integer":
        if not float(center).is_integer():
            raise ValueError("integer取样要求center为整数")
        return volume[
            int(inline),
            int(crossline),
            indices.astype(np.int64),
        ]

    vertical_axis = np.arange(volume.shape[2], dtype=np.float64)
    return np.interp(
        indices,
        vertical_axis,
        volume[int(inline), int(crossline), :],
    ).astype(np.float32)


def extract_windows(
    volume,
    horizon,
    window=8,
    stride=1,
    sampling="integer",
    inline_slice=None,
    crossline_slice=None,
    skip_invalid_horizon=False,
):
    volume = np.asarray(volume)
    if volume.ndim != 3:
        raise ValueError(f"volume必须是三维数组，实际为{volume.ndim}维")
    if not np.isfinite(volume).all():
        raise ValueError("volume包含NaN或Inf")

    n_inline, n_crossline, _ = volume.shape
    horizon_map = _horizon_map(
        horizon,
        (n_inline, n_crossline),
    )
    if not skip_invalid_horizon and not np.isfinite(horizon_map).all():
        raise ValueError("horizon包含NaN或Inf")
    if sampling == "integer":
        finite_horizon = np.isfinite(horizon_map)
        if finite_horizon.any() and not np.allclose(
            horizon_map[finite_horizon],
            np.round(horizon_map[finite_horizon]),
        ):
            raise ValueError("integer取样要求horizon为整数采样点")

    inline_start, inline_stop = inline_slice or (0, n_inline)
    crossline_start, crossline_stop = crossline_slice or (0, n_crossline)
    if not (0 <= inline_start < inline_stop <= n_inline):
        raise ValueError("inline_slice超出范围")
    if not (0 <= crossline_start < crossline_stop <= n_crossline):
        raise ValueError("crossline_slice超出范围")

    inline_step, crossline_step = _stride_pair(stride)
    samples = []
    positions = []

    for inline in range(inline_start, inline_stop, inline_step):
        for crossline in range(
            crossline_start,
            crossline_stop,
            crossline_step,
        ):
            center = horizon_map[inline, crossline]
            if not np.isfinite(center):
                if skip_invalid_horizon:
                    continue
                raise ValueError("horizon包含NaN或Inf")
            try:
                sample = extract_window(
                    volume,
                    inline,
                    crossline,
                    center,
                    window,
                    sampling=sampling,
                )
            except ValueError as error:
                if str(error) == "窗口超出垂向范围":
                    continue
                raise
            samples.append(sample)
            positions.append([inline, crossline])

    if not samples:
        raise ValueError("没有成功提取任何窗口")

    samples = np.asarray(samples, dtype=np.float32)
    samples = samples[:, None, None, :]
    positions = np.asarray(positions, dtype=np.int64)
    return samples, positions
