from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np


if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import run_all


def _json_value(value):
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    return value


def _finite_range(values):
    values = np.asarray(values)
    finite = np.isfinite(values)
    if not finite.any():
        return None
    finite_values = values[finite].astype(np.float64, copy=False)
    return [float(finite_values.min()), float(finite_values.max())]


def _segy_metadata(paths, iline, xline, strict=False):
    """Read SEG-Y geometry without materialising the cube.

    The normal SEG-Y cube reader requires a perfectly sorted 3-D geometry and
    can allocate many gigabytes.  Preflight only needs trace/sample/header
    metadata, so it deliberately opens with ``ignore_geometry=True`` and
    scans headers one trace at a time.
    """
    try:
        import segyio  # type: ignore
    except ImportError as error:
        return [], None, [f"segyio:{type(error).__name__}: {error}"]
    records = []
    reference = None
    errors = []
    for item in paths:
        path = Path(item)
        record = {"path": str(path), "exists": path.is_file()}
        if not path.is_file():
            records.append(record)
            continue
        try:
            # Preflight must not invoke segyio's 3-D sorting inference.  A
            # valid SEG-Y may be sparse or unsorted while still being usable
            # by the trace-window reader.
            with segyio.open(str(path), strict=False, ignore_geometry=True) as handle:
                samples = np.asarray(handle.samples, dtype=np.float64)
                if samples.size < 2:
                    raise ValueError("SEG-Y垂向采样点少于2个")
                diff = np.diff(samples)
                if not np.allclose(diff, diff[0], rtol=1e-5, atol=1e-6):
                    raise ValueError("SEG-Y垂向采样间隔不均匀")
                inline_min = inline_max = crossline_min = crossline_max = None
                for index in range(int(handle.tracecount)):
                    header = handle.header[index]
                    inline = int(header[int(iline)])
                    crossline = int(header[int(xline)])
                    inline_min = inline if inline_min is None else min(inline_min, inline)
                    inline_max = inline if inline_max is None else max(inline_max, inline)
                    crossline_min = crossline if crossline_min is None else min(crossline_min, crossline)
                    crossline_max = crossline if crossline_max is None else max(crossline_max, crossline)
                trace_count = int(handle.tracecount)
                record.update({
                    "size_bytes": int(path.stat().st_size),
                    "size_gib": float(path.stat().st_size / (1024 ** 3)),
                    "tracecount": trace_count,
                    "sample_count": int(samples.size),
                    "sample_start_interval_last": [float(samples[0]), float(diff[0]), float(samples[-1])],
                    "inline_range": [inline_min, inline_max],
                    "crossline_range": [crossline_min, crossline_max],
                    "iline_field": int(iline),
                    "xline_field": int(xline),
                })
            geometry = (
                int(record["tracecount"]),
                int(record["sample_count"]),
                tuple(record["inline_range"]),
                tuple(record["crossline_range"]),
                tuple(record["sample_start_interval_last"]),
            )
            if reference is None:
                reference = geometry
            elif geometry[1:] != reference[1:]:
                errors.append(str(path))
        except Exception as error:
            record["error"] = f"{type(error).__name__}: {error}"
            errors.append(str(path))
        records.append(record)
    return records, reference, errors


def _environment(input_suffixes=None, interval_mode=False):
    result = {"python": sys.version, "executable": sys.executable, "imports": {}}
    required = (
        "numpy", "torch", "pyzgy", "openzgy", "einops", "scipy",
        "sklearn", "kmeans_pytorch", "matplotlib", "tqdm",
        "transforms3d", "torchvision",
    )
    suffixes = set(input_suffixes or ())
    if not interval_mode and suffixes and suffixes <= {".sgy", ".segy"}:
        required = tuple(name for name in required if name not in {"pyzgy", "openzgy"})
    optional = ("seaborn", "sympy", "cigvis")
    missing = []
    optional_missing = []
    for name in required + optional:
        try:
            module = __import__(name)
            result["imports"][name] = str(getattr(module, "__version__", "available"))
        except Exception as error:
            result["imports"][name] = f"missing: {type(error).__name__}: {error}"
            (missing if name in required else optional_missing).append(name)
    try:
        import torch

        result["cuda_available"] = bool(torch.cuda.is_available())
        result["gpu"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except Exception as error:
        result["cuda_available"] = False
        result["gpu"] = None
        result["cuda_error"] = f"{type(error).__name__}: {error}"
    result["missing_required"] = missing
    result["missing_optional"] = optional_missing
    return result


def _zgy_metadata(paths):
    from zgy_windows import _metadata, _reader, _world_grid

    records = []
    reference = None
    geometry_errors = []
    for item in paths:
        path = Path(item)
        record = {"path": str(path), "exists": path.is_file()}
        if not path.is_file():
            records.append(record)
            continue
        record["size_bytes"] = int(path.stat().st_size)
        record["size_gib"] = float(path.stat().st_size / (1024 ** 3))
        try:
            with _reader(path) as reader:
                metadata = _metadata(reader)
                shape, origin, step, zstart, zinc, zunit = metadata
                record.update(
                    {
                        "shape": list(shape),
                        "inline_origin_step": [float(origin[0]), float(step[0])],
                        "crossline_origin_step": [float(origin[1]), float(step[1])],
                        "sample_start_step_last": [
                            float(zstart), float(zinc),
                            float(zstart + zinc * (shape[2] - 1)),
                        ],
                        "zunit": zunit or "unknown",
                        "datatype": str(getattr(reader, "datatype", "unknown")),
                        "datarange": str(getattr(reader, "datarange", "unknown")),
                    }
                )
                corners = getattr(reader, "corners", None)
                if corners is not None:
                    corners_array = np.asarray(corners, dtype=np.float64)
                    if corners_array.ndim == 2 and corners_array.shape[1] >= 2:
                        record["corners_xy"] = corners_array[:, :2].tolist()
                        record["world_x_range"] = _finite_range(corners_array[:, 0])
                        record["world_y_range"] = _finite_range(corners_array[:, 1])
                preview_shape = (min(shape[0], 2), min(shape[1], 2))
                wx, wy = _world_grid(reader, preview_shape)
                record["world_grid_preview_shape"] = list(wx.shape)
                record["world_grid_x_range"] = _finite_range(wx)
                record["world_grid_y_range"] = _finite_range(wy)
                count = min(shape[2], 8)
                sample = np.asarray(reader.read_subvolume(0, 1, 0, 1, 0, count)).reshape(-1)
                record["trace_preview"] = {
                    "shape": list(sample.shape),
                    "dtype": str(sample.dtype),
                    "finite": bool(np.isfinite(sample).all()),
                    "range": _finite_range(sample),
                }
            if reference is None:
                reference = metadata
            elif metadata[:5] != reference[:5] or metadata[5] != reference[5]:
                geometry_errors.append(str(path))
        except Exception as error:
            record["error"] = f"{type(error).__name__}: {error}"
        records.append(record)
    return records, reference, geometry_errors


def _horizon_metadata(config, reference, first_path, horizon_path=None):
    from read_volume import read_inline_horizon_world, read_smi_axes, read_surface
    from zgy_windows import _interpolate_horizon_to_zgy, _reader, _world_grid

    if horizon_path is None:
        horizon_path = config.HORIZON_FILE
    if horizon_path is None:
        return {"path": None, "exists": False, "error": "HORIZON_FILE为空"}
    path = Path(horizon_path)
    result = {"path": str(path), "exists": path.is_file()}
    if not path.is_file():
        return result
    coordinates = str(getattr(config, "HORIZON_COORDINATES", "inline_crossline")).lower()
    horizon_shape = (
        None
        if bool(getattr(config, "INTERVAL_MODE", False))
        and bool(getattr(config, "HORIZON_CROP_TO_COMMON", False))
        else config.HORIZON_SHAPE
    )
    world_x = world_y = None
    if coordinates == "world":
        surface, world_x, world_y = read_inline_horizon_world(path, shape=horizon_shape)
    else:
        surface = read_surface(
            path,
            shape=horizon_shape,
            dtype=config.HORIZON_DTYPE,
            endian=config.HORIZON_ENDIAN,
            order=config.HORIZON_ORDER,
            key=config.HORIZON_NPZ_KEY,
            allow_invalid=True,
        )
    surface = np.asarray(surface, dtype=np.float64)
    finite = np.isfinite(surface)
    axes = read_smi_axes(path, shape=surface.shape)
    result.update(
        {
            "coordinate_mode": coordinates,
            "shape": list(surface.shape),
            "valid": int(finite.sum()),
            "invalid": int((~finite).sum()),
            "valid_fraction": float(finite.mean()),
            "value_range": _finite_range(surface),
            "axes": list(axes) if axes is not None else None,
        }
    )
    if coordinates == "world":
        result["source_world_x_range"] = _finite_range(world_x)
        result["source_world_y_range"] = _finite_range(world_y)
    target_world_x = target_world_y = None
    if coordinates == "world":
        with _reader(first_path) as reader:
            target_world_x, target_world_y = _world_grid(reader, (2, 2))
        result["target_world_x_range"] = _finite_range(target_world_x)
        result["target_world_y_range"] = _finite_range(target_world_y)
        source_x_range = result["source_world_x_range"]
        source_y_range = result["source_world_y_range"]
        target_x_range = result["target_world_x_range"]
        target_y_range = result["target_world_y_range"]
        result["world_bbox_overlap"] = bool(
            source_x_range and source_y_range and target_x_range and target_y_range
            and source_x_range[1] >= target_x_range[0]
            and target_x_range[1] >= source_x_range[0]
            and source_y_range[1] >= target_y_range[0]
            and target_y_range[1] >= source_y_range[0]
        )
    if (
        bool(getattr(config, "HORIZON_INTERPOLATION", False))
        and not bool(getattr(config, "HORIZON_CROP_TO_COMMON", False))
        and coordinates == "world"
    ):
        target_shape = (reference[0][0], reference[0][1])
        preview_step = max(int(getattr(config, "CHECK_INTERPOLATION_PREVIEW_STEP", 10)), 1)
        preview_shape = (
            max(2, int(np.ceil(target_shape[0] / preview_step))),
            max(2, int(np.ceil(target_shape[1] / preview_step))),
        )
        with _reader(first_path) as reader:
            preview_x, preview_y = _world_grid(reader, preview_shape)
        preview, diagnostics = _interpolate_horizon_to_zgy(
            surface,
            (0.0, 0.0),
            (1.0, 1.0),
            (0.0, 0.0),
            (1.0, 1.0),
            preview_shape,
            method=getattr(config, "HORIZON_INTERPOLATION_METHOD", "linear_nearest"),
            source_world_x=world_x,
            source_world_y=world_y,
            target_world_x=preview_x,
            target_world_y=preview_y,
            max_fill_distance_factor=getattr(config, "HORIZON_MAX_FILL_DISTANCE_FACTOR", 2.0),
            low_confidence_distance_factor=getattr(config, "HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR", 1.0),
            return_diagnostics=True,
        )
        result["interpolation_preview"] = {
            "shape": list(preview.shape),
            "method": getattr(config, "HORIZON_INTERPOLATION_METHOD", "linear_nearest"),
            "linear_cells": int(diagnostics["interpolated_mask"].sum()),
            "nearest_filled_cells": int(diagnostics["nearest_filled_mask"].sum()),
            "unsupported_cells": int(diagnostics["extrapolated_mask"].sum()),
            "low_confidence_cells": int(diagnostics["low_confidence_mask"].sum()),
            "finite_cells": int(np.isfinite(preview).sum()),
            "typical_source_spacing": _json_value(diagnostics["typical_spacing"]),
        }
    elif bool(getattr(config, "HORIZON_CROP_TO_COMMON", False)):
        result["interpolation_preview"] = {
            "skipped": True,
            "reason": "crop_to_common先按上下层位物理网格求交集，再在裁剪区域内填补空洞",
        }
    return result


def _resource_estimate(config, report):
    """Conservative byte estimates for the configurable working sets."""
    records = report.get("zgy", [])
    shape = records[0].get("shape") if records else None
    horizon = report.get("horizon", {})
    if horizon.get("mode") == "interval":
        horizon = horizon.get("upper", {})
    hshape = horizon.get("shape")
    if not shape or len(shape) != 3 or not hshape or len(hshape) != 2:
        return {"available": False}
    stride = getattr(config, "PREDICTION_STRIDE", (1, 1))
    positions = int(np.ceil(int(hshape[0]) / max(int(stride[0]), 1))) * int(
        np.ceil(int(hshape[1]) / max(int(stride[1]), 1))
    )
    positions = max(positions, 1)
    attributes = len(report.get("input_paths", []))
    window_points = 2 * int(getattr(config, "WINDOW", 8)) + 1
    raw_bytes = positions * attributes * window_points * 4
    feature_batch = max(int(getattr(config, "FEATURE_BATCH", 512)), 1)
    batch = max(int(getattr(config, "BATCH_SIZE", 2048)), 1)
    distance_batch = max(int(getattr(config, "DISTANCE_BATCH", 8192)), 1)
    return {
        "available": True,
        "zgy_shape": list(shape),
        "horizon_shape": list(hshape),
        "estimated_prediction_positions": int(positions),
        "attribute_count": int(attributes),
        "window_points": int(window_points),
        "estimated_sample_bundle_bytes": int(raw_bytes),
        "estimated_feature_batch_bytes": int(feature_batch * 64 * 4),
        "estimated_train_batch_bytes": int(batch * attributes * window_points * 4),
        "estimated_distance_batch_bytes": int(distance_batch * 64 * 4),
        "note": "估算只覆盖主要float32数组，不包含模型、CUDA工作区和Python开销",
    }


def main():
    config = run_all.apply_config()
    paths = list(config.INPUT_PATHS)
    suffixes = {Path(path).suffix.lower() for path in paths}
    interval_mode = bool(getattr(config, "INTERVAL_MODE", False))
    report = {
        "run_name": run_all.RUN_NAME,
        "environment": _environment(suffixes, interval_mode),
    }
    failures = []
    if report["environment"]["missing_required"]:
        failures.append("missing_required_dependencies")
    report["input_paths"] = [str(Path(path)) for path in paths]
    if not paths:
        failures.append("no_attributes")
    suffixes = {Path(path).suffix.lower() for path in paths}
    interval_mode = bool(getattr(config, "INTERVAL_MODE", False))
    if len(suffixes) > 1:
        failures.append("mixed_attribute_extensions")
    if suffixes == {".zgy"}:
        zgy_records, reference, geometry_errors = _zgy_metadata(paths)
        report["zgy"] = zgy_records
        if any(not record.get("exists", False) or "error" in record for record in zgy_records):
            failures.append("zgy_open_or_missing")
        if geometry_errors:
            report["zgy_geometry_errors"] = geometry_errors
            failures.append("zgy_geometry_mismatch")
        if reference is None:
            failures.append("no_reference_zgy")
        else:
            report["reference_shape"] = list(reference[0])
            report["reference_origin"] = list(reference[1])
            report["reference_step"] = list(reference[2])
    elif suffixes <= {".sgy", ".segy"} and suffixes:
        if interval_mode:
            failures.append("segy_interval_unsupported")
        segy_records, reference, geometry_errors = _segy_metadata(
            paths,
            getattr(config, "SEGY_INLINE_FIELD", 189),
            getattr(config, "SEGY_CROSSLINE_FIELD", 193),
            getattr(config, "SEGY_STRICT", False),
        )
        report["segy"] = segy_records
        if any(not record.get("exists", False) or "error" in record for record in segy_records):
            failures.append("segy_open_or_missing")
        if geometry_errors:
            report["segy_geometry_errors"] = geometry_errors
            failures.append("segy_geometry_mismatch")
        if reference is None:
            failures.append("no_reference_segy")
        else:
            report["reference_shape"] = [None, None, reference[1]]
            report["reference_tracecount"] = reference[0]
    else:
        failures.append("attribute_extension")
        reference = None
    if not paths:
        failures.append("no_input_paths")
    horizon_paths = (
        [getattr(config, "UPPER_HORIZON_FILE", None), getattr(config, "LOWER_HORIZON_FILE", None)]
        if interval_mode else [config.HORIZON_FILE]
    )
    horizon_paths = [path for path in horizon_paths if path is not None]
    horizon_exists = bool(horizon_paths) and all(Path(path).is_file() for path in horizon_paths)
    if reference is not None and paths and Path(paths[0]).is_file() and horizon_exists:
        horizon_records = []
        for horizon_path in horizon_paths:
            try:
                item = _horizon_metadata(config, reference, paths[0], horizon_path)
                horizon_records.append(item)
                if not item.get("valid", 0):
                    failures.append("no_valid_horizon_points")
                if (
                    getattr(config, "HORIZON_INTERPOLATION", False)
                    and not getattr(config, "HORIZON_CROP_TO_COMMON", False)
                    and not item.get("world_bbox_overlap", True)
                ):
                    failures.append("world_bbox_no_overlap")
            except Exception as error:
                horizon_records.append({"path": str(horizon_path), "error": f"{type(error).__name__}: {error}"})
                failures.append("horizon_check_failed")
        if not interval_mode:
            report["horizon"] = horizon_records[0]
        else:
            report["horizon"] = {
                "mode": "interval",
                "upper": horizon_records[0] if len(horizon_records) > 0 else {"path": str(horizon_paths[0]), "error": "未生成检查记录"},
                "lower": horizon_records[1] if len(horizon_records) > 1 else {"path": str(horizon_paths[1]), "error": "未生成检查记录"},
            }
    else:
        failures.append("horizon_missing_or_no_zgy")
    report["configuration"] = {
        key: _json_value(getattr(config, key))
        for key in (
        "WINDOW", "GAUSSIAN_SIGMA", "TRAIN_STRIDE", "PREDICTION_STRIDE",
            "GAUSSIAN_PEAK_MODE", "INTERVAL_COVERAGE", "INTERVAL_ANCHOR_OFFSET",
            "INTERVAL_PADDING_MODE", "TRAIN_SAFE_ONLY", "KMEANS_SAFE_ONLY",
            "SAMPLING", "NORMALIZE", "HORIZON_UNIT", "HORIZON_SHIFT",
            "INTERVAL_MODE", "UPPER_HORIZON_FILE", "LOWER_HORIZON_FILE",
            "INTERVAL_CENTER_MODE", "INTERVAL_FRACTION", "INTERVAL_MARGIN",
            "INTERVAL_WINDOW_MODE",
            "HORIZON_INTERPOLATION", "HORIZON_INTERPOLATION_METHOD",
            "HORIZON_CROP_TO_COMMON", "HORIZON_FILL_NANS",
            "HORIZON_COORDINATES", "HORIZON_MAX_FILL_DISTANCE_FACTOR",
            "HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR", "CHECK_INTERPOLATION_PREVIEW_STEP",
            "BATCH_SIZE", "EPOCHS",
            "NOISE_STD", "LR", "LR_WARMUP_EPOCHS", "LR_SCHEDULER_T0", "LR_MIN_FACTOR",
            "SEED", "DEVICE",
            "K_SELECTION_ENABLED", "K_SELECTION_MAX_SAMPLES", "K_SELECTION_STABILITY_RUNS",
        )
        if hasattr(config, key)
    }
    report["failures"] = failures
    report["resource_estimate"] = _resource_estimate(config, report)
    report["status"] = "FAIL" if failures else "PASS"
    output_dir = Path(config.RUN_DIR) / "checks"
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "input_check_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=_json_value), encoding="utf-8")
    print("python:", report["environment"]["executable"])
    print("required dependencies:", "PASS" if not report["environment"]["missing_required"] else "FAIL")
    if report["environment"].get("missing_optional"):
        print("optional dependencies:", ", ".join(report["environment"]["missing_optional"]))
    attribute_records = report.get("zgy", report.get("segy", []))
    attribute_label = "ZGY" if "zgy" in report else "SEG-Y"
    print(attribute_label + " attributes:", len(paths), "files")
    for record in attribute_records:
        print(record["path"], record.get("shape", record.get("error", "missing")))
    if "horizon" in report:
        horizon = report["horizon"]
        records = (
            [("upper", horizon["upper"]), ("lower", horizon["lower"])]
            if horizon.get("mode") == "interval" else [("horizon", horizon)]
        )
        for label, item in records:
            print(label + ":", item.get("shape", item.get("error", "unavailable")))
            if "valid" in item:
                print(label + " valid/invalid:", item["valid"], item["invalid"])
                if "interpolation_preview" in item:
                    preview = item["interpolation_preview"]
                    if preview.get("skipped"):
                        print(label + " interpolation preview: skipped (crop_to_common)")
                    else:
                        print(
                            label + " interpolation preview:", preview["shape"],
                            "linear=", preview["linear_cells"],
                            "nearest=", preview["nearest_filled_cells"],
                            "unsupported=", preview["unsupported_cells"],
                        )
    if report["resource_estimate"].get("available"):
        estimate = report["resource_estimate"]
        print(
            "resource estimate: positions=", estimate["estimated_prediction_positions"],
            "sample_bundle_GiB=", round(estimate["estimated_sample_bundle_bytes"] / (1024 ** 3), 3),
            "feature_batch_MiB=", round(estimate["estimated_feature_batch_bytes"] / (1024 ** 2), 3),
        )
    print("report:", report_path.resolve())
    if failures:
        print("FAIL:", ", ".join(failures))
        raise SystemExit(1)
    print("PASS: complete MAMCL input and environment check")


if __name__ == "__main__":
    main()
