from pathlib import Path
import sys

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    if str(TOOLS) not in sys.path:
        sys.path.insert(0, str(TOOLS))

from dataset_io import load_bundle
from mamcl_bridge import choose_device
from run_mamcl import _check


BUNDLE = None
BATCH_SIZE = 4
DEVICE = "auto"


def main():
    if BUNDLE is None:
        raise ValueError("请在check_bundle.py顶部设置BUNDLE")
    bundle = load_bundle(BUNDLE)
    _check(bundle, choose_device(DEVICE), BATCH_SIZE)


if __name__ == "__main__":
    main()
