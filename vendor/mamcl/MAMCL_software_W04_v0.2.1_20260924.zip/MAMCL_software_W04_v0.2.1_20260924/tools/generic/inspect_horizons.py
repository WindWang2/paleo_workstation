from pathlib import Path
import sys

import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from read_volume import (
    read_smi_horizon,
    read_surface,
    read_smi_axes,
    _iter_inline_rows,
    _looks_like_inline_horizon,
    INLINE_INVALID_Z_LIMIT,
)


def _scan_rows(path):
    valid = 0
    malformed = 0
    inline_values = set()
    crossline_values = set()
    z_values = []
    with Path(path).open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            text = line.strip()
            if not text or text.startswith("#"):
                continue
            fields = text.split()
            if len(fields) < 5:
                malformed += 1
                continue
            try:
                z = float(fields[2])
                inline = int(float(fields[3]))
                crossline = int(float(fields[4]))
            except ValueError:
                malformed += 1
                continue
            if not np.isfinite([z, inline, crossline]).all():
                malformed += 1
                continue
            valid += 1
            inline_values.add(inline)
            crossline_values.add(crossline)
            if len(z_values) < 100000:
                z_values.append(z)
    return valid, malformed, inline_values, crossline_values, np.asarray(z_values, dtype=np.float64)


def main():
    if not config.HORIZON_FILES:
        raise ValueError("请先在tools/generic/config.py填写HORIZON_FILES")
    for item in config.HORIZON_FILES:
        path = Path(item)
        if _looks_like_inline_horizon(path):
            rows = list(_iter_inline_rows(path))
            usable = [row for row in rows if np.isfinite(row[0]) and abs(row[0]) <= INLINE_INVALID_Z_LIMIT]
            valid = len(usable)
            malformed = len(rows) - valid
            inline_values = {int(row[1]) for row in rows}
            crossline_values = {int(row[2]) for row in rows}
            z_values = np.asarray([row[0] for row in usable], dtype=np.float64)
            dense = read_surface(path, allow_invalid=True)
        else:
            valid, malformed, inline_values, crossline_values, z_values = _scan_rows(path)
            dense = read_smi_horizon(path)
        finite = np.isfinite(dense)
        print(path.name)
        print("  valid rows:", valid)
        print("  malformed rows:", malformed)
        print("  grid shape:", dense.shape)
        print("  valid grid points:", int(finite.sum()))
        print("  inline range:", min(inline_values), max(inline_values), "count:", len(inline_values))
        print("  crossline range:", min(crossline_values), max(crossline_values), "count:", len(crossline_values))
        if z_values.size:
            print("  z(ms) sample range:", float(z_values.min()), float(z_values.max()))
        print("  axes:", read_smi_axes(path, shape=dense.shape))
        print("  usable complete rows:", malformed == 0)


if __name__ == "__main__":
    main()
