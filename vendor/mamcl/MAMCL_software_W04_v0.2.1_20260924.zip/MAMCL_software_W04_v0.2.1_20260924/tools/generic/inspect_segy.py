from pathlib import Path
import sys

import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config


def main():
    try:
        import segyio
    except ImportError as error:
        raise ImportError("请先安装segyio") from error
    for item in config.INPUT_PATHS:
        path = Path(item)
        print("file:", path)
        with segyio.open(str(path), ignore_geometry=True) as handle:
            print("tracecount:", handle.tracecount)
            print("sample_count:", len(handle.samples))
            print("samples_first_last:", float(handle.samples[0]), float(handle.samples[-1]))
            try:
                print("sample_interval_us:", handle.bin[segyio.BinField.Interval])
            except Exception as error:
                print("sample_interval_us: unavailable", error)
            probe = min(int(handle.tracecount), 500)
            first = dict(handle.header[0])
            keys = sorted(first, key=int)
            print("trace0_nonzero:", {int(k): int(first[k]) for k in keys if first[k] != 0})
            print("varying_fields:")
            for key in keys:
                values = np.asarray([handle.header[index][key] for index in range(probe)])
                unique = np.unique(values)
                if unique.size > 1:
                    print(int(key), int(unique.size), int(values.min()), int(values.max()))


if __name__ == "__main__":
    main()
