from pathlib import Path
import sys

import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))


SEGY_PATH = r""
HEADER_SCAN_TRACES = 5000


def _field_map(enum_type):
    result = {}
    for name in dir(enum_type):
        if name.startswith("_"):
            continue
        try:
            code = int(getattr(enum_type, name))
        except (TypeError, ValueError):
            continue
        result.setdefault(code, name)
    return result


def _number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return value
    if number.is_integer():
        return int(number)
    return number


def _print_text_header(text):
    if isinstance(text, bytes):
        decoded = text.decode("ascii", errors="replace")
    else:
        decoded = str(text)
    print("text_header:")
    for line in decoded.splitlines():
        line = line.rstrip()
        if line:
            print("  " + line)


def _trace_statistics(trace):
    trace = np.asarray(trace)
    finite = np.isfinite(trace)
    result = {
        "dtype": str(trace.dtype),
        "shape": tuple(int(value) for value in trace.shape),
        "finite": int(finite.sum()),
        "nonfinite": int((~finite).sum()),
        "zero": int(np.count_nonzero(trace == 0)),
    }
    if finite.any():
        values = trace[finite].astype(np.float64, copy=False)
        result.update(
            {
                "min": float(values.min()),
                "max": float(values.max()),
                "mean": float(values.mean()),
                "std": float(values.std()),
            }
        )
    return result


def main():
    try:
        import segyio
    except ImportError as error:
        raise ImportError("请先安装segyio") from error

    if not str(SEGY_PATH).strip():
        raise ValueError("请在SEGY_PATH中填写SEG-Y文件路径")
    path = Path(SEGY_PATH)
    if not path.is_file():
        raise FileNotFoundError(path)

    trace_names = _field_map(segyio.TraceField)
    binary_names = _field_map(segyio.BinField)
    print("file:", path.resolve())
    print("file_size_bytes:", path.stat().st_size)
    print("file_size_gib:", path.stat().st_size / (1024 ** 3))
    print("segyio_version:", getattr(segyio, "__version__", "unknown"))

    with segyio.open(str(path), ignore_geometry=True) as handle:
        trace_count = int(handle.tracecount)
        sample_count = int(len(handle.samples))
        print("tracecount:", trace_count)
        print("sample_count:", sample_count)
        print("samples_first_last:", float(handle.samples[0]), float(handle.samples[-1]))
        print("sample_interval_us:", _number(handle.bin[segyio.BinField.Interval]))
        print("sample_axis:", np.asarray(handle.samples, dtype=np.float64))

        try:
            print("sorting_code:", _number(handle.bin[segyio.BinField.SortingCode]))
        except Exception:
            print("sorting_code: unavailable")
        try:
            print("format_code:", _number(handle.bin[segyio.BinField.Format]))
        except Exception:
            print("format_code: unavailable")
        try:
            print("fixed_length_trace_flag:", _number(handle.bin[segyio.BinField.FixedLengthTraceFlag]))
        except Exception:
            print("fixed_length_trace_flag: unavailable")
        try:
            print("extended_text_headers:", int(handle.ext_headers))
        except Exception:
            print("extended_text_headers: unavailable")

        try:
            print("inline_geometry:", np.asarray(handle.ilines))
            print("crossline_geometry:", np.asarray(handle.xlines))
        except Exception as error:
            print("geometry: unavailable", type(error).__name__, error)

        try:
            _print_text_header(handle.text[0])
        except Exception as error:
            print("text_header: unavailable", type(error).__name__, error)

        first_header = dict(handle.header[0])
        print("trace0_header_field_count:", len(first_header))
        print("trace0_header:")
        for key in sorted(first_header, key=lambda item: int(item)):
            code = int(key)
            print(f"  {code} {trace_names.get(code, 'UNKNOWN')}: {_number(first_header[key])}")

        if trace_count:
            if HEADER_SCAN_TRACES is None:
                probe_indices = np.arange(trace_count, dtype=np.int64)
                print("header_scan_mode: all traces")
            else:
                probe_count = min(trace_count, max(int(HEADER_SCAN_TRACES), 1))
                probe_indices = np.linspace(0, trace_count - 1, probe_count, dtype=np.int64)
                probe_indices = np.unique(probe_indices)
                print("header_scan_mode: evenly spaced sample")
            print("header_scan_traces:", int(probe_indices.size))
            print("header_field_statistics:")
            for key in sorted(first_header, key=lambda item: int(item)):
                code = int(key)
                values = np.asarray([handle.header[int(index)][key] for index in probe_indices])
                finite = np.isfinite(values) if np.issubdtype(values.dtype, np.number) else np.ones(values.shape, dtype=bool)
                numeric = values[finite]
                if numeric.size:
                    unique_count = int(np.unique(numeric).size)
                    print(
                        f"  {code} {trace_names.get(code, 'UNKNOWN')}: "
                        f"min={_number(numeric.min())} max={_number(numeric.max())} "
                        f"unique_in_scan={unique_count}"
                    )

            trace_indices = sorted({0, trace_count // 2, trace_count - 1})
            print("trace_sample_statistics:")
            for index in trace_indices:
                print(f"  trace={index} {_trace_statistics(handle.trace[index])}")

        print("binary_header_fields:")
        try:
            binary_header = dict(handle.bin)
            for key in sorted(binary_header, key=lambda item: int(item)):
                code = int(key)
                print(f"  {code} {binary_names.get(code, 'UNKNOWN')}: {_number(binary_header[key])}")
        except Exception as error:
            print("  unavailable:", type(error).__name__, error)

    print("PASS: SEG-Y metadata and sampled header/data inspection")


if __name__ == "__main__":
    main()
