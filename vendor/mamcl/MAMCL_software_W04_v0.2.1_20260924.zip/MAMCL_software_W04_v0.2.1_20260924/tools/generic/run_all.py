from pathlib import Path
import argparse
import json
import shutil
import time
import os
from datetime import datetime
import sys


RESOURCE_ROOT = Path(os.environ.get(
    "MAMCL_RESOURCE_ROOT",
    getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]),
))
ROOT = Path(os.environ.get(
    "MAMCL_APP_ROOT",
    Path(__file__).resolve().parents[2],
))
OUTPUT_ROOT = ROOT / "runs"
TOOLS = RESOURCE_ROOT / "tools"
GENERIC = TOOLS / "generic"
for path in (GENERIC, TOOLS):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


PACKAGE_VERSION = 'MAMCL_software_W04_20260923'
RUN_NAME = 'mamcl_run'

RUN_TIMESTAMP = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
INPUT_PATHS = []
INTERVAL_MODE = True

HORIZON_FILE = None

UPPER_HORIZON_FILE = None

LOWER_HORIZON_FILE = None

INTERVAL_FRACTION = 0.25

INTERVAL_MARGIN = 1.0
INTERVAL_CENTER_MODE = 'fraction'

INTERVAL_WINDOW_MODE = 'fixed'

INTERVAL_COVERAGE = 0.90
INTERVAL_ANCHOR_OFFSET = 1.0
INTERVAL_PADDING_MODE = "edge"
HORIZON = None
WINDOW = 8

GAUSSIAN_SIGMA = 1.5
GAUSSIAN_PEAK_MODE = "center"
HORIZON_SHIFT = 0.0
HORIZON_UNIT = "ms"
TRAIN_STRIDE = (4, 4)

PREDICTION_STRIDE = (1, 1)

SAMPLING = "linear"
NORMALIZE = 'per_attribute'

DILATED_CONV_DILATIONS = (1, 2, 3)


SEGY_INLINE_FIELD = 9
SEGY_CROSSLINE_FIELD = 21
SEGY_SOURCE_X_FIELD = 73
SEGY_SOURCE_Y_FIELD = 77
SEGY_COORDINATE_SCALAR_FIELD = 71
SEGY_STRICT = True
SEGY_AXES = None
VOLUME_SHAPE = None
VOLUME_DTYPE = "float32"
VOLUME_ENDIAN = "native"
VOLUME_ORDER = "C"
VOLUME_NPZ_KEY = None
HORIZON_SHAPE = None
HORIZON_DTYPE = "float32"
HORIZON_ENDIAN = "native"
HORIZON_ORDER = "C"
HORIZON_NPZ_KEY = None
HORIZON_SCALE = 1.0
HORIZON_OFFSET = 0.0
SKIP_INVALID_HORIZON = True

BATCH_SIZE = 2048

EPOCHS = 20

NOISE_STD = 0.1

LR = 0.2

LR_WARMUP_EPOCHS = 10
LR_SCHEDULER_T0 = 500
LR_MIN_FACTOR = 0.25
DCL_TOPK = 0
DCL_POSITION_WEIGHTING = False
SPATIAL_CONSISTENCY_ENABLED = True

SPATIAL_CONSISTENCY_WEIGHT = 0.03

SPATIAL_CONSISTENCY_NEIGHBORS = 4
SPATIAL_CONSISTENCY_DISTANCE_SCALE = 16.0
NUM_WORKERS = 0
FEATURE_BATCH = 512
CLUSTERS = 4

PREDICTION_CLUSTERS = (3, 4, 5, 6, 7, 8, 9)

K_SELECTION_ENABLED = True
K_SELECTION_MAX_SAMPLES = 5000
K_SELECTION_STABILITY_RUNS = 5
HORIZON_INTERPOLATION = True

HORIZON_INTERPOLATION_METHOD = 'linear_nearest'

HORIZON_CROP_TO_COMMON = True

HORIZON_FILL_NANS = True

HORIZON_COORDINATES = 'world'

PLOT_COORDINATES = 'world'

HORIZON_MAX_FILL_DISTANCE_FACTOR = 2.0
HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR = 1.0
CHECK_INTERPOLATION_PREVIEW_STEP = 10
SEED = 42

DEVICE = "auto"
SUPPORTED_ATTRIBUTE_SUFFIXES = {".zgy", ".sgy", ".segy"}
SMOOTHING_KERNEL_SIZE = 3

SMOOTHING_ITERATIONS = 1

SMOOTHING_MIN_VOTES = 5

SMOOTHING_COMPONENT_MIN_SIZE = 0

SMOOTHING_COMPONENT_CONNECTIVITY = 8
POSTPROCESS_MODE = "majority_vote"
PROBABILITY_SMOOTHING_SIGMA = 1.0
ANALYSIS_MAX_SAMPLES = 20000
ANALYSIS_MAX_SIMILARITY = 20000
ANALYSIS_EVERY = 5
REUSE_FEATURES = True
TRAIN_SAFE_ONLY = True
KMEANS_SAFE_ONLY = True
SAVE_DISTANCE_MAPS = False
INCLUDE_REVIEW_ARRAYS = False
DISTANCE_BATCH = 8192
KMEANS_MAX_FIT_SAMPLES = 0
CHECKPOINT_INTERVAL = 1
RESUME = None

WELL_CSV_PATH = None

WELL_CSV_ENCODING = "gbk"
WELL_X_COLUMN = "X坐标"
WELL_Y_COLUMN = "Y坐标"
WELL_NAME_COLUMN = "井号"
WELL_MARKER_SIZE = 38.0
WELL_MARKER_COLOR = "#ff00ff"
WELL_MARKER_EDGE_COLOR = "#ffffff"
WELL_MARKER_EDGE_WIDTH = 0.9

CLEAN_RUN_DIR = True
RUN_PREFLIGHT_CHECK = True


WELL_XLSX_PATH = None

WELL_GROUP = '恩平组'

WELL_SEGMENTS = ('一段',)

WELL_SUPERVISION_ENABLED = False

WELL_LOSS_WEIGHT = 0.2

WELL_SIGMA_FACTOR = 0.5

WELL_MIN_WEIGHT = 0.05

WELL_MAX_NEIGHBORS = 3

WELL_MIN_CONFIDENCE = 0.6

WELL_FALLBACK_CSV = True

WELL_FALLBACK_WEIGHT = 0.35

WELL_LABEL_CLASSES = ('delta_plain', 'delta_front', 'shallow_lake', 'deep_lake')

CONFIDENCE_PLOT_ENABLED = True

WELL_DECAY_MODE = 'probability_decay'

def apply_config():
    import config
    run_dir = Path(OUTPUT_ROOT).expanduser().resolve() / RUN_NAME
    config.INPUT_PATHS = list(INPUT_PATHS)
    config.INTERVAL_MODE = bool(INTERVAL_MODE)
    config.HORIZON_FILE = HORIZON_FILE if not INTERVAL_MODE else UPPER_HORIZON_FILE
    config.UPPER_HORIZON_FILE = UPPER_HORIZON_FILE if INTERVAL_MODE else None
    config.LOWER_HORIZON_FILE = LOWER_HORIZON_FILE if INTERVAL_MODE else None
    config.INTERVAL_FRACTION = float(INTERVAL_FRACTION)
    config.INTERVAL_MARGIN = float(INTERVAL_MARGIN)
    config.INTERVAL_CENTER_MODE = str(INTERVAL_CENTER_MODE)
    config.INTERVAL_WINDOW_MODE = str(INTERVAL_WINDOW_MODE)
    config.INTERVAL_COVERAGE = float(INTERVAL_COVERAGE)
    config.INTERVAL_ANCHOR_OFFSET = float(INTERVAL_ANCHOR_OFFSET)
    config.INTERVAL_PADDING_MODE = str(INTERVAL_PADDING_MODE)
    config.HORIZON_FILES = (
        [UPPER_HORIZON_FILE, LOWER_HORIZON_FILE]
        if INTERVAL_MODE else [HORIZON_FILE]
    )
    config.HORIZON = HORIZON
    config.WINDOW = WINDOW
    config.GAUSSIAN_SIGMA = GAUSSIAN_SIGMA
    config.GAUSSIAN_PEAK_MODE = str(GAUSSIAN_PEAK_MODE)
    config.HORIZON_SHIFT = HORIZON_SHIFT
    config.HORIZON_UNIT = HORIZON_UNIT
    config.TRAIN_STRIDE = tuple(TRAIN_STRIDE)
    config.PREDICTION_STRIDE = tuple(PREDICTION_STRIDE)
    config.SAMPLING = SAMPLING
    config.NORMALIZE = NORMALIZE
    config.DILATED_CONV_DILATIONS = tuple(DILATED_CONV_DILATIONS)
    config.SEGY_INLINE_FIELD = SEGY_INLINE_FIELD
    config.SEGY_CROSSLINE_FIELD = SEGY_CROSSLINE_FIELD
    config.SEGY_SOURCE_X_FIELD = SEGY_SOURCE_X_FIELD
    config.SEGY_SOURCE_Y_FIELD = SEGY_SOURCE_Y_FIELD
    config.SEGY_COORDINATE_SCALAR_FIELD = SEGY_COORDINATE_SCALAR_FIELD
    config.SEGY_STRICT = SEGY_STRICT
    config.SEGY_AXES = SEGY_AXES
    config.VOLUME_SHAPE = VOLUME_SHAPE
    config.VOLUME_DTYPE = VOLUME_DTYPE
    config.VOLUME_ENDIAN = VOLUME_ENDIAN
    config.VOLUME_ORDER = VOLUME_ORDER
    config.VOLUME_NPZ_KEY = VOLUME_NPZ_KEY
    config.HORIZON_SHAPE = HORIZON_SHAPE
    config.HORIZON_DTYPE = HORIZON_DTYPE
    config.HORIZON_ENDIAN = HORIZON_ENDIAN
    config.HORIZON_ORDER = HORIZON_ORDER
    config.HORIZON_NPZ_KEY = HORIZON_NPZ_KEY
    config.HORIZON_SCALE = HORIZON_SCALE
    config.HORIZON_OFFSET = HORIZON_OFFSET
    config.SKIP_INVALID_HORIZON = SKIP_INVALID_HORIZON
    config.BATCH_SIZE = BATCH_SIZE
    config.EPOCHS = EPOCHS
    config.NOISE_STD = NOISE_STD
    config.LR = LR
    config.LR_WARMUP_EPOCHS = int(LR_WARMUP_EPOCHS)
    config.LR_SCHEDULER_T0 = int(LR_SCHEDULER_T0)
    config.LR_MIN_FACTOR = float(LR_MIN_FACTOR)
    config.DCL_TOPK = int(DCL_TOPK)
    config.DCL_POSITION_WEIGHTING = bool(DCL_POSITION_WEIGHTING)
    config.SPATIAL_CONSISTENCY_ENABLED = bool(SPATIAL_CONSISTENCY_ENABLED)
    config.SPATIAL_CONSISTENCY_WEIGHT = float(SPATIAL_CONSISTENCY_WEIGHT)
    config.SPATIAL_CONSISTENCY_NEIGHBORS = int(SPATIAL_CONSISTENCY_NEIGHBORS)
    config.SPATIAL_CONSISTENCY_DISTANCE_SCALE = float(SPATIAL_CONSISTENCY_DISTANCE_SCALE)
    config.NUM_WORKERS = NUM_WORKERS
    config.FEATURE_BATCH = FEATURE_BATCH
    config.CLUSTERS = CLUSTERS
    config.PREDICTION_CLUSTERS = tuple(PREDICTION_CLUSTERS)
    config.K_SELECTION_ENABLED = bool(K_SELECTION_ENABLED)
    config.K_SELECTION_MAX_SAMPLES = int(K_SELECTION_MAX_SAMPLES)
    config.K_SELECTION_STABILITY_RUNS = int(K_SELECTION_STABILITY_RUNS)
    config.HORIZON_INTERPOLATION = bool(HORIZON_INTERPOLATION)
    config.HORIZON_INTERPOLATION_METHOD = str(HORIZON_INTERPOLATION_METHOD)
    config.HORIZON_CROP_TO_COMMON = bool(HORIZON_CROP_TO_COMMON)
    config.HORIZON_FILL_NANS = bool(HORIZON_FILL_NANS)
    config.HORIZON_COORDINATES = str(HORIZON_COORDINATES)
    config.PLOT_COORDINATES = str(PLOT_COORDINATES)
    config.HORIZON_MAX_FILL_DISTANCE_FACTOR = float(HORIZON_MAX_FILL_DISTANCE_FACTOR)
    config.HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR = float(HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR)
    config.CHECK_INTERPOLATION_PREVIEW_STEP = int(CHECK_INTERPOLATION_PREVIEW_STEP)
    config.SEED = SEED
    config.DEVICE = DEVICE
    config.ANALYSIS_MAX_SAMPLES = ANALYSIS_MAX_SAMPLES
    config.ANALYSIS_MAX_SIMILARITY = ANALYSIS_MAX_SIMILARITY
    config.REUSE_FEATURES = REUSE_FEATURES
    config.TRAIN_SAFE_ONLY = bool(TRAIN_SAFE_ONLY)
    config.KMEANS_SAFE_ONLY = bool(KMEANS_SAFE_ONLY)
    config.SAVE_DISTANCE_MAPS = SAVE_DISTANCE_MAPS
    config.INCLUDE_REVIEW_ARRAYS = bool(INCLUDE_REVIEW_ARRAYS)
    config.DISTANCE_BATCH = DISTANCE_BATCH
    config.KMEANS_MAX_FIT_SAMPLES = int(KMEANS_MAX_FIT_SAMPLES)
    config.ANALYSIS_EVERY = ANALYSIS_EVERY
    config.CHECKPOINT_INTERVAL = CHECKPOINT_INTERVAL
    config.RESUME = RESUME
    config.SMOOTHING_KERNEL_SIZE = int(SMOOTHING_KERNEL_SIZE)
    config.SMOOTHING_ITERATIONS = int(SMOOTHING_ITERATIONS)
    config.SMOOTHING_MIN_VOTES = None if SMOOTHING_MIN_VOTES is None else int(SMOOTHING_MIN_VOTES)
    config.SMOOTHING_COMPONENT_MIN_SIZE = int(SMOOTHING_COMPONENT_MIN_SIZE)
    config.SMOOTHING_COMPONENT_CONNECTIVITY = int(SMOOTHING_COMPONENT_CONNECTIVITY)
    config.POSTPROCESS_MODE = str(POSTPROCESS_MODE)
    config.PROBABILITY_SMOOTHING_SIGMA = float(PROBABILITY_SMOOTHING_SIGMA)
    config.WELL_CSV_PATH = WELL_CSV_PATH
    config.WELL_CSV_ENCODING = WELL_CSV_ENCODING
    config.WELL_X_COLUMN = WELL_X_COLUMN
    config.WELL_Y_COLUMN = WELL_Y_COLUMN
    config.WELL_NAME_COLUMN = WELL_NAME_COLUMN
    config.WELL_MARKER_SIZE = WELL_MARKER_SIZE
    config.WELL_MARKER_COLOR = WELL_MARKER_COLOR
    config.WELL_MARKER_EDGE_COLOR = WELL_MARKER_EDGE_COLOR
    config.WELL_MARKER_EDGE_WIDTH = WELL_MARKER_EDGE_WIDTH
    config.WELL_XLSX_PATH = WELL_XLSX_PATH
    config.WELL_GROUP = WELL_GROUP
    config.WELL_SEGMENTS = tuple(WELL_SEGMENTS)
    config.WELL_SUPERVISION_ENABLED = bool(WELL_SUPERVISION_ENABLED)
    config.WELL_LOSS_WEIGHT = float(WELL_LOSS_WEIGHT)
    config.WELL_DECAY_MODE = str(WELL_DECAY_MODE)
    config.WELL_SIGMA_FACTOR = float(WELL_SIGMA_FACTOR)
    config.WELL_MIN_WEIGHT = float(WELL_MIN_WEIGHT)
    config.WELL_MAX_NEIGHBORS = int(WELL_MAX_NEIGHBORS)
    config.WELL_MIN_CONFIDENCE = float(WELL_MIN_CONFIDENCE)
    config.WELL_FALLBACK_CSV = bool(WELL_FALLBACK_CSV)
    config.WELL_FALLBACK_WEIGHT = float(WELL_FALLBACK_WEIGHT)
    config.WELL_LABEL_CLASSES = tuple(WELL_LABEL_CLASSES)
    config.CONFIDENCE_PLOT_ENABLED = bool(CONFIDENCE_PLOT_ENABLED)
    config.RUN_DIR = run_dir
    config.TRAIN_BUNDLE = ROOT / "derived" / f"{RUN_NAME}_train_samples.npz"
    config.PREDICTION_BUNDLE = ROOT / "derived" / f"{RUN_NAME}_prediction_samples.npz"
    return config


def save_run_settings(config):
    config.RUN_DIR.mkdir(parents=True, exist_ok=True)
    settings = {
        key: value
        for key, value in globals().items()
        if key.isupper() and key not in {"ROOT", "TOOLS", "GENERIC"}
    }
    settings.update(
        {
            "TRAIN_BUNDLE": str(config.TRAIN_BUNDLE),
            "PREDICTION_BUNDLE": str(config.PREDICTION_BUNDLE),
            "RUN_DIR": str(config.RUN_DIR),
        }
    )
    with (config.RUN_DIR / "run_all_settings.json").open("w", encoding="utf-8") as handle:
        json.dump(settings, handle, ensure_ascii=False, indent=2, default=str)


def _parse_args(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--from-step", type=int, default=0, help="从指定步骤开始续跑")
    args = parser.parse_args(argv)
    if args.from_step not in {0, 1, 2, 3, 4, 5, 6, 7}:
        raise ValueError("--from-step必须是0到7之间的步骤编号")
    return args


def main(argv=None):
    args = _parse_args(argv)
    if not INPUT_PATHS:
        raise ValueError("至少需要提供1个属性文件（.zgy、.sgy或.segy）")
    if WELL_CSV_PATH is not None:
        from well_supervision import validate_well_csv
        validate_well_csv(WELL_CSV_PATH, WELL_CSV_ENCODING)
    if bool(WELL_SUPERVISION_ENABLED):
        missing_well_files = [
            f"{kind}:{path}" for kind, path in (("CSV", WELL_CSV_PATH), ("XLSX", WELL_XLSX_PATH))
            if path is None or not Path(path).is_file()
        ]
        if missing_well_files:
            raise FileNotFoundError(
                "已启用井约束，但井位/层位覆盖文件不存在：" + ", ".join(missing_well_files)
                + "；请修改WELL_CSV_PATH和WELL_XLSX_PATH，或关闭WELL_SUPERVISION_ENABLED"
            )
        if WELL_LOSS_WEIGHT < 0:
            raise ValueError("WELL_LOSS_WEIGHT不能小于0")
        if WELL_SIGMA_FACTOR <= 0 or WELL_MIN_WEIGHT < 0 or WELL_MAX_NEIGHBORS < 1:
            raise ValueError("井约束参数无效：WELL_SIGMA_FACTOR>0、WELL_MIN_WEIGHT>=0、WELL_MAX_NEIGHBORS>=1")
        if not 0.0 <= WELL_MIN_WEIGHT <= 1.0 or not 0.0 <= WELL_MIN_CONFIDENCE <= 1.0 or not 0.0 <= WELL_FALLBACK_WEIGHT <= 1.0:
            raise ValueError("井权重、置信度及备用权重必须在0到1之间")
        from well_supervision import validate_well_inputs
        well_qc = validate_well_inputs(
            WELL_CSV_PATH,
            WELL_XLSX_PATH,
            WELL_CSV_ENCODING,
            group=WELL_GROUP,
            segments=WELL_SEGMENTS,
        )
        print("well input QC:", json.dumps(well_qc, ensure_ascii=False, sort_keys=True))
    if POSTPROCESS_MODE not in {"none", "majority_vote", "probability_smoothing"}:
        raise ValueError("POSTPROCESS_MODE必须是none、majority_vote或probability_smoothing")
    if PROBABILITY_SMOOTHING_SIGMA <= 0:
        raise ValueError("PROBABILITY_SMOOTHING_SIGMA必须大于0")
    if SMOOTHING_ITERATIONS < 0:
        raise ValueError("SMOOTHING_ITERATIONS不能小于0")
    if SMOOTHING_MIN_VOTES is not None and not 1 <= int(SMOOTHING_MIN_VOTES) <= int(SMOOTHING_KERNEL_SIZE) ** 2:
        raise ValueError("SMOOTHING_MIN_VOTES必须在1到平滑核像素数之间")
    unsupported = [path for path in INPUT_PATHS if Path(path).suffix.lower() not in SUPPORTED_ATTRIBUTE_SUFFIXES]
    if unsupported:
        raise ValueError(
            "属性文件格式不支持：" + ", ".join(str(path) for path in unsupported)
            + "；当前独立包支持 .zgy/.sgy/.segy"
        )
    suffixes = {Path(path).suffix.lower() for path in INPUT_PATHS}
    if INTERVAL_MODE and suffixes != {".zgy"}:
        raise ValueError("层间模式要求所有属性体使用.zgy；单层位模式才支持SEG-Y")
    if INTERVAL_MODE:
        if UPPER_HORIZON_FILE is None or LOWER_HORIZON_FILE is None:
            raise ValueError("层间模式必须同时提供UPPER_HORIZON_FILE和LOWER_HORIZON_FILE")
        horizon_files = (UPPER_HORIZON_FILE, LOWER_HORIZON_FILE)
    elif HORIZON_FILE is None and HORIZON is None:
        raise ValueError("HORIZON_FILE和HORIZON不能同时为None")
    else:
        horizon_files = (HORIZON_FILE,) if HORIZON_FILE is not None else ()
    non_dat_horizons = [str(path) for path in horizon_files if Path(path).suffix.lower() != ".dat"]
    if non_dat_horizons:
        raise ValueError("层位文件必须使用.dat格式：" + ", ".join(non_dat_horizons))
    if DCL_TOPK < 0 or DCL_TOPK >= BATCH_SIZE:
        raise ValueError("DCL_TOPK必须在[0, BATCH_SIZE)范围内")
    config = apply_config()
    if RESUME is not None and CLEAN_RUN_DIR and args.from_step == 0:
        raise ValueError("RESUME不应与CLEAN_RUN_DIR同时启用")
    if args.from_step > 0:
        if not config.RUN_DIR.exists():
            raise FileNotFoundError(f"续跑目录不存在：{config.RUN_DIR}")
        if args.from_step >= 5:
            required = (config.RUN_DIR / "checkpoint.pt", config.PREDICTION_BUNDLE)
            missing = [str(path) for path in required if not path.exists()]
            if missing:
                raise FileNotFoundError("从step05续跑需要已有checkpoint和预测样本：" + ", ".join(missing))
        print(f"resume mode: from step {args.from_step}; preserve existing run directory")
    elif CLEAN_RUN_DIR and config.RUN_DIR.exists():
        shutil.rmtree(config.RUN_DIR)
    save_run_settings(config)
    from result_io import capture_log
    import step08_collect_results
    step_modules = (
        "step00_check_environment", "step00_check_data", "step01_prepare",
        "step02_check", "step03_train", "step04_prepare_prediction",
        "step05_cluster", "step05_select_k", "step06_visualize", "step07_replot_analysis",
    )
    step_start_index = {0: 0, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 8, 7: 9}[args.from_step]
    steps = step_modules[step_start_index:]
    log_path = config.RUN_DIR / ("run_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".log")
    collection_completed = False
    final_archive = None
    try:
        with capture_log(log_path):
            if RUN_PREFLIGHT_CHECK and args.from_step == 0:
                import check_all
                check_all.main()
            for module_name in steps:
                started = time.perf_counter()
                print(f"===== {module_name} =====")
                result = __import__(module_name).main()
                if module_name == "step08_collect_results":
                    collection_completed = True
                    final_archive = result
                print(f"{module_name} seconds={time.perf_counter()-started:.3f}")
            print("ALL STEPS PASSED")
    finally:
        # step08 already writes the summary and creates the review archive.
        # If an earlier step fails, still create a partial diagnostic archive
        # once so that the failure can be inspected.
        if not collection_completed:
            summary_log = config.RUN_DIR / "step08_collect_results.log"
            from result_io import capture_log as capture_summary_log
            with capture_summary_log(summary_log):
                final_archive = step08_collect_results.main()
        if final_archive is not None:
            print("final review archive:", Path(final_archive).resolve())


if __name__ == "__main__":
    main()
