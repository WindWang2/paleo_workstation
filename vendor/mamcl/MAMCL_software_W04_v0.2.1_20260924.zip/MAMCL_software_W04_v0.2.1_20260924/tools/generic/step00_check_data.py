from pathlib import Path
import sys

import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from read_volume import read_inline_horizon_world, read_smi_axes, read_surface
from zgy_windows import (
    _axis_index,
    _crop_and_fill_interval_surfaces,
    _interpolate_horizon_to_zgy,
    _interval_center,
    _interval_window,
    _metadata,
    _reader,
    _world_grid,
    _vertical_indices,
)


def _check_single_segy(paths):
    """Lightweight preflight for single-horizon SEG-Y mode.

    SEG-Y is intentionally not converted to a full cube here.  The check
    reads headers and samples metadata only, then verifies that the requested
    horizon/window has at least one valid trace location.
    """
    if bool(getattr(config, "INTERVAL_MODE", False)):
        raise ValueError("SEG-Y层间模式暂不支持；层间模式请使用ZGY属性体")
    if config.HORIZON_FILE is None:
        raise ValueError("SEG-Y单层位模式必须提供HORIZON_FILE")
    try:
        import segyio  # type: ignore
    except ImportError as error:
        raise ImportError("读取SEG-Y需要安装segyio") from error
    from segy_windows import _axis_values, _center_indices

    horizon_path = Path(config.HORIZON_FILE)
    if not horizon_path.is_file():
        raise FileNotFoundError(f"找不到层位文件：{horizon_path}")
    horizon_coordinates = str(getattr(config, "HORIZON_COORDINATES", "inline_crossline")).lower()
    if horizon_coordinates == "world":
        horizon, _, _ = read_inline_horizon_world(horizon_path, shape=config.HORIZON_SHAPE)
    else:
        horizon = read_surface(
            horizon_path,
            shape=config.HORIZON_SHAPE,
            dtype=config.HORIZON_DTYPE,
            endian=config.HORIZON_ENDIAN,
            order=config.HORIZON_ORDER,
            key=config.HORIZON_NPZ_KEY,
            allow_invalid=True,
        )
    horizon = np.asarray(horizon, dtype=np.float64)
    if horizon.ndim != 2:
        raise ValueError(f"SEG-Y层位必须是二维数组，实际shape={horizon.shape}")
    sample_meta = None
    for path in paths:
        path = Path(path)
        if not path.is_file():
            raise FileNotFoundError(f"找不到SEG-Y属性：{path}")
        with segyio.open(
            str(path),
            strict=False,
            ignore_geometry=True,
        ) as handle:
            samples = np.asarray(handle.samples, dtype=np.float64)
            if samples.size < 2 or not np.allclose(np.diff(samples), np.diff(samples)[0], rtol=1e-5, atol=1e-6):
                raise ValueError(f"SEG-Y垂向采样轴无效：{path}")
            current = (int(samples.size), float(samples[0]), float(np.diff(samples)[0]))
            if sample_meta is None:
                sample_meta = current
            elif not np.allclose(current, sample_meta, rtol=1e-5, atol=1e-6):
                raise ValueError(f"属性SEG-Y采样轴不一致：{path}")
            print(path.name)
            print("  tracecount:", int(handle.tracecount))
            print("  sample_count/start/interval:", current)
    axes = _axis_values(
        getattr(config, "SEGY_AXES", None),
        paths[0],
        config.SEGY_INLINE_FIELD,
        config.SEGY_CROSSLINE_FIELD,
        horizon.shape,
    )
    centers = _center_indices(
        horizon,
        sample_meta[1],
        sample_meta[2],
        config.HORIZON_UNIT,
        config.HORIZON_SCALE,
        config.HORIZON_OFFSET,
        config.HORIZON_SHIFT,
    )
    valid = np.isfinite(centers)
    valid &= centers - int(config.WINDOW) >= 0
    valid &= centers + int(config.WINDOW) < sample_meta[0]
    print("horizon:", horizon_path)
    print("  shape:", horizon.shape)
    print("  valid windows:", int(valid.sum()))
    print("  invalid windows:", int((~valid).sum()))
    print("  segy axes:", axes)
    if not valid.any():
        raise ValueError("SEG-Y层位没有可用窗口")
    print(f"PASS: {len(paths)} SEG-Y attributes, horizon axes, units and windows")


def main():
    paths = list(config.INPUT_PATHS)
    if not paths:
        raise ValueError("至少需要1个属性体")
    suffixes = {Path(path).suffix.lower() for path in paths}
    if suffixes <= {".sgy", ".segy"}:
        _check_single_segy(paths)
        return
    if suffixes != {".zgy"}:
        raise ValueError("属性体必须统一为ZGY，或统一为SEG-Y")
    reference = None
    for path in paths:
        path = Path(path)
        if not path.is_file():
            raise FileNotFoundError(f"找不到ZGY属性：{path}")
        with _reader(path) as reader:
            metadata = _metadata(reader)
            print(path.name)
            print("  shape:", metadata[0])
            print("  inline:", metadata[1][0], metadata[2][0])
            print("  crossline:", metadata[1][1], metadata[2][1])
            print("  samples:", metadata[3], metadata[3] + metadata[4] * (metadata[0][2] - 1))
            print("  zunit:", metadata[5] or "unknown")
            print("  datatype:", getattr(reader, "datatype", "unknown"))
            print("  datarange:", getattr(reader, "datarange", "unknown"))
        if reference is None:
            reference = metadata
        elif metadata[:5] != reference[:5] or metadata[5] != reference[5]:
            raise ValueError(f"ZGY几何或垂向轴不一致：{path}")

    horizon_path = Path(config.HORIZON_FILE)
    if not horizon_path.is_file():
        raise FileNotFoundError(f"找不到层位文件：{horizon_path}")
    horizon_coordinates = str(getattr(config, "HORIZON_COORDINATES", "inline_crossline")).lower()
    interval_mode_enabled = bool(getattr(config, "INTERVAL_MODE", False))
    crop_to_common = bool(getattr(config, "HORIZON_CROP_TO_COMMON", False)) and interval_mode_enabled
    horizon_shape = None if crop_to_common else config.HORIZON_SHAPE
    horizon_world_x = None
    horizon_world_y = None
    if horizon_coordinates == "world":
        horizon, horizon_world_x, horizon_world_y = read_inline_horizon_world(
            horizon_path,
            shape=horizon_shape,
        )
        horizon = np.asarray(horizon, dtype=np.float64)
        axes = read_smi_axes(horizon_path, shape=horizon.shape)
    else:
        horizon = np.asarray(
            read_surface(
                horizon_path,
                shape=horizon_shape,
                dtype=config.HORIZON_DTYPE,
                endian=config.HORIZON_ENDIAN,
                order=config.HORIZON_ORDER,
                key=config.HORIZON_NPZ_KEY,
                allow_invalid=bool(getattr(config, "HORIZON_FILL_NANS", False)),
            ),
            dtype=np.float64,
        )
        axes = read_smi_axes(horizon_path, shape=horizon.shape)
    finite = np.isfinite(horizon)
    print("horizon:", horizon_path)
    print("  coordinate mode:", horizon_coordinates)
    print("  shape:", horizon.shape)
    print("  valid:", int(finite.sum()))
    print("  invalid:", int((~finite).sum()))
    print("  axes:", axes)
    if finite.any():
        print("  value range:", float(np.nanmin(horizon)), float(np.nanmax(horizon)))
    if horizon_coordinates == "world":
        print("  source world X range:", float(np.nanmin(horizon_world_x)), float(np.nanmax(horizon_world_x)))
        print("  source world Y range:", float(np.nanmin(horizon_world_y)), float(np.nanmax(horizon_world_y)))
    lower_horizon_world_x = None
    lower_horizon_world_y = None
    lower_axes = None
    alignment_metadata = None
    if interval_mode_enabled:
        lower_path = Path(config.LOWER_HORIZON_FILE)
        if not lower_path.is_file():
            raise FileNotFoundError(f"找不到下层位文件：{lower_path}")
        if horizon_coordinates == "world":
            lower_horizon, lower_horizon_world_x, lower_horizon_world_y = read_inline_horizon_world(
                lower_path,
                shape=horizon_shape,
            )
        else:
            lower_horizon = read_surface(
                lower_path,
                shape=horizon_shape,
                dtype=config.HORIZON_DTYPE,
                endian=config.HORIZON_ENDIAN,
                order=config.HORIZON_ORDER,
                key=config.HORIZON_NPZ_KEY,
                allow_invalid=bool(getattr(config, "HORIZON_FILL_NANS", False) or crop_to_common),
            )
        lower_horizon = np.asarray(lower_horizon, dtype=np.float64)
        lower_axes = read_smi_axes(lower_path, shape=lower_horizon.shape)
        lower_finite = np.isfinite(lower_horizon)
        print("lower horizon:", lower_path)
        print("  shape:", lower_horizon.shape)
        print("  valid:", int(lower_finite.sum()))
        print("  invalid:", int((~lower_finite).sum()))
        if lower_finite.any():
            print("  value range:", float(np.nanmin(lower_horizon)), float(np.nanmax(lower_horizon)))
        if crop_to_common:
            target_world_x = None
            target_world_y = None
            if horizon_coordinates == "world":
                with _reader(paths[0]) as reader:
                    target_world_x, target_world_y = _world_grid(reader, reference[0])
            horizon, lower_horizon, axes, alignment_metadata = _crop_and_fill_interval_surfaces(
                horizon,
                lower_horizon,
                axes,
                lower_axes,
                reference[0],
                reference[1],
                reference[2],
                bool(getattr(config, "HORIZON_FILL_NANS", False)),
                getattr(config, "HORIZON_INTERPOLATION_METHOD", "linear_nearest"),
                getattr(config, "HORIZON_MAX_FILL_DISTANCE_FACTOR", 2.0),
                getattr(config, "HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR", 1.0),
                upper_world_x=horizon_world_x,
                upper_world_y=horizon_world_y,
                lower_world_x=lower_horizon_world_x,
                lower_world_y=lower_horizon_world_y,
                target_world_x=target_world_x,
                target_world_y=target_world_y,
            )
            horizon_coordinates = "inline_crossline"
            horizon_world_x = None
            horizon_world_y = None
            lower_horizon_world_x = None
            lower_horizon_world_y = None
            print("  crop mode:", alignment_metadata["mode"])
            print("  crop index:", alignment_metadata["crop_index"])
            print("  crop shape:", alignment_metadata["crop_shape"])
            print("  upper remaining invalid:", alignment_metadata["upper_remaining_invalid"])
            print("  lower remaining invalid:", alignment_metadata["lower_remaining_invalid"])
        elif lower_horizon.shape != horizon.shape:
            raise ValueError(f"上下层位shape不一致：{horizon.shape} != {lower_horizon.shape}；开启HORIZON_CROP_TO_COMMON可处理不同网格")
    interpolate_horizon = bool(getattr(config, "HORIZON_INTERPOLATION", False)) and not crop_to_common
    if interpolate_horizon:
        target_world_x = None
        target_world_y = None
        if horizon_coordinates == "world":
            with _reader(paths[0]) as reader:
                target_world_x, target_world_y = _world_grid(reader, reference[0])
            print("  target world X range:", float(np.nanmin(target_world_x)), float(np.nanmax(target_world_x)))
            print("  target world Y range:", float(np.nanmin(target_world_y)), float(np.nanmax(target_world_y)))
        interpolation = _interpolate_horizon_to_zgy(
            horizon,
            (axes[0], axes[1]),
            (axes[2], axes[3]),
            (reference[1][0], reference[1][1]),
            (reference[2][0], reference[2][1]),
            reference[0],
            method=getattr(config, "HORIZON_INTERPOLATION_METHOD", "linear_nearest"),
            source_world_x=horizon_world_x,
            source_world_y=horizon_world_y,
            target_world_x=target_world_x,
            target_world_y=target_world_y,
            max_fill_distance_factor=getattr(config, "HORIZON_MAX_FILL_DISTANCE_FACTOR", 2.0),
            low_confidence_distance_factor=getattr(config, "HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR", 1.0),
            return_diagnostics=True,
        )
        horizon, interpolation_diagnostics = interpolation
        if getattr(config, "INTERVAL_MODE", False):
            lower_interpolation = _interpolate_horizon_to_zgy(
                lower_horizon,
                (axes[0], axes[1]),
                (axes[2], axes[3]),
                (reference[1][0], reference[1][1]),
                (reference[2][0], reference[2][1]),
                reference[0],
                method=getattr(config, "HORIZON_INTERPOLATION_METHOD", "linear_nearest"),
                source_world_x=lower_horizon_world_x,
                source_world_y=lower_horizon_world_y,
                target_world_x=target_world_x,
                target_world_y=target_world_y,
                max_fill_distance_factor=getattr(config, "HORIZON_MAX_FILL_DISTANCE_FACTOR", 2.0),
                low_confidence_distance_factor=getattr(config, "HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR", 1.0),
                return_diagnostics=True,
            )
            lower_horizon, lower_interpolation_diagnostics = lower_interpolation
        axes = (
            reference[1][0],
            reference[1][1],
            reference[2][0],
            reference[2][1],
        )
        print("  horizon interpolation:", getattr(config, "HORIZON_INTERPOLATION_METHOD", "linear_nearest"))
        print("  interpolated shape:", horizon.shape)
        print("  linear cells:", int(interpolation_diagnostics["interpolated_mask"].sum()))
        print("  nearest-filled cells:", int(interpolation_diagnostics["nearest_filled_mask"].sum()))
        print("  unsupported cells:", int(interpolation_diagnostics["extrapolated_mask"].sum()))
        print("  low-confidence cells:", int(interpolation_diagnostics["low_confidence_mask"].sum()))
        print("  typical source spacing:", interpolation_diagnostics["typical_spacing"])
    inline_values = axes[0] + np.arange(horizon.shape[0], dtype=np.float64) * axes[2]
    crossline_values = axes[1] + np.arange(horizon.shape[1], dtype=np.float64) * axes[3]
    inline_indices = _axis_index(
        inline_values,
        reference[1][0],
        reference[2][0],
        reference[0][0],
        "inline",
        allow_outside=config.SKIP_INVALID_HORIZON,
    )
    crossline_indices = _axis_index(
        crossline_values,
        reference[1][1],
        reference[2][1],
        reference[0][1],
        "crossline",
        allow_outside=config.SKIP_INVALID_HORIZON,
    )
    centers = _vertical_indices(
        horizon,
        config.HORIZON_UNIT,
        reference[3],
        reference[4],
        reference[5],
    )
    if getattr(config, "INTERVAL_MODE", False):
        lower_centers = _vertical_indices(
            lower_horizon,
            config.HORIZON_UNIT,
            reference[3],
            reference[4],
            reference[5],
        )
        interval_mode = str(getattr(config, "INTERVAL_WINDOW_MODE", "global_min")).lower()
        if interval_mode in {"upper_anchor_coverage", "upper_anchor_down", "downward_coverage"}:
            anchor_offset = float(getattr(config, "INTERVAL_ANCHOR_OFFSET", 0.0))
            margin = float(getattr(config, "INTERVAL_MARGIN", 1.0))
            target_coverage = float(getattr(config, "INTERVAL_COVERAGE", 0.90))
            spatial_valid = (
                (inline_indices[:, None] >= 0)
                & (crossline_indices[None, :] >= 0)
                & (inline_indices[:, None] < reference[0][0])
                & (crossline_indices[None, :] < reference[0][1])
            )
            upper_valid = np.isfinite(centers) & spatial_valid
            matched = upper_valid & np.isfinite(lower_centers)
            denominator = int(matched.sum())
            if denominator <= 0:
                raise ValueError("上下层位没有可用于单向窗口覆盖率检查的匹配位置")
            anchors = centers + anchor_offset
            selected_window = None
            coverage_curve = []
            for span in range(int(config.WINDOW), -1, -1):
                end = anchors + float(span)
                safe = matched & (lower_centers > centers)
                safe &= end <= (lower_centers - margin - 1.0 + 1e-6)
                safe_count = int(safe[matched].sum())
                coverage = safe_count / denominator
                coverage_curve.append((span, coverage, safe_count))
                if selected_window is None and span >= 1 and coverage >= target_coverage:
                    selected_window = span
            if selected_window is None:
                selected_window, selected_coverage, _ = max(
                    coverage_curve, key=lambda item: (item[1], item[0])
                )
                coverage_met = False
            else:
                selected_coverage = next(
                    item[1] for item in coverage_curve if item[0] == selected_window
                )
                coverage_met = True
            valid_centers = upper_valid
            print("  interval window mode:", interval_mode)
            print("  interval anchor offset:", anchor_offset)
            print("  interval target coverage:", target_coverage)
            print("  selected interval span/points:", selected_window, selected_window + 1)
            print("  selected interval coverage:", selected_coverage, "met:", coverage_met)
            print("  matched positions:", denominator)
            print("  valid anchor positions:", int(valid_centers.sum()))
            print("  unsafe positions after forced extraction:", int((valid_centers & ~(
                matched & (lower_centers > centers)
                & (anchors + float(selected_window) <= lower_centers - margin - 1.0 + 1e-6)
            )).sum()))
        else:
            interval_centers, lower_weight = _interval_center(
                centers,
                lower_centers,
                mode=getattr(config, "INTERVAL_CENTER_MODE", "equal"),
                fraction=getattr(config, "INTERVAL_FRACTION", 0.5),
            )
            selected_window, window_grid, valid_centers = _interval_window(
                interval_centers,
                lower_centers,
                reference[0],
                inline_indices,
                crossline_indices,
                config.WINDOW,
                margin=getattr(config, "INTERVAL_MARGIN", 1.0),
                mode=interval_mode,
            )
            print("  interval center mode:", getattr(config, "INTERVAL_CENTER_MODE", "equal"))
            print("  interval lower weight:", lower_weight)
            print("  interval window mode:", interval_mode)
            print("  selected interval window:", selected_window)
            print("  valid windows:", int(valid_centers.sum()))
            print("  rejected windows:", int((~valid_centers).sum()))
    else:
        valid_centers = np.isfinite(centers)
        valid_centers &= inline_indices[:, None] >= 0
        valid_centers &= crossline_indices[None, :] >= 0
        if valid_centers.any():
            valid_centers &= centers >= config.WINDOW
            valid_centers &= centers <= reference[0][2] - 1 - config.WINDOW
        print("  valid windows:", int(valid_centers.sum()))
        print("  rejected windows:", int((~valid_centers).sum()))
    if not config.SKIP_INVALID_HORIZON and not valid_centers.all():
        raise ValueError("层位存在无效或越界窗口，且SKIP_INVALID_HORIZON=False")
    if not valid_centers.any():
        raise ValueError("层位没有可用窗口")
    print(f"PASS: {len(paths)} ZGY attributes, geometry, horizon axes, units and windows")


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
