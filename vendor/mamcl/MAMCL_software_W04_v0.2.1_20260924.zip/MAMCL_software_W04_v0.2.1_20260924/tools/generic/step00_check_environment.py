def main():
    import sys
    print("python:", sys.version)
    try:
        import torch
        print("torch:", torch.__version__)
        print("cuda available:", torch.cuda.is_available())
        if torch.cuda.is_available():
            print("gpu:", torch.cuda.get_device_name(0))
    except ImportError as error:
        print("torch: missing", error)
    for name in (
        "numpy", "sklearn", "matplotlib", "einops", "segyio", "pyzgy", "openzgy",
        "scipy", "transforms3d", "tqdm", "kmeans_pytorch",
        "torchvision", "seaborn",
    ):
        try:
            module = __import__(name)
            print(f"{name}:", getattr(module, "__version__", "available"))
        except ImportError as error:
            print(f"{name}: missing", error)
    try:
        import umap
        print("umap: optional", getattr(umap, "__version__", "available"))
    except ImportError:
        print("umap: optional missing (PCA fallback will be used)")


if __name__ == "__main__":
    from pathlib import Path
    from run_all import apply_config
    config = apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
