from pathlib import Path
import sys
import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from dataset_io import load_bundle
from mamcl_bridge import choose_device, set_seed
from run_mamcl import _check


def main():
    bundle = load_bundle(config.TRAIN_BUNDLE)
    set_seed(config.SEED)
    masks = bundle.get("masks", {})
    if masks:
        print("masks:", {name: int(np.asarray(value, dtype=bool).sum()) for name, value in masks.items()})
    check_batch = min(4, int(bundle["samples"].shape[0]))
    _check(bundle, choose_device(config.DEVICE), check_batch)


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
