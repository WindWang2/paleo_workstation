from pathlib import Path
import sys
from types import SimpleNamespace

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from dataset_io import load_bundle
from mamcl_bridge import choose_device, set_seed
from run_mamcl import _train


def main():
    bundle = load_bundle(config.TRAIN_BUNDLE)
    set_seed(config.SEED)
    args = SimpleNamespace(
        batch_size=config.BATCH_SIZE,
        epochs=config.EPOCHS,
        noise_std=config.NOISE_STD,
        lr=config.LR,
        num_workers=config.NUM_WORKERS,
        output_dir=str(config.RUN_DIR),
        analysis_clusters=config.CLUSTERS,
        analysis_feature_batch=config.FEATURE_BATCH,
        analysis_max_samples=config.ANALYSIS_MAX_SAMPLES,
        analysis_max_similarity=config.ANALYSIS_MAX_SIMILARITY,
        analysis_every=config.ANALYSIS_EVERY,
        checkpoint_interval=config.CHECKPOINT_INTERVAL,
        resume=config.RESUME,
        seed=config.SEED,
        train_safe_only=getattr(config, "TRAIN_SAFE_ONLY", True),
    )
    _train(bundle, args, choose_device(config.DEVICE))


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
