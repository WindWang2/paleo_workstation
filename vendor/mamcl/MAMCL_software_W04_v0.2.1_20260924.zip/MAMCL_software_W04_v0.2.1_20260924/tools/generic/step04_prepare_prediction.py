from pathlib import Path
import sys

import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from mamcl_adapter import prepare_samples, save_samples
from result_io import bundle_metadata


def main():
    if not config.INPUT_PATHS:
        raise ValueError("请先在tools/generic/config.py填写INPUT_PATHS")
    normalization = bundle_metadata(config.TRAIN_BUNDLE)["normalization"]
    samples, positions, volume_shape, stats, masks = prepare_samples(
        config.INPUT_PATHS,
        normalization_stats=normalization,
        shape=config.VOLUME_SHAPE,
        dtype=config.VOLUME_DTYPE,
        endian=config.VOLUME_ENDIAN,
        order=config.VOLUME_ORDER,
        npz_key=config.VOLUME_NPZ_KEY,
        segy_inline_field=config.SEGY_INLINE_FIELD,
        segy_crossline_field=config.SEGY_CROSSLINE_FIELD,
        segy_strict=config.SEGY_STRICT,
        horizon=config.HORIZON,
        window=config.WINDOW,
        stride=config.PREDICTION_STRIDE,
        sampling=config.SAMPLING,
        normalize=config.NORMALIZE,
        horizon_file=config.HORIZON_FILE,
        horizon_shape=config.HORIZON_SHAPE,
        horizon_dtype=config.HORIZON_DTYPE,
        horizon_endian=config.HORIZON_ENDIAN,
        horizon_order=config.HORIZON_ORDER,
        horizon_key=config.HORIZON_NPZ_KEY,
        horizon_scale=config.HORIZON_SCALE,
        horizon_offset=config.HORIZON_OFFSET,
        horizon_shift=config.HORIZON_SHIFT,
        skip_invalid_horizon=config.SKIP_INVALID_HORIZON,
        horizon_unit=config.HORIZON_UNIT,
        segy_axes=config.SEGY_AXES,
        interpolate_horizon=getattr(config, "HORIZON_INTERPOLATION", False),
        interpolation_method=getattr(config, "HORIZON_INTERPOLATION_METHOD", "linear_nearest"),
        horizon_coordinates=getattr(config, "HORIZON_COORDINATES", "inline_crossline"),
        max_fill_distance_factor=getattr(config, "HORIZON_MAX_FILL_DISTANCE_FACTOR", 2.0),
        low_confidence_distance_factor=getattr(config, "HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR", 1.0),
        upper_horizon_file=getattr(config, "UPPER_HORIZON_FILE", None),
        lower_horizon_file=getattr(config, "LOWER_HORIZON_FILE", None),
        crop_to_common=getattr(config, "HORIZON_CROP_TO_COMMON", False),
        fill_horizon_nans=getattr(config, "HORIZON_FILL_NANS", False),
        interval_fraction=getattr(config, "INTERVAL_FRACTION", 0.5),
        interval_margin=getattr(config, "INTERVAL_MARGIN", 1.0),
        interval_center_mode=getattr(config, "INTERVAL_CENTER_MODE", "equal"),
        interval_window_mode=getattr(config, "INTERVAL_WINDOW_MODE", "global_min"),
        interval_coverage=getattr(config, "INTERVAL_COVERAGE", 0.90),
        interval_anchor_offset=getattr(config, "INTERVAL_ANCHOR_OFFSET", 0.0),
        interval_padding_mode=getattr(config, "INTERVAL_PADDING_MODE", "edge"),
        return_masks=True,
        return_normalization=True,
    )
    save_samples(
        config.PREDICTION_BUNDLE,
        samples,
        positions,
        config.INPUT_PATHS,
        volume_shape,
        {
            "purpose": "generic MAMCL dense prediction samples",
            "window": config.WINDOW,
            "stride": list(config.PREDICTION_STRIDE),
            "sampling": config.SAMPLING,
            "normalize": config.NORMALIZE,
            "segy_inline_field": config.SEGY_INLINE_FIELD,
            "segy_crossline_field": config.SEGY_CROSSLINE_FIELD,
            "segy_strict": config.SEGY_STRICT,
            "horizon_file": str(Path(config.HORIZON_FILE).resolve()) if config.HORIZON_FILE else None,
            "horizon_shape": list(config.HORIZON_SHAPE) if config.HORIZON_SHAPE else None,
            "horizon_dtype": config.HORIZON_DTYPE,
            "horizon_endian": config.HORIZON_ENDIAN,
            "horizon_order": config.HORIZON_ORDER,
            "horizon_key": config.HORIZON_NPZ_KEY,
            "horizon_scale": config.HORIZON_SCALE,
            "horizon_offset": config.HORIZON_OFFSET,
            "horizon_shift": config.HORIZON_SHIFT,
            "horizon_unit": config.HORIZON_UNIT,
            "skip_invalid_horizon": config.SKIP_INVALID_HORIZON,
            "interpolate_horizon": getattr(config, "HORIZON_INTERPOLATION", False),
            "interpolation_method": getattr(config, "HORIZON_INTERPOLATION_METHOD", "linear_nearest"),
            "crop_to_common": getattr(config, "HORIZON_CROP_TO_COMMON", False),
            "fill_horizon_nans": getattr(config, "HORIZON_FILL_NANS", False),
            "horizon_coordinates": getattr(config, "HORIZON_COORDINATES", "inline_crossline"),
            "max_fill_distance_factor": getattr(config, "HORIZON_MAX_FILL_DISTANCE_FACTOR", 2.0),
            "low_confidence_distance_factor": getattr(config, "HORIZON_LOW_CONFIDENCE_DISTANCE_FACTOR", 1.0),
            "upper_horizon_file": str(Path(config.UPPER_HORIZON_FILE).resolve()) if getattr(config, "UPPER_HORIZON_FILE", None) else None,
            "lower_horizon_file": str(Path(config.LOWER_HORIZON_FILE).resolve()) if getattr(config, "LOWER_HORIZON_FILE", None) else None,
            "interval_fraction": getattr(config, "INTERVAL_FRACTION", 0.5),
            "interval_margin": getattr(config, "INTERVAL_MARGIN", 1.0),
            "interval_center_mode": getattr(config, "INTERVAL_CENTER_MODE", "equal"),
            "interval_window_mode": getattr(config, "INTERVAL_WINDOW_MODE", "global_min"),
            "interval_coverage": getattr(config, "INTERVAL_COVERAGE", 0.90),
            "interval_anchor_offset": getattr(config, "INTERVAL_ANCHOR_OFFSET", 0.0),
            "interval_padding_mode": getattr(config, "INTERVAL_PADDING_MODE", "edge"),
        },
        normalization_stats=stats,
        masks=masks,
    )
    print("samples shape:", samples.shape)
    print("positions shape:", positions.shape)
    print("finite:", bool(np.isfinite(samples).all()))
    print("output:", Path(config.PREDICTION_BUNDLE).resolve())


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
