from pathlib import Path
import sys
from types import SimpleNamespace

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from dataset_io import load_bundle
from mamcl_bridge import choose_device, set_seed
from run_mamcl import _cluster
from well_overlay import load_well_points


def main():
    bundle = load_bundle(config.PREDICTION_BUNDLE)
    set_seed(config.SEED)
    args = SimpleNamespace(
        checkpoint=str(config.RUN_DIR / "checkpoint.pt"),
        output_dir=str(config.RUN_DIR / "prediction"),
        feature_batch=config.FEATURE_BATCH,
        clusters=getattr(config, "PREDICTION_CLUSTERS", (config.CLUSTERS,)),
        seed=config.SEED,
        reuse_features=config.REUSE_FEATURES,
        save_distance_maps=config.SAVE_DISTANCE_MAPS,
        distance_batch=config.DISTANCE_BATCH,
        kmeans_max_fit_samples=getattr(config, "KMEANS_MAX_FIT_SAMPLES", 0),
        kmeans_safe_only=getattr(config, "KMEANS_SAFE_ONLY", True),
        coordinate_path=config.INPUT_PATHS[0] if getattr(config, "INPUT_PATHS", None) else None,
        coordinate_mode=getattr(config, "PLOT_COORDINATES", getattr(config, "HORIZON_COORDINATES", "world")),
    )
    args.well_points, well_metadata = load_well_points(
        getattr(config, "WELL_CSV_PATH", None),
        encoding=getattr(config, "WELL_CSV_ENCODING", "gbk"),
        x_column=getattr(config, "WELL_X_COLUMN", None),
        y_column=getattr(config, "WELL_Y_COLUMN", None),
        name_column=getattr(config, "WELL_NAME_COLUMN", None),
    )
    args.well_style = {
        "size": getattr(config, "WELL_MARKER_SIZE", 38.0),
        "color": getattr(config, "WELL_MARKER_COLOR", "#ff00ff"),
        "edge_color": getattr(config, "WELL_MARKER_EDGE_COLOR", "#ffffff"),
        "edge_width": getattr(config, "WELL_MARKER_EDGE_WIDTH", 0.9),
        "labels": well_metadata.get("labels", []),
    }
    _cluster(bundle, args, choose_device(config.DEVICE))


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
