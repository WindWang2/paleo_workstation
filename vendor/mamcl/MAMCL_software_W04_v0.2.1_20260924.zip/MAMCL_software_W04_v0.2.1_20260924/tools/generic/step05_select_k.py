from pathlib import Path
import sys

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from k_selection import select_k


def main():
    if not getattr(config, "K_SELECTION_ENABLED", True):
        print("K selection disabled")
        return
    select_k(
        config.RUN_DIR / "prediction" / "features_h.npy",
        config.RUN_DIR / "prediction",
        max_samples=getattr(config, "K_SELECTION_MAX_SAMPLES", 5000),
        seed=config.SEED,
        stability_runs=getattr(config, "K_SELECTION_STABILITY_RUNS", 5),
    )


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
