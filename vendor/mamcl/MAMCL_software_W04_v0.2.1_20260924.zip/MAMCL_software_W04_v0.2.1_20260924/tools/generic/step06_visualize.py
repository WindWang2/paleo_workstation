from pathlib import Path
import sys
import json

import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from attribute_plots import plot_horizon_attribute_slices
from analysis_plots import plot_spatial_attribute_attention
from dataset_io import load_bundle
from plot_coordinates import coordinate_metadata
from plot_styles import cluster_color_metadata, paper_cluster_colors, save_paper_cluster_map
from run_mamcl import _grid_positions, _plot_coordinate_info, _spatial_cluster_metrics
from spatial_postprocess import majority_smooth_labels, probability_smooth_labels, remove_small_components
from well_overlay import load_well_points, scatter_wells


SMOOTHING_KERNEL_SIZE = int(getattr(config, "SMOOTHING_KERNEL_SIZE", 3))
SMOOTHING_ITERATIONS = int(getattr(config, "SMOOTHING_ITERATIONS", 1))
SMOOTHING_MIN_VOTES = getattr(config, "SMOOTHING_MIN_VOTES", 5)
SMOOTHING_COMPONENT_MIN_SIZE = int(getattr(config, "SMOOTHING_COMPONENT_MIN_SIZE", 0))
SMOOTHING_COMPONENT_CONNECTIVITY = int(getattr(config, "SMOOTHING_COMPONENT_CONNECTIVITY", 8))
POSTPROCESS_MODE = str(getattr(config, "POSTPROCESS_MODE", "majority_vote")).lower()
PROBABILITY_SMOOTHING_SIGMA = float(getattr(config, "PROBABILITY_SMOOTHING_SIGMA", 1.0))
CONFIDENCE_PLOT_ENABLED = bool(getattr(config, "CONFIDENCE_PLOT_ENABLED", False))


def _cluster_counts(values, clusters):
    values = np.asarray(values, dtype=np.int64).reshape(-1)
    values = values[(values >= 0) & (values < int(clusters))]
    return np.bincount(values, minlength=int(clusters)).tolist()


def _save_smoothed_maps(grid, clusters, output_dir, coordinate_info, base, unsafe_positions, well_points, well_style, suffix="_smoothed"):
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap

    cmap = ListedColormap(
        paper_cluster_colors(clusters),
        name=f"bright_clusters_{clusters}{suffix}",
    )
    cmap.set_bad("white")
    image = np.ma.masked_equal(grid, -1)
    norm = BoundaryNorm(np.arange(-0.5, clusters + 0.5, 1), clusters)
    label_path = output_dir / f"cluster_map_k{clusters}{suffix}_labels.png"
    figure, axis = plt.subplots(figsize=(11, 8), constrained_layout=True)
    shown = axis.pcolormesh(
        coordinate_info["x"], coordinate_info["y"], image,
        shading="auto", edgecolors="none", linewidth=0.0, antialiased=False, cmap=cmap, norm=norm,
    )
    scatter_wells(
        axis,
        well_points,
        coordinate_info,
        valid_mask=np.asarray(grid) >= 0,
        **dict(well_style or {}),
    )
    axis.set_xlabel(str(coordinate_info.get("xlabel", "X coordinate")))
    axis.set_ylabel(str(coordinate_info.get("ylabel", "Y coordinate")))
    axis.set_aspect("equal", adjustable="box")
    axis.set_title(f"MAMCL postprocessed seismic-facies clusters (K={clusters})")
    figure.colorbar(shown, ax=axis, ticks=np.arange(clusters), label="cluster id")
    figure.savefig(label_path, dpi=220)
    plt.close(figure)

    paper_path = output_dir / f"cluster_map_k{clusters}{suffix}.png"
    bbox = save_paper_cluster_map(
        grid,
        clusters,
        paper_path,
        base=base,
        title=None,
        overlay_alpha=0.82,
        dpi=400,
        coordinates=coordinate_info,
        well_points=well_points,
        well_style=well_style,
    )

    qc_path = output_dir / f"cluster_map_k{clusters}{suffix}_qc.png"
    qc_figure, qc_axis = plt.subplots(figsize=(11, 8), constrained_layout=True)
    qc_shown = qc_axis.pcolormesh(
        coordinate_info["x"], coordinate_info["y"], image,
        shading="auto", edgecolors="none", linewidth=0.0, antialiased=False, cmap=cmap, norm=norm,
    )
    if unsafe_positions.size:
        unsafe_x = coordinate_info["x"][unsafe_positions[:, 0], unsafe_positions[:, 1]]
        unsafe_y = coordinate_info["y"][unsafe_positions[:, 0], unsafe_positions[:, 1]]
        finite = np.isfinite(unsafe_x) & np.isfinite(unsafe_y)
        qc_axis.scatter(
            unsafe_x[finite], unsafe_y[finite],
            s=2, c="black", marker="x", alpha=0.45, linewidths=0.35,
            label="unsafe / padded",
        )
        qc_axis.legend(loc="upper right", fontsize=8, frameon=True)
    scatter_wells(
        qc_axis,
        well_points,
        coordinate_info,
        valid_mask=np.asarray(grid) >= 0,
        **dict(well_style or {}),
    )
    qc_axis.set_xlabel(str(coordinate_info.get("xlabel", "X coordinate")))
    qc_axis.set_ylabel(str(coordinate_info.get("ylabel", "Y coordinate")))
    qc_axis.set_aspect("equal", adjustable="box")
    qc_axis.set_title(f"MAMCL smoothed clusters with unsafe-window QC (K={clusters})")
    qc_figure.colorbar(qc_shown, ax=qc_axis, ticks=np.arange(clusters), label="cluster id")
    qc_figure.savefig(qc_path, dpi=220)
    plt.close(qc_figure)
    return {
        "label_path": label_path,
        "paper_path": paper_path,
        "qc_path": qc_path,
        "bbox": list(bbox),
    }


def main():
    bundle = load_bundle(config.PREDICTION_BUNDLE)
    output_dir = config.RUN_DIR / "prediction"

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap

    output_dir.mkdir(parents=True, exist_ok=True)
    cluster_argument = getattr(config, "PREDICTION_CLUSTERS", (config.CLUSTERS,))
    if isinstance(cluster_argument, (int, np.integer)):
        cluster_values = [int(cluster_argument)]
    else:
        cluster_values = sorted(set(int(value) for value in cluster_argument))
    if not cluster_values:
        raise ValueError("PREDICTION_CLUSTERS不能为空")

    reference_grid = None
    reference_attention = None
    attribute_maps = None
    paper_bboxes = {}
    smoothed_bboxes = {}
    component_bboxes = {}
    smoothing_records = {}
    coordinate_info = None
    bundle_masks = bundle.get("masks", {})
    unsafe_mask = np.asarray(
        bundle_masks.get("unsafe_mask", np.zeros(bundle["positions"].shape[0], dtype=bool)),
        dtype=bool,
    )
    if unsafe_mask.shape != (bundle["positions"].shape[0],):
        raise ValueError("unsafe_mask与positions数量不一致")
    grid_positions = _grid_positions(bundle)
    for clusters in cluster_values:
        cluster_file = output_dir / f"clusters_k{clusters}.npz"
        if not cluster_file.exists():
            raise FileNotFoundError(f"找不到K={clusters}的聚类结果：{cluster_file}")
        with np.load(cluster_file, allow_pickle=False) as archive:
            grid = np.asarray(archive["grid"])
            labels = np.asarray(archive["labels"])
            confidence_grid = np.asarray(archive["confidence_grid"]) if "confidence_grid" in archive.files else None
            probabilities_grid = np.asarray(archive["probabilities_grid"], dtype=np.float32) if "probabilities_grid" in archive.files else None
            attention = np.asarray(archive["attribute_attention"]) if "attribute_attention" in archive.files else np.load(output_dir / "attribute_attention.npy", mmap_mode="r")
        if reference_grid is None:
            reference_grid = grid
            reference_attention = attention
            coordinate_mode = getattr(config, "PLOT_COORDINATES", getattr(config, "HORIZON_COORDINATES", "world"))
            coordinate_info = _plot_coordinate_info(
                bundle,
                config.INPUT_PATHS[0] if getattr(config, "INPUT_PATHS", None) else None,
                mode=coordinate_mode,
                allow_fallback=False,
            )
            if "fallback_reason" in coordinate_info:
                print("coordinate warning:", coordinate_info["fallback_reason"])
            well_points, well_metadata = load_well_points(
                getattr(config, "WELL_CSV_PATH", None),
                encoding=getattr(config, "WELL_CSV_ENCODING", "gbk"),
                x_column=getattr(config, "WELL_X_COLUMN", None),
                y_column=getattr(config, "WELL_Y_COLUMN", None),
                name_column=getattr(config, "WELL_NAME_COLUMN", None),
            )
            well_style = {
                "size": getattr(config, "WELL_MARKER_SIZE", 38.0),
                "color": getattr(config, "WELL_MARKER_COLOR", "#ff00ff"),
                "edge_color": getattr(config, "WELL_MARKER_EDGE_COLOR", "#ffffff"),
                "edge_width": getattr(config, "WELL_MARKER_EDGE_WIDTH", 0.9),
                "labels": well_metadata.get("labels", []),
            }
            print("well points:", int(well_points.shape[0]), well_metadata.get("status"))
            plot_bundle = dict(bundle)
            plot_bundle["positions"] = grid_positions
            attribute_maps = plot_horizon_attribute_slices(
                plot_bundle,
                reference_grid.shape,
                output_dir,
                coordinates=coordinate_info,
                well_points=well_points,
                well_style=well_style,
            )

        cmap = ListedColormap(
            paper_cluster_colors(clusters),
            name=f"bright_clusters_{clusters}",
        )
        (output_dir / f"cluster_colors_k{clusters}.json").write_text(
            json.dumps(cluster_color_metadata(clusters), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        cmap.set_bad("white")
        image = np.ma.masked_equal(grid, -1)
        norm = BoundaryNorm(np.arange(-0.5, clusters + 0.5, 1), clusters)
        figure, axis = plt.subplots(figsize=(11, 8), constrained_layout=True)
        shown = axis.pcolormesh(
            coordinate_info["x"], coordinate_info["y"], image,
            shading="auto", edgecolors="none", linewidth=0.0, antialiased=False, cmap=cmap, norm=norm,
        )
        scatter_wells(
            axis,
            well_points,
            coordinate_info,
            valid_mask=np.asarray(grid) >= 0,
            **dict(well_style or {}),
        )
        axis.set_xlabel(str(coordinate_info.get("xlabel", "X coordinate")))
        axis.set_ylabel(str(coordinate_info.get("ylabel", "Y coordinate")))
        axis.set_aspect("equal", adjustable="box")
        axis.set_title(f"MAMCL anonymous seismic-facies clusters (K={clusters})")
        figure.colorbar(shown, ax=axis, ticks=np.arange(clusters), label="cluster id")
        figure.savefig(output_dir / f"cluster_map_k{clusters}_labels.png", dpi=220)
        plt.close(figure)
        if CONFIDENCE_PLOT_ENABLED and confidence_grid is not None:
            base_colors = np.asarray([
                tuple(int(value.lstrip("#")[offset:offset+2], 16) / 255.0 for offset in (0, 2, 4))
                for value in paper_cluster_colors(clusters)
            ], dtype=np.float32)
            rgba = np.ones((*grid.shape, 3), dtype=np.float32)
            valid_conf = np.isfinite(confidence_grid) & (grid >= 0)
            if valid_conf.any():
                class_rgb = base_colors[np.clip(grid, 0, clusters - 1)]
                alpha = np.clip(np.nan_to_num(confidence_grid, nan=0.0), 0.0, 1.0)[..., None]
                rgba = 1.0 - alpha * (1.0 - class_rgb)
                rgba[~valid_conf] = 1.0
            confidence_path = output_dir / f"cluster_map_k{clusters}_confidence.png"
            confidence_fig, confidence_axis = plt.subplots(figsize=(11, 8), constrained_layout=True)
            confidence_axis.pcolormesh(coordinate_info["x"], coordinate_info["y"], rgba, shading="auto")
            confidence_axis.set_xlabel(str(coordinate_info.get("xlabel", "X coordinate")))
            confidence_axis.set_ylabel(str(coordinate_info.get("ylabel", "Y coordinate")))
            confidence_axis.set_aspect("equal", adjustable="box")
            confidence_axis.set_title(f"MAMCL cluster confidence (K={clusters})")
            confidence_fig.savefig(confidence_path, dpi=300)
            plt.close(confidence_fig)

        paper_path = output_dir / f"cluster_map_k{clusters}.png"
        paper_bboxes[str(clusters)] = list(
            save_paper_cluster_map(
                grid,
                clusters,
                paper_path,
                base=attribute_maps[0] if attribute_maps is not None else None,
                title=None,
                overlay_alpha=0.82,
                dpi=400,
                coordinates=coordinate_info,
                well_points=well_points,
                well_style=well_style,
            )
        )
        if clusters == config.CLUSTERS:
            (output_dir / "cluster_map.png").write_bytes(paper_path.read_bytes())
        qc_figure, qc_axis = plt.subplots(figsize=(11, 8), constrained_layout=True)
        qc_shown = qc_axis.pcolormesh(
            coordinate_info["x"], coordinate_info["y"], image,
            shading="auto", edgecolors="none", linewidth=0.0, antialiased=False, cmap=cmap, norm=norm,
        )
        unsafe_positions = grid_positions[unsafe_mask]
        if unsafe_positions.shape[0] > 100000:
            stride = int(np.ceil(unsafe_positions.shape[0] / 100000.0))
            unsafe_positions = unsafe_positions[::stride]
        if unsafe_positions.size:
            unsafe_x = coordinate_info["x"][unsafe_positions[:, 0], unsafe_positions[:, 1]]
            unsafe_y = coordinate_info["y"][unsafe_positions[:, 0], unsafe_positions[:, 1]]
            finite = np.isfinite(unsafe_x) & np.isfinite(unsafe_y)
            qc_axis.scatter(
                unsafe_x[finite], unsafe_y[finite],
                s=2, c="black", marker="x", alpha=0.45, linewidths=0.35,
                label="unsafe / padded",
            )
            qc_axis.legend(loc="upper right", fontsize=8, frameon=True)
        scatter_wells(
            qc_axis,
            well_points,
            coordinate_info,
            valid_mask=np.asarray(grid) >= 0,
            **dict(well_style or {}),
        )
        qc_axis.set_xlabel(str(coordinate_info.get("xlabel", "X coordinate")))
        qc_axis.set_ylabel(str(coordinate_info.get("ylabel", "Y coordinate")))
        qc_axis.set_aspect("equal", adjustable="box")
        qc_axis.set_title(f"MAMCL clusters with unsafe-window QC (K={clusters})")
        qc_figure.colorbar(qc_shown, ax=qc_axis, ticks=np.arange(clusters), label="cluster id")
        qc_figure.savefig(output_dir / f"cluster_map_k{clusters}_qc.png", dpi=220)
        if clusters == config.CLUSTERS:
            qc_figure.savefig(output_dir / "cluster_map_qc.png", dpi=220)
        plt.close(qc_figure)
        print(f"K={clusters}")
        print("grid shape:", grid.shape)
        print("sample count:", labels.size)
        print("cluster counts:", _cluster_counts(labels, clusters))
        print("unsafe samples:", int(unsafe_mask.sum()))
        print("cluster map:", paper_path.resolve())
        print("cluster QC map:", (output_dir / f"cluster_map_k{clusters}_qc.png").resolve())

        if POSTPROCESS_MODE == "majority_vote":
            smoothed_grid, smoothing_info = majority_smooth_labels(
                grid, clusters, kernel_size=SMOOTHING_KERNEL_SIZE,
                iterations=SMOOTHING_ITERATIONS, min_votes=SMOOTHING_MIN_VOTES,
            )
        elif POSTPROCESS_MODE == "probability_smoothing":
            if probabilities_grid is None:
                raise RuntimeError(
                    "选择了软概率平滑，但聚类文件没有probabilities_grid；"
                    "请从step05重新运行，或改选多数投票/关闭后处理"
                )
            smoothed_grid, smoothing_info = probability_smooth_labels(
                grid, probabilities_grid,
                sigma=PROBABILITY_SMOOTHING_SIGMA,
                iterations=SMOOTHING_ITERATIONS,
            )
            smoothing_info["method"] = "probability_smoothing"
        else:
            smoothed_grid = np.asarray(grid, dtype=np.int32).copy()
            smoothing_info = {"enabled": False, "changed_count": 0, "iterations": 0, "method": "none"}
        smoothed_labels = smoothed_grid[
            grid_positions[:, 0], grid_positions[:, 1]
        ]
        smoothed_metrics = _spatial_cluster_metrics(smoothed_grid)
        raw_metrics = _spatial_cluster_metrics(grid)
        smoothed_suffix = {
            "probability_smoothing": "_probability_smoothed",
            "majority_vote": "_smoothed",
            "none": "_rawcopy",
        }.get(POSTPROCESS_MODE, "_smoothed")
        smoothed_file = output_dir / f"clusters_k{clusters}{smoothed_suffix}.npz"
        smoothed_values = {
            "labels": smoothed_labels.astype(np.int32),
            "grid": smoothed_grid.astype(np.int32),
        }
        with np.load(cluster_file, allow_pickle=False) as archive:
            for key in ("cluster_centers", "fit_mask", "fit_count"):
                if key in archive.files:
                    smoothed_values[key] = np.asarray(archive[key])
        np.savez_compressed(smoothed_file, **smoothed_values)
        smoothed_metrics_path = output_dir / f"clusters_k{clusters}{smoothed_suffix}_spatial_metrics.json"
        smoothed_metrics_path.write_text(
            json.dumps(
                {
                    "raw": raw_metrics,
                    "smoothed": smoothed_metrics,
                    "smoothing": smoothing_info,
                    "cluster_count_raw": _cluster_counts(labels, clusters),
                    "cluster_count_smoothed": _cluster_counts(smoothed_labels, clusters),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        smoothed_result = _save_smoothed_maps(
            smoothed_grid,
            clusters,
            output_dir,
            coordinate_info,
            attribute_maps[0] if attribute_maps is not None else None,
            unsafe_positions,
            well_points,
            well_style,
            suffix=smoothed_suffix,
        )
        component_grid = None
        component_info = {
            "min_size": SMOOTHING_COMPONENT_MIN_SIZE,
            "connectivity": SMOOTHING_COMPONENT_CONNECTIVITY,
            "removed_components": 0,
            "changed_count": 0,
        }
        component_result = None
        component_file = None
        component_metrics_path = None
        if SMOOTHING_COMPONENT_MIN_SIZE > 1:
            component_grid, component_info = remove_small_components(
                smoothed_grid,
                min_size=SMOOTHING_COMPONENT_MIN_SIZE,
                connectivity=SMOOTHING_COMPONENT_CONNECTIVITY,
            )
            component_labels = component_grid[grid_positions[:, 0], grid_positions[:, 1]]
            component_metrics = _spatial_cluster_metrics(component_grid)
            component_file = output_dir / f"clusters_k{clusters}_smoothed_components.npz"
            component_values = {
                "labels": component_labels.astype(np.int32),
                "grid": component_grid.astype(np.int32),
            }
            with np.load(cluster_file, allow_pickle=False) as archive:
                for key in ("cluster_centers", "fit_mask", "fit_count", "fit_sample_count"):
                    if key in archive.files:
                        component_values[key] = np.asarray(archive[key])
            np.savez_compressed(component_file, **component_values)
            component_metrics_path = output_dir / f"clusters_k{clusters}_smoothed_components_spatial_metrics.json"
            component_metrics_path.write_text(
                json.dumps(
                    {
                        "raw": raw_metrics,
                        "majority_smoothed": smoothed_metrics,
                        "component_smoothed": component_metrics,
                        "majority": smoothing_info,
                        "components": component_info,
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            component_result = _save_smoothed_maps(
                component_grid,
                clusters,
                output_dir,
                coordinate_info,
                attribute_maps[0] if attribute_maps is not None else None,
                unsafe_positions,
                well_points,
                well_style,
                suffix="_smoothed_components",
            )
            print("component-smoothed cluster map:", component_result["paper_path"].resolve())
        smoothed_bboxes[str(clusters)] = smoothed_result["bbox"]
        smoothing_records[str(clusters)] = {
            **smoothing_info,
            "component_cleaning": component_info,
            "raw_metrics": raw_metrics,
            "smoothed_metrics": smoothed_metrics,
            "raw_counts": _cluster_counts(labels, clusters),
            "smoothed_counts": _cluster_counts(smoothed_labels, clusters),
            "outputs": [
                smoothed_file.name,
                smoothed_metrics_path.name,
                smoothed_result["label_path"].name,
                smoothed_result["paper_path"].name,
                smoothed_result["qc_path"].name,
            ],
        }
        if component_result is not None:
            component_bboxes[str(clusters)] = component_result["bbox"]
            smoothing_records[str(clusters)]["component_outputs"] = [
                component_file.name,
                component_metrics_path.name,
                component_result["label_path"].name,
                component_result["paper_path"].name,
                component_result["qc_path"].name,
            ]
        print("smoothed cluster counts:", _cluster_counts(smoothed_labels, clusters))
        print("smoothed changed samples:", smoothing_info["changed_count"])
        print("smoothed cluster map:", smoothed_result["paper_path"].resolve())

    if reference_attention is not None:
        plot_spatial_attribute_attention(
            reference_attention,
            grid_positions,
            reference_grid.shape,
            bundle["attribute_names"],
            output_dir,
            coordinates=coordinate_info,
        )
    (output_dir / "paper_cluster_plot_metadata.json").write_text(
        json.dumps(
            {
                "background": "first attribute horizon map",
                "overlay_alpha": 0.82,
                "rendering": "nearest-neighbor, discrete categorical classes",
                "coordinate": coordinate_metadata(coordinate_info),
                "wells": well_metadata,
                "display_bboxes_by_clusters": paper_bboxes,
                "smoothed_display_bboxes_by_clusters": smoothed_bboxes,
                "component_smoothed_display_bboxes_by_clusters": component_bboxes,
                "spatial_smoothing": {
                    "method": POSTPROCESS_MODE,
                    "postprocess_mode": POSTPROCESS_MODE,
                    "confidence_plot_enabled": CONFIDENCE_PLOT_ENABLED,
                    "kernel_size": SMOOTHING_KERNEL_SIZE,
                    "iterations": SMOOTHING_ITERATIONS,
                    "min_votes": SMOOTHING_MIN_VOTES,
                    "probability_sigma": PROBABILITY_SMOOTHING_SIGMA,
                    "component_min_size": SMOOTHING_COMPONENT_MIN_SIZE,
                    "component_connectivity": SMOOTHING_COMPONENT_CONNECTIVITY,
                    "records": smoothing_records,
                },
                "outputs": [
                    item
                    for value in cluster_values
                    for item in (
                        f"cluster_map_k{value}.png",
                        f"cluster_map_k{value}{smoothed_suffix}.png",
                    )
                ],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print("attribute slices:", (output_dir / "attribute_horizon_slices.png").resolve())
    print("ZGY 2D slices:", (output_dir / "zgy_horizon_slices_2d.png").resolve())


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
