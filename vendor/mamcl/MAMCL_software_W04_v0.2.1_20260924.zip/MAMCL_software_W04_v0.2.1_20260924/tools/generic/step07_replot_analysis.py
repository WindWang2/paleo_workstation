from pathlib import Path
import sys

import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (TOOLS, GENERIC):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from result_io import bundle_metadata
from run_mamcl import _plot_training_analysis


def main():
    analysis_dir = config.RUN_DIR / "analysis"
    attention_path = analysis_dir / "attribute_attention_by_epoch.npy"
    if not attention_path.exists():
        raise FileNotFoundError(f"找不到训练分析文件：{attention_path}")
    attention = np.asarray(np.load(attention_path), dtype=np.float32)
    similarity_paths = sorted(analysis_dir.glob("similarity_distribution_epoch_*.npy"))
    similarity = [np.asarray(np.load(path), dtype=np.float32) for path in similarity_paths]
    positive_paths = sorted(analysis_dir.glob("positive_similarity_epoch_*.npy"))
    negative_paths = sorted(analysis_dir.glob("negative_similarity_epoch_*.npy"))
    positive_similarity = [np.asarray(np.load(path), dtype=np.float32) for path in positive_paths]
    negative_similarity = [np.asarray(np.load(path), dtype=np.float32) for path in negative_paths]
    centers_path = analysis_dir / "cluster_centers_by_epoch.npy"
    centers = []
    if centers_path.exists():
        centers = [value for value in np.asarray(np.load(centers_path), dtype=np.float32)]
    names = bundle_metadata(config.TRAIN_BUNDLE)["inputs"]
    bundle = {"attribute_names": [Path(name).stem for name in names]}
    _plot_training_analysis(
        config.RUN_DIR,
        bundle["attribute_names"],
        [value for value in attention],
        similarity,
        centers,
        positive_similarity,
        negative_similarity,
    )
    print("analysis figures:", analysis_dir.resolve())


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    from result_io import capture_log
    with capture_log(config.RUN_DIR / (Path(__file__).stem + ".log")):
        main()
