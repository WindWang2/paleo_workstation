from __future__ import annotations

import json
import platform
import sys
from collections import deque
from datetime import datetime
from pathlib import Path

import numpy as np

if not getattr(sys, "frozen", False):
    ROOT = Path(__file__).resolve().parents[2]
    TOOLS = ROOT / "tools"
    GENERIC = TOOLS / "generic"
    for path in (GENERIC, TOOLS):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

import config
from result_io import file_info, bundle_metadata, package_results


def _plain(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, (tuple, list)):
        return [_plain(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _plain(item) for key, item in value.items()}
    return value


def _finite_stats(values):
    array = np.asarray(values)
    result = {"shape": list(array.shape), "dtype": str(array.dtype)}
    if array.size == 0:
        result.update({"count": 0, "finite": 0})
        return result
    numeric = np.asarray(array, dtype=np.float64).reshape(-1)
    finite = numeric[np.isfinite(numeric)]
    result.update({"count": int(numeric.size), "finite": int(finite.size)})
    if finite.size:
        result.update(
            {
                "min": float(finite.min()),
                "max": float(finite.max()),
                "mean": float(finite.mean()),
                "std": float(finite.std()),
                "q05": float(np.percentile(finite, 5)),
                "q50": float(np.percentile(finite, 50)),
                "q95": float(np.percentile(finite, 95)),
            }
        )
    return result


def _array_file(path, per_axis=False):
    path = Path(path)
    if not path.exists():
        return None
    try:
        values = np.load(path, allow_pickle=False)
        result = _finite_stats(values)
        if per_axis and values.ndim == 2:
            result["first"] = [float(value) for value in values[0].tolist()] if values.shape[0] else []
            result["last"] = [float(value) for value in values[-1].tolist()] if values.shape[0] else []
        return result
    except Exception as error:
        return {"error": f"{type(error).__name__}: {error}"}


def _bundle_file(path):
    result = file_info(path)
    if result['exists']:
        try:
            result['metadata'] = bundle_metadata(path)
            with np.load(path, allow_pickle=False) as archive:
                result["masks"] = {
                    key[5:]: int(np.asarray(archive[key], dtype=bool).sum())
                    for key in archive.files if key.startswith("mask_")
                }
        except Exception as error:
            result['error'] = str(error)
    return result


def _loss_file(path):
    result = _array_file(path)
    if not result or "error" in result or result.get("count", 0) == 0:
        return result
    values = np.asarray(np.load(path, allow_pickle=False), dtype=np.float64).reshape(-1)
    finite = values[np.isfinite(values)]
    if finite.size <= 100000:
        result["values"] = finite.tolist()
    result["first"] = [float(value) for value in finite[:10]]
    result["last"] = [float(value) for value in finite[-10:]]
    result["last_mean_10"] = float(np.mean(finite[-10:])) if finite.size else None
    return result


def _log_file(path):
    path = Path(path)
    if not path.exists():
        return {"exists": False}
    first = []
    last = deque(maxlen=20)
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for index, line in enumerate(handle):
                line = line.rstrip("\r\n")
                if index < 20:
                    first.append(line)
                last.append(line)
        return {"exists": True, "bytes": path.stat().st_size, "first": first, "last": list(last)}
    except Exception as error:
        return {"exists": True, "bytes": path.stat().st_size, "error": f"{type(error).__name__}: {error}"}


def _analysis_summary(analysis_dir):
    analysis_dir = Path(analysis_dir)
    result = {}
    attention = analysis_dir / "attribute_attention_by_epoch.npy"
    if attention.exists():
        result["attribute_attention"] = _array_file(attention, per_axis=True)
    center = analysis_dir / "cluster_centers_by_epoch.npy"
    if center.exists():
        values = np.asarray(np.load(center, allow_pickle=False), dtype=np.float64)
        item = _finite_stats(values)
        item["epochs"] = int(values.shape[0]) if values.ndim else 0
        if values.ndim >= 3 and values.shape[0]:
            item["final_center_norms"] = [
                float(np.linalg.norm(vector)) for vector in values[-1]
            ]
            if values.shape[0] > 1:
                shifts = np.linalg.norm(np.diff(values, axis=0), axis=-1)
                item["center_shift_last"] = [float(value) for value in shifts[-1]]
        result["cluster_centers"] = item
    similarity = []
    for path in sorted(analysis_dir.glob("similarity_distribution_epoch_*.npy")):
        item = _array_file(path)
        if item is not None:
            item["epoch"] = int(path.stem.rsplit("_", 1)[-1])
            similarity.append(item)
    if similarity:
        result["similarity_distribution"] = similarity
    runtime_path = analysis_dir / "runtime_diagnostics.json"
    if runtime_path.exists():
        try:
            runtime = json.loads(runtime_path.read_text(encoding="utf-8"))
            epochs = runtime.get("epochs", [])
            result["runtime_diagnostics"] = {
                "version": runtime.get("version"),
                "epoch_count": len(epochs),
                "runtime_config": runtime.get("runtime_config", {}),
                "last_epoch": epochs[-1] if epochs else None,
            }
        except Exception as error:
            result["runtime_diagnostics"] = {
                "error": f"{type(error).__name__}: {error}"
            }
    elif analysis_dir.exists():
        epoch_paths = sorted(analysis_dir.glob("runtime_diagnostics_epoch_*.json"))
        if epoch_paths:
            epochs = []
            for path in epoch_paths:
                try:
                    epochs.append(json.loads(path.read_text(encoding="utf-8")))
                except Exception:
                    continue
            result["runtime_diagnostics"] = {
                "version": "mamcl-runtime-diagnostics-v1",
                "epoch_count": len(epochs),
                "runtime_config": {},
                "last_epoch": epochs[-1] if epochs else None,
                "partial": True,
            }
    result["files"] = [
        {"name": path.name, "bytes": path.stat().st_size}
        for path in sorted(analysis_dir.iterdir())
        if path.is_file()
    ] if analysis_dir.exists() else []
    return result


def _prediction_summary(prediction_dir):
    prediction_dir = Path(prediction_dir)
    result = []
    for path in sorted(prediction_dir.glob("clusters_k*.npz")):
        item = {"file": path.name, "bytes": path.stat().st_size}
        try:
            with np.load(path, allow_pickle=False) as archive:
                grid = np.asarray(archive["grid"])
                labels = np.asarray(archive["labels"])
                item["grid_shape"] = list(grid.shape)
                item["sample_count"] = int(labels.size)
                valid = labels[labels >= 0]
                item["valid_count"] = int(valid.size)
                item["cluster_count"] = int(np.max(valid) + 1) if valid.size else 0
                item["counts"] = np.bincount(valid.astype(np.int64)).tolist() if valid.size else []
                if "fit_count" in archive.files:
                    item["fit_count"] = int(np.asarray(archive["fit_count"]).item())
                if "fit_mask" in archive.files:
                    item["fit_safe_count"] = int(np.asarray(archive["fit_mask"], dtype=bool).sum())
                for key in (
                    "spatial_continuity",
                    "spatial_transition_rate",
                    "isolated_fraction",
                    "horizontal_pair_count",
                    "vertical_pair_count",
                ):
                    if key in archive.files:
                        value = np.asarray(archive[key]).reshape(-1)
                        item[key] = float(value[0]) if value.size else None
        except Exception as error:
            item["error"] = f"{type(error).__name__}: {error}"
        result.append(item)
    return result


def _k_selection_summary(prediction_dir):
    path = Path(prediction_dir) / "k_selection_metrics.json"
    if not path.exists():
        return {"exists": False}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return {
            "exists": True,
            "recommended_k": data.get("recommended_k"),
            "metric_sample_count": data.get("metric_sample_count"),
            "rows": data.get("rows", []),
        }
    except Exception as error:
        return {"exists": True, "error": f"{type(error).__name__}: {error}"}


def _config_summary():
    fields = (
        "RUN_NAME", "INPUT_PATHS", "HORIZON_FILE", "UPPER_HORIZON_FILE",
        "LOWER_HORIZON_FILE", "INTERVAL_MODE", "INTERVAL_CENTER_MODE",
        "INTERVAL_FRACTION", "INTERVAL_MARGIN", "INTERVAL_WINDOW_MODE",
        "INTERVAL_COVERAGE", "INTERVAL_ANCHOR_OFFSET", "INTERVAL_PADDING_MODE",
        "HORIZON_SHAPE", "WINDOW",
        "GAUSSIAN_SIGMA", "GAUSSIAN_PEAK_MODE", "HORIZON_SHIFT", "HORIZON_UNIT", "TRAIN_STRIDE",
        "PREDICTION_STRIDE", "SAMPLING", "NORMALIZE", "BATCH_SIZE", "EPOCHS",
        "NOISE_STD", "LR", "CLUSTERS", "PREDICTION_CLUSTERS", "SEED", "DEVICE",
        "DCL_TOPK", "DCL_POSITION_WEIGHTING",
        "DILATED_CONV_DILATIONS", "SPATIAL_CONSISTENCY_ENABLED",
        "SPATIAL_CONSISTENCY_WEIGHT", "SPATIAL_CONSISTENCY_NEIGHBORS",
        "SPATIAL_CONSISTENCY_DISTANCE_SCALE",
        "TRAIN_SAFE_ONLY", "KMEANS_SAFE_ONLY",
        "INCLUDE_REVIEW_ARRAYS",
        "K_SELECTION_ENABLED", "K_SELECTION_MAX_SAMPLES", "K_SELECTION_STABILITY_RUNS",
        "HORIZON_INTERPOLATION", "HORIZON_INTERPOLATION_METHOD", "HORIZON_COORDINATES",
        "HORIZON_CROP_TO_COMMON", "HORIZON_FILL_NANS",
    )
    result = {}
    for field in fields:
        if hasattr(config, field):
            value = _plain(getattr(config, field))
            if field == "INPUT_PATHS":
                value = [
                    {"path": str(Path(item)), "exists": Path(item).is_file()}
                    for item in value
                ]
            result[field] = value
    return result


def _file_inventory(run_dir):
    result = []
    for path in sorted(Path(run_dir).rglob("*")):
        if path.is_file() and path.name not in {"result_summary.json", "result_summary.txt"}:
            result.append(file_info(path))
    return result


def _text_summary(summary):
    lines = [
        "MAMCL generic result summary",
        f"created: {summary['created']}",
        f"run_dir: {summary['run_dir']}",
        "",
        "[configuration]",
    ]
    for key, value in summary["configuration"].items():
        if key == "INPUT_PATHS":
            value = [item["path"] if isinstance(item, dict) else item for item in value]
        lines.append(f"{key}: {value}")
    lines.extend(["", "[loss]"])
    loss = summary.get("loss", {})
    for key in ("shape", "count", "finite", "min", "max", "mean", "std", "first", "last", "last_mean_10"):
        if key in loss:
            lines.append(f"{key}: {loss[key]}")
    log = summary.get("training_log", {})
    lines.append(f"training_log: exists={log.get('exists')} bytes={log.get('bytes')}")
    runtime = summary.get("analysis", {}).get("runtime_diagnostics", {})
    if runtime:
        lines.append(f"runtime_diagnostics_epochs: {runtime.get('epoch_count')}")
        last_epoch = runtime.get("last_epoch") or {}
        positive = last_epoch.get("positive_similarity", {}) or {}
        negative = last_epoch.get("negative_similarity", {}) or {}
        lines.append(
            "last_epoch_positive_similarity: "
            + str(positive.get("mean"))
        )
        lines.append(
            "last_epoch_negative_similarity: "
            + str(negative.get("mean"))
        )
        spatial = last_epoch.get("spatial_consistency", {}) or {}
        lines.append("last_epoch_spatial_consistency: " + str(spatial.get("mean")))
    lines.extend(["", "[bundles]"])
    for name, item in summary.get("bundles", {}).items():
        lines.append(f"{name}: {item.get('path')} shape={item.get('samples', {}).get('shape')} bytes={item.get('bytes')} masks={item.get('masks')}")
    lines.extend(["", "[prediction]"])
    for item in summary.get("prediction", []):
        lines.append(f"{item.get('file')}: grid={item.get('grid_shape')} counts={item.get('counts')} fit_count={item.get('fit_count')}")
    selection = summary.get("k_selection", {})
    lines.extend(["", "[K selection]"])
    lines.append(f"exists: {selection.get('exists')}")
    if selection.get("exists"):
        lines.append(f"recommended_k: {selection.get('recommended_k')}")
        lines.append(f"metric_sample_count: {selection.get('metric_sample_count')}")
    lines.extend(["", "[analysis files]"])
    lines.append(str(summary.get("analysis", {}).get("files", [])))
    return "\n".join(lines) + "\n"


def main():
    run_dir = Path(config.RUN_DIR)
    run_dir.mkdir(parents=True, exist_ok=True)
    summary = {
        "version": "generic-result-summary-v1",
        "created": datetime.now().astimezone().isoformat(timespec="seconds"),
        "run_dir": str(run_dir.resolve()),
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "configuration": json.loads((run_dir / "run_all_settings.json").read_text(encoding="utf-8")) if (run_dir / "run_all_settings.json").exists() else _config_summary(),
        "bundles": {
            "train": _bundle_file(getattr(config, "TRAIN_BUNDLE", "")),
            "prediction": _bundle_file(getattr(config, "PREDICTION_BUNDLE", "")),
        },
        "loss": _loss_file(run_dir / "losses.npy") or {"exists": False},
        "training_log": _log_file(run_dir / "training.log"),
        "analysis": _analysis_summary(run_dir / "analysis"),
        "prediction": _prediction_summary(run_dir / "prediction"),
        "k_selection": _k_selection_summary(run_dir / "prediction"),
    }
    summary["files"] = _file_inventory(run_dir)
    json_path = run_dir / "result_summary.json"
    text_path = run_dir / "result_summary.txt"
    json_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    text_path.write_text(_text_summary(summary), encoding="utf-8")
    print("result summary json:", json_path.resolve())
    print("result summary text:", text_path.resolve())
    archive = package_results(run_dir)
    print("result directory:", (run_dir / "result").resolve())
    print("review archive:", archive.resolve())
    return archive


if __name__ == "__main__":
    from run_all import apply_config
    apply_config()
    main()
