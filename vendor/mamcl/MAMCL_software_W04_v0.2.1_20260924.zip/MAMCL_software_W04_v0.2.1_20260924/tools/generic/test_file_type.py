from pathlib import Path
import argparse
import json
import struct


FILE_PATH = r""


def size_text(size):
    value = float(size)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:.2f} {unit}"
        value /= 1024


def read_prefix(path, count=64):
    with path.open("rb") as handle:
        return handle.read(count)


def signature_info(prefix):
    result = {
        "npy": prefix.startswith(b"\x93NUMPY"),
        "npz_or_zip": prefix.startswith(b"PK\x03\x04"),
        "gzip": prefix.startswith(b"\x1f\x8b"),
        "hdf5": prefix.startswith(b"\x89HDF\r\n\x1a\n"),
    }
    return result


def segy_info(path):
    try:
        import segyio
    except Exception as error:
        return {"available": False, "error": f"segyio unavailable: {error}"}

    try:
        with segyio.open(
            str(path),
            "r",
            strict=False,
            ignore_geometry=True,
        ) as handle:
            result = {
                "available": True,
                "is_segy": True,
                "tracecount": int(handle.tracecount),
                "sample_count": int(len(handle.samples)),
                "samples_first": float(handle.samples[0]),
                "samples_last": float(handle.samples[-1]),
                "trace0_first10": [float(value) for value in handle.trace[0][:10]],
            }
            try:
                result["sample_interval_us"] = int(
                    handle.bin[segyio.BinField.Interval]
                )
            except Exception as error:
                result["sample_interval_us"] = f"unavailable: {error}"
            try:
                result["format_code"] = int(handle.format)
            except Exception:
                result["format_code"] = "unavailable"
            return result
    except Exception as error:
        return {
            "available": True,
            "is_segy": False,
            "error": f"SEG-Y open failed: {type(error).__name__}: {error}",
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?", default=FILE_PATH)
    args = parser.parse_args()

    if not args.path:
        raise SystemExit("请提供文件路径，或先修改脚本顶部的 FILE_PATH")

    path = Path(args.path).expanduser()
    if not path.is_file():
        raise SystemExit(f"文件不存在: {path}")

    prefix = read_prefix(path)
    report = {
        "path": str(path),
        "size_bytes": int(path.stat().st_size),
        "size": size_text(path.stat().st_size),
        "suffix": path.suffix.lower(),
        "prefix_hex": prefix[:32].hex(" "),
        "signatures": signature_info(prefix),
        "segy": segy_info(path),
    }

    if report["signatures"]["npy"]:
        report["conclusion"] = "NumPy .npy 文件"
    elif report["signatures"]["npz_or_zip"]:
        report["conclusion"] = "ZIP/NPZ 容器文件"
    elif report["signatures"]["gzip"]:
        report["conclusion"] = "GZIP 压缩文件"
    elif report["signatures"]["hdf5"]:
        report["conclusion"] = "HDF5 文件"
    elif report["segy"].get("is_segy"):
        report["conclusion"] = "SEG-Y 地震数据文件，可使用流式 SEG-Y 读取"
    else:
        report["conclusion"] = "未识别；可能是原始二进制文件或专有格式，需要 dtype、字节序和三维 shape"

    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
