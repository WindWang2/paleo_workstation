from __future__ import annotations

import csv
import json
import re
from pathlib import Path

import numpy as np


def _rank(values, higher):
    values = np.asarray(values, dtype=np.float64)
    finite = np.isfinite(values)
    ranks = np.full(values.shape, np.inf, dtype=np.float64)
    order_values = -values if higher else values
    order = np.argsort(np.where(finite, order_values, np.inf), kind="stable")
    rank = 1
    for index in order:
        if finite[index]:
            ranks[index] = rank
            rank += 1
    return ranks


def _sample_indices(labels_by_k, max_samples, seed, base_mask=None):
    first = next(iter(labels_by_k.values()))
    count = int(first.size)
    common = np.ones(count, dtype=bool)
    if base_mask is not None:
        base_mask = np.asarray(base_mask, dtype=bool)
        if base_mask.shape != (count,):
            raise ValueError("K筛选base_mask与标签数量不一致")
        common &= base_mask
    required = []
    for labels in labels_by_k.values():
        if labels.size != count:
            raise ValueError("不同K的聚类标签数量不一致")
        valid = np.asarray(labels) >= 0
        common &= valid
        for cluster in np.unique(labels[valid]):
            hits = np.flatnonzero(labels == cluster)
            if hits.size:
                required.append(int(hits[0]))
    valid_indices = np.flatnonzero(common)
    if valid_indices.size == 0:
        raise ValueError("没有所有K都有效的共同样本")
    limit = int(max_samples)
    if limit <= 0 or valid_indices.size <= limit:
        chosen = valid_indices
    else:
        rng = np.random.default_rng(int(seed))
        chosen = rng.choice(valid_indices, size=limit, replace=False)
    required = np.asarray(required, dtype=np.int64)
    if required.size:
        required = required[common[required]]
    return np.unique(np.concatenate((chosen, required)))


def _plot_metrics(rows, output):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    k = [row["k"] for row in rows]
    recommended = min(rows, key=lambda row: row["overall_rank"])["k"]
    figure, axes = plt.subplots(2, 3, figsize=(15, 8), constrained_layout=True)
    plots = (
        ("silhouette", "Silhouette score", True),
        ("davies_bouldin", "Davies-Bouldin index", False),
        ("calinski_harabasz", "Calinski-Harabasz score", True),
        ("stability", "Stability (ARI)", True),
        ("inertia_per_sample", "Inertia per sample", False),
        ("overall_rank", "Mean metric rank", False),
    )
    for axis, (field, title, higher) in zip(axes.ravel(), plots):
        values = np.asarray([row[field] for row in rows], dtype=np.float64)
        axis.plot(k, values, marker="o")
        axis.axvline(recommended, color="tab:red", linestyle="--", alpha=0.7)
        axis.set_xlabel("K")
        axis.set_ylabel(title)
        axis.set_title(title)
        axis.grid(alpha=0.25)
    figure.suptitle(f"K selection metrics (recommended K={recommended})")
    figure.savefig(output, dpi=220)
    plt.close(figure)


def select_k(
    features_path,
    prediction_dir,
    output_dir=None,
    max_samples=5000,
    seed=42,
    stability_runs=5,
):
    features_path = Path(features_path)
    prediction_dir = Path(prediction_dir)
    output_dir = Path(output_dir or prediction_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    features = np.load(features_path, mmap_mode="r")
    if features.ndim != 2:
        raise ValueError("features_h.npy必须是二维数组")
    label_files = {}
    pattern = re.compile(r"^clusters_k(\d+)\.npz$")
    for path in sorted(prediction_dir.glob("clusters_k*.npz")):
        match = pattern.match(path.name)
        if match:
            label_files[int(match.group(1))] = path
    if not label_files:
        raise FileNotFoundError(f"找不到聚类结果：{prediction_dir}")
    labels_by_k = {}
    archives = {}
    for k, path in sorted(label_files.items()):
        archive = np.load(path, allow_pickle=False)
        labels = np.asarray(archive["labels"], dtype=np.int64)
        if labels.ndim != 1 or labels.size != features.shape[0]:
            archive.close()
            raise ValueError(f"K={k}标签与特征数量不一致")
        labels_by_k[k] = labels
        archives[k] = archive
    fit_masks = []
    for archive in archives.values():
        if "fit_mask" in archive.files:
            fit_masks.append(np.asarray(archive["fit_mask"], dtype=bool))
    evaluation_mask = None
    if fit_masks:
        evaluation_mask = np.logical_and.reduce(fit_masks)
    indices = _sample_indices(labels_by_k, max_samples, seed, base_mask=evaluation_mask)
    if indices.size < 2:
        raise ValueError("用于K筛选的样本少于两个")
    rows = []
    try:
        from sklearn.metrics import (
            adjusted_rand_score,
            calinski_harabasz_score,
            davies_bouldin_score,
            silhouette_score,
        )
        from sklearn.cluster import KMeans
    except ImportError as exc:
        for archive in archives.values():
            archive.close()
        raise ImportError("K筛选需要scikit-learn") from exc
    for k in sorted(labels_by_k):
        labels = labels_by_k[k]
        selected_labels = labels[indices]
        selected_features = np.asarray(features[indices], dtype=np.float32)
        unique = np.unique(selected_labels)
        if unique.size < 2:
            silhouette = float("nan")
            davies_bouldin = float("nan")
            calinski_harabasz = float("nan")
            stability = float("nan")
        else:
            silhouette = float(silhouette_score(selected_features, selected_labels))
            davies_bouldin = float(davies_bouldin_score(selected_features, selected_labels))
            calinski_harabasz = float(calinski_harabasz_score(selected_features, selected_labels))
            run_count = max(2, int(stability_runs))
            repeated = [
                KMeans(
                    n_clusters=k,
                    n_init=1,
                    random_state=int(seed) + repeat,
                ).fit_predict(selected_features)
                for repeat in range(run_count)
            ]
            pairwise = [
                adjusted_rand_score(repeated[i], repeated[j])
                for i in range(run_count)
                for j in range(i + 1, run_count)
            ]
            stability = float(np.mean(pairwise)) if pairwise else float("nan")
        counts = np.bincount(labels[labels >= 0], minlength=k)
        inertia = float(np.asarray(archives[k]["inertia"]).item()) if "inertia" in archives[k].files else float("nan")
        rows.append(
            {
                "k": int(k),
                "silhouette": silhouette,
                "davies_bouldin": davies_bouldin,
                "calinski_harabasz": calinski_harabasz,
                "stability": stability,
                "inertia": inertia,
                "inertia_per_sample": inertia / max(int(labels.size), 1),
                "sample_count": int(labels.size),
                "metric_sample_count": int(indices.size),
                "cluster_counts": counts.astype(int).tolist(),
                "min_cluster_fraction": float(counts.min() / max(labels.size, 1)),
            }
        )
    for archive in archives.values():
        archive.close()
    silhouette_ranks = _rank([row["silhouette"] for row in rows], higher=True)
    db_ranks = _rank([row["davies_bouldin"] for row in rows], higher=False)
    ch_ranks = _rank([row["calinski_harabasz"] for row in rows], higher=True)
    stability_ranks = _rank([row["stability"] for row in rows], higher=True)
    for index, row in enumerate(rows):
        ranks = [
            silhouette_ranks[index],
            db_ranks[index],
            ch_ranks[index],
            stability_ranks[index],
        ]
        finite_ranks = [value for value in ranks if np.isfinite(value)]
        row["silhouette_rank"] = int(silhouette_ranks[index]) if np.isfinite(silhouette_ranks[index]) else None
        row["davies_bouldin_rank"] = int(db_ranks[index]) if np.isfinite(db_ranks[index]) else None
        row["calinski_harabasz_rank"] = int(ch_ranks[index]) if np.isfinite(ch_ranks[index]) else None
        row["stability_rank"] = int(stability_ranks[index]) if np.isfinite(stability_ranks[index]) else None
        row["overall_rank"] = float(np.mean(finite_ranks)) if finite_ranks else float("inf")
    recommended = min(rows, key=lambda row: (row["overall_rank"], row["k"]))
    result = {
        "method": "mean rank of Silhouette, Davies-Bouldin, Calinski-Harabasz and stability ARI",
        "features": str(features_path.resolve()),
        "prediction_dir": str(prediction_dir.resolve()),
        "seed": int(seed),
        "metric_sample_count": int(indices.size),
        "metric_mask": "intersection of cluster fit_mask fields" if evaluation_mask is not None else "all predicted samples",
        "max_samples": int(max_samples),
        "stability_runs": max(2, int(stability_runs)),
        "recommended_k": int(recommended["k"]),
        "rows": rows,
    }
    json_path = output_dir / "k_selection_metrics.json"
    csv_path = output_dir / "k_selection_metrics.csv"
    plot_path = output_dir / "k_selection_metrics.png"
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=True), encoding="utf-8")
    fields = [
        "k", "silhouette", "davies_bouldin", "calinski_harabasz", "stability", "inertia",
        "inertia_per_sample", "sample_count", "metric_sample_count",
        "min_cluster_fraction", "silhouette_rank", "davies_bouldin_rank",
        "calinski_harabasz_rank", "stability_rank", "overall_rank", "cluster_counts",
    ]
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            item = dict(row)
            item["cluster_counts"] = json.dumps(item["cluster_counts"], ensure_ascii=False)
            writer.writerow(item)
    try:
        _plot_metrics(rows, plot_path)
    except Exception as error:
        print(f"K筛选绘图失败：{type(error).__name__}: {error}")
    print("K selection metric sample count:", int(indices.size))
    for row in rows:
        print(
            f"K={row['k']} silhouette={row['silhouette']:.6f} "
            f"davies_bouldin={row['davies_bouldin']:.6f} "
            f"calinski_harabasz={row['calinski_harabasz']:.6f} "
            f"stability={row['stability']:.6f} "
            f"overall_rank={row['overall_rank']:.3f}"
        )
    print("recommended K:", int(recommended["k"]))
    print("metrics json:", json_path.resolve())
    print("metrics csv:", csv_path.resolve())
    if plot_path.exists():
        print("metrics figure:", plot_path.resolve())
    return result
