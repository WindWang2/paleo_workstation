import argparse
import json
from pathlib import Path

import numpy as np

from equal_judge import equal_or_not
from extract_window import extract_windows
from normalize import normalize_samples
from read_volume import load_surface, load_volume, read_inline_horizon_world, read_smi_axes
from segy_windows import prepare_segy_samples
from zgy_windows import prepare_zgy_samples


def _default_masks(count):
    count = int(count)
    return {
        "interval_safe_mask": np.ones(count, dtype=bool),
        "interval_unsafe_mask": np.zeros(count, dtype=bool),
        "direction_unsafe_mask": np.zeros(count, dtype=bool),
        "lower_invalid_mask": np.zeros(count, dtype=bool),
        "array_oob_mask": np.zeros(count, dtype=bool),
        "padding_mask": np.zeros(count, dtype=bool),
        "invalid_attribute_mask": np.zeros(count, dtype=bool),
        "unsafe_mask": np.zeros(count, dtype=bool),
        "train_mask": np.ones(count, dtype=bool),
    }


def prepare_samples(
    input_paths,
    shape=None,
    dtype="float32",
    endian="native",
    order="C",
    npz_key=None,
    segy_inline_field=189,
    segy_crossline_field=193,
    segy_strict=True,
    horizon=50,
    window=8,
    stride=(1, 1),
    sampling="integer",
    normalize="zscore",
    inline_slice=None,
    crossline_slice=None,
    horizon_file=None,
    horizon_shape=None,
    horizon_dtype="float32",
    horizon_endian="native",
    horizon_order="C",
    horizon_key=None,
    horizon_scale=1.0,
    horizon_offset=0.0,
    horizon_shift=0.0,
    skip_invalid_horizon=False,
    horizon_unit="samples",
    segy_axes=None,
    normalization_stats=None,
    return_normalization=False,
    interpolate_horizon=False,
    interpolation_method="linear_nearest",
    horizon_coordinates="inline_crossline",
    max_fill_distance_factor=2.0,
    low_confidence_distance_factor=1.0,
    upper_horizon_file=None,
    lower_horizon_file=None,
    lower_axes=None,
    crop_to_common=False,
    fill_horizon_nans=False,
    interval_center_mode="equal",
    interval_fraction=0.5,
    interval_margin=1.0,
    interval_window_mode="global_min",
    interval_coverage=0.90,
    interval_anchor_offset=0.0,
    interval_padding_mode="edge",
    return_masks=False,
):
    if not input_paths:
        raise ValueError("input_paths不能为空")
    interval_mode = upper_horizon_file is not None or lower_horizon_file is not None
    if interval_mode and (upper_horizon_file is None or lower_horizon_file is None):
        raise ValueError("层间模式必须同时提供upper_horizon_file和lower_horizon_file")
    horizon_value = horizon
    horizon_world_x = None
    horizon_world_y = None
    lower_horizon_value = None
    lower_horizon_world_x = None
    lower_horizon_world_y = None
    upper_axes = None
    lower_axes_value = None
    if interval_mode:
        interval_horizon_shape = None if crop_to_common else horizon_shape
        if str(horizon_coordinates).lower() == "world":
            horizon_value, horizon_world_x, horizon_world_y = read_inline_horizon_world(
                upper_horizon_file,
                shape=interval_horizon_shape,
            )
            lower_horizon_value, lower_horizon_world_x, lower_horizon_world_y = read_inline_horizon_world(
                lower_horizon_file,
                shape=interval_horizon_shape,
            )
        else:
            horizon_value = load_surface(
                upper_horizon_file,
                shape=interval_horizon_shape,
                dtype=horizon_dtype,
                endian=horizon_endian,
                order=horizon_order,
                key=horizon_key,
                allow_invalid=bool(fill_horizon_nans or crop_to_common),
            )
            lower_horizon_value = load_surface(
                lower_horizon_file,
                shape=interval_horizon_shape,
                dtype=horizon_dtype,
                endian=horizon_endian,
                order=horizon_order,
                key=horizon_key,
                allow_invalid=bool(fill_horizon_nans or crop_to_common),
            )
        try:
            upper_axes = read_smi_axes(upper_horizon_file, shape=horizon_value.shape)
        except (OSError, ValueError):
            upper_axes = None
        try:
            lower_axes_value = read_smi_axes(lower_horizon_file, shape=lower_horizon_value.shape)
        except (OSError, ValueError):
            lower_axes_value = None
    elif horizon_file is not None:
        if str(horizon_coordinates).lower() == "world":
            horizon_value, horizon_world_x, horizon_world_y = read_inline_horizon_world(
                horizon_file,
                shape=horizon_shape,
            )
        else:
            horizon_value = load_surface(
                horizon_file,
                shape=horizon_shape,
                dtype=horizon_dtype,
                endian=horizon_endian,
                order=horizon_order,
                key=horizon_key,
                allow_invalid=bool(fill_horizon_nans),
            )
    horizon_value = np.asarray(horizon_value, dtype=np.float64)

    segy_flags = [Path(path).suffix.lower() in {".sgy", ".segy"} for path in input_paths]
    zgy_flags = [Path(path).suffix.lower() == ".zgy" for path in input_paths]
    if any(segy_flags) and not all(segy_flags):
        raise ValueError("属性体不能混合SEG-Y与.npy/.npz/裸二进制格式；请先统一格式")
    if input_paths and all(segy_flags):
        if interval_mode:
            raise ValueError("层间模式当前仅支持ZGY属性体")
        if segy_axes is None and horizon_file is not None and str(horizon_file).lower().endswith((".dat", ".raw", ".bin")):
            try:
                segy_axes = read_smi_axes(horizon_file, shape=horizon_value.shape)
            except (OSError, ValueError):
                segy_axes = None
        result = prepare_segy_samples(
            input_paths,
            horizon_value,
            window=window,
            stride=stride,
            sampling=sampling,
            normalize=normalize,
            iline=segy_inline_field,
            xline=segy_crossline_field,
            horizon_unit=horizon_unit,
            horizon_scale=horizon_scale,
            horizon_offset=horizon_offset,
            horizon_shift=horizon_shift,
            skip_invalid_horizon=skip_invalid_horizon,
            axes=segy_axes,
            normalization_stats=normalization_stats,
            inline_slice=inline_slice,
            crossline_slice=crossline_slice,
        )
        if return_normalization:
            if return_masks and len(result) == 4:
                return (*result, _default_masks(result[0].shape[0]))
            return result
        return result[:3]

    if any(zgy_flags):
        if not all(zgy_flags):
            raise ValueError("属性体不能混合ZGY与其他格式；请先统一格式")
        zgy_axes = segy_axes if segy_axes is not None else upper_axes
        axes_file = upper_horizon_file if interval_mode else horizon_file
        if zgy_axes is None and axes_file is not None and str(axes_file).lower().endswith((".dat", ".raw", ".bin")):
            try:
                zgy_axes = read_smi_axes(axes_file, shape=horizon_value.shape)
            except (OSError, ValueError):
                zgy_axes = None
        if interval_mode:
            lower_horizon_value = np.asarray(lower_horizon_value, dtype=np.float64)
        result = prepare_zgy_samples(
            input_paths,
            horizon_value * float(horizon_scale) + float(horizon_offset),
            window=window,
            stride=stride,
            sampling=sampling,
            normalize=normalize,
            horizon_unit=horizon_unit,
            horizon_shift=horizon_shift,
            skip_invalid_horizon=skip_invalid_horizon,
            axes=zgy_axes,
            normalization_stats=normalization_stats,
            inline_slice=inline_slice,
            crossline_slice=crossline_slice,
            interpolate_horizon=interpolate_horizon,
            interpolation_method=interpolation_method,
            horizon_coordinates=horizon_coordinates,
            horizon_world_x=horizon_world_x,
            horizon_world_y=horizon_world_y,
            max_fill_distance_factor=max_fill_distance_factor,
            low_confidence_distance_factor=low_confidence_distance_factor,
            lower_horizon=(
                lower_horizon_value * float(horizon_scale) + float(horizon_offset)
                if interval_mode else None
            ),
            lower_horizon_world_x=lower_horizon_world_x,
            lower_horizon_world_y=lower_horizon_world_y,
            lower_axes=(lower_axes if lower_axes is not None else lower_axes_value),
            crop_to_common=crop_to_common,
            fill_horizon_nans=fill_horizon_nans,
            interval_center_mode=interval_center_mode,
            interval_fraction=interval_fraction,
            interval_margin=interval_margin,
            interval_window_mode=interval_window_mode,
            interval_coverage=interval_coverage,
            interval_anchor_offset=interval_anchor_offset,
            interval_padding_mode=interval_padding_mode,
            return_masks=return_masks,
        )
        if return_normalization:
            if return_masks and len(result) == 4:
                return (*result, _default_masks(result[0].shape[0]))
            return result
        return result[:3]

    load_kwargs = {
        "shape": shape,
        "dtype": dtype,
        "endian": endian,
        "order": order,
        "iline": segy_inline_field,
        "xline": segy_crossline_field,
        "strict": segy_strict,
    }
    if interpolate_horizon:
        raise ValueError("interpolate_horizon目前只支持ZGY属性体")
    if interval_mode:
        raise ValueError("层间模式当前仅支持ZGY属性体")
    if str(horizon_unit).lower() not in {"samples", "sample", "index"}:
        raise ValueError("非SEG-Y体没有采样时间元数据，horizon_unit必须为samples")
    if npz_key is not None:
        load_kwargs["key"] = npz_key
    volumes = [load_volume(path, **load_kwargs) for path in input_paths]

    if any(volume.shape != volumes[0].shape for volume in volumes[1:]):
        raise ValueError("所有属性体shape必须一致")

    horizon_value = (
        horizon_value * float(horizon_scale)
        + float(horizon_offset)
        + float(horizon_shift)
    )

    sample_sets = []
    position_sets = []
    for volume in volumes:
        samples, positions = extract_windows(
            volume,
            horizon_value,
            window=window,
            stride=stride,
            sampling=sampling,
            inline_slice=inline_slice,
            crossline_slice=crossline_slice,
            skip_invalid_horizon=skip_invalid_horizon,
        )
        sample_sets.append(samples)
        position_sets.append(positions)

    for positions in position_sets[1:]:
        equal_or_not(position_sets[0], positions)

    raw = np.concatenate(sample_sets, axis=1)
    normalized, stats = normalize_samples(
        raw, normalize, stats=normalization_stats, return_stats=True,
    )
    if return_normalization:
        if return_masks:
            return normalized, position_sets[0], volumes[0].shape, stats, _default_masks(normalized.shape[0])
        return normalized, position_sets[0], volumes[0].shape, stats
    return normalized, position_sets[0], volumes[0].shape


def save_samples(output, samples, positions, input_paths, volume_shape, parameters, normalization_stats=None, masks=None):
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    parameters = dict(parameters)
    if normalization_stats is not None and "_selected_window" in normalization_stats:
        parameters["window_max"] = parameters.get("window")
        parameters["window"] = int(normalization_stats["_selected_window"])
        for key in (
            "_selected_window_points", "_interval_coverage", "_interval_target_coverage",
            "_interval_coverage_met", "_interval_coverage_curve", "_interval_denominator",
            "_sample_count", "_unsafe_count", "_padding_count", "_array_oob_count",
            "_interval_unsafe_count", "direction_unsafe_count", "lower_invalid_count",
            "invalid_attribute_count", "_horizon_alignment",
        ):
            if key in normalization_stats:
                parameters[key.lstrip("_")] = normalization_stats[key]
    metadata = {
        "inputs": [str(Path(path).resolve()) for path in input_paths],
        "volume_shape": list(volume_shape),
        "sample_shape": list(samples.shape),
        "parameters": parameters,
        "mask_names": sorted(str(name) for name in dict(masks or {})),
    }
    if normalization_stats is not None:
        normalization = {
            "method": str(normalization_stats["method"]),
            "per_attribute": bool(normalization_stats.get("per_attribute", True)),
            "attribute_count": int(normalization_stats.get("attribute_count", samples.shape[1])),
            "center": np.asarray(normalization_stats["center"], dtype=np.float32).tolist(),
            "scale": np.asarray(normalization_stats["scale"], dtype=np.float32).tolist(),
        }
        for key in ("lower", "upper"):
            if key in normalization_stats:
                normalization[key] = np.asarray(normalization_stats[key], dtype=np.float32).tolist()
        metadata["normalization"] = normalization
    arrays = {
        "samples": samples.astype(np.float32),
        "positions": positions.astype(np.int64),
        "attribute_names": np.asarray([Path(path).stem for path in input_paths]),
        "metadata": np.asarray(json.dumps(metadata, ensure_ascii=False)),
    }
    if normalization_stats is not None:
        arrays["normalization_center"] = np.asarray(normalization_stats["center"], dtype=np.float32)
        arrays["normalization_scale"] = np.asarray(normalization_stats["scale"], dtype=np.float32)
        arrays["normalization_method"] = np.asarray(str(normalization_stats["method"]))
        for key in ("lower", "upper"):
            if key in normalization_stats:
                arrays[f"normalization_{key}"] = np.asarray(normalization_stats[key], dtype=np.float32)
    for name, values in dict(masks or {}).items():
        values = np.asarray(values)
        if values.shape != (samples.shape[0],):
            raise ValueError(f"mask {name}必须是一维样本mask，实际为{values.shape}")
        arrays[f"mask_{name}"] = values.astype(bool, copy=False)
    np.savez_compressed(output, **arrays)


def _range_pair(values):
    if values is None:
        return None
    return int(values[0]), int(values[1])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", action="append", required=True)
    parser.add_argument("--shape", nargs=3, type=int)
    parser.add_argument("--dtype", default="float32")
    parser.add_argument("--endian", default="native")
    parser.add_argument("--order", default="C", choices=["C", "F"])
    parser.add_argument("--npz-key", default=None)
    parser.add_argument("--segy-inline-field", type=int, default=189)
    parser.add_argument("--segy-crossline-field", type=int, default=193)
    parser.add_argument(
        "--segy-strict",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    parser.add_argument("--horizon", type=float, default=50)
    parser.add_argument("--horizon-file", default=None)
    parser.add_argument("--upper-horizon-file", default=None)
    parser.add_argument("--lower-horizon-file", default=None)
    parser.add_argument("--horizon-shape", nargs=2, type=int)
    parser.add_argument("--horizon-dtype", default="float32")
    parser.add_argument("--horizon-endian", default="native")
    parser.add_argument("--horizon-order", default="C", choices=["C", "F"])
    parser.add_argument("--horizon-key", default=None)
    parser.add_argument("--horizon-scale", type=float, default=1.0)
    parser.add_argument("--horizon-offset", type=float, default=0.0)
    parser.add_argument("--horizon-shift", type=float, default=0.0)
    parser.add_argument("--interval-fraction", type=float, default=0.5)
    parser.add_argument("--interval-margin", type=float, default=1.0)
    parser.add_argument(
        "--interval-center-mode",
        choices=["equal", "weighted", "upper_biased", "lower_biased"],
        default="equal",
    )
    parser.add_argument(
        "--interval-window-mode",
        choices=["global_min", "fixed", "upper_anchor_coverage", "upper_anchor_down", "downward_coverage"],
        default="global_min",
    )
    parser.add_argument("--interval-coverage", type=float, default=0.90)
    parser.add_argument("--interval-anchor-offset", type=float, default=0.0)
    parser.add_argument("--interval-padding-mode", choices=["edge", "zero"], default="edge")
    parser.add_argument("--horizon-unit", choices=["ms", "s", "samples"], default="samples")
    parser.add_argument("--horizon-coordinates", choices=["inline_crossline", "world"], default="inline_crossline")
    parser.add_argument("--max-fill-distance-factor", type=float, default=2.0)
    parser.add_argument("--low-confidence-distance-factor", type=float, default=1.0)
    parser.add_argument(
        "--crop-to-common",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    parser.add_argument(
        "--fill-horizon-nans",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    parser.add_argument("--segy-inline-origin", type=float)
    parser.add_argument("--segy-crossline-origin", type=float)
    parser.add_argument("--segy-inline-step", type=float)
    parser.add_argument("--segy-crossline-step", type=float)
    parser.add_argument("--skip-invalid-horizon", action="store_true")
    parser.add_argument("--window", type=int, default=8)
    parser.add_argument("--stride", nargs=2, type=int, default=[1, 1])
    parser.add_argument(
        "--sampling",
        choices=["integer", "linear"],
        default="integer",
    )
    parser.add_argument(
        "--normalize",
        choices=["per_attribute", "source", "xnorm", "none", "zscore", "robust"],
        default="source",
    )
    parser.add_argument("--inline-range", nargs=2, type=int)
    parser.add_argument("--crossline-range", nargs=2, type=int)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    samples, positions, volume_shape, stats = prepare_samples(
        args.input,
        shape=tuple(args.shape) if args.shape else None,
        dtype=args.dtype,
        endian=args.endian,
        order=args.order,
        npz_key=args.npz_key,
        segy_inline_field=args.segy_inline_field,
        segy_crossline_field=args.segy_crossline_field,
        segy_strict=args.segy_strict,
        horizon=args.horizon,
        window=args.window,
        stride=(args.stride[0], args.stride[1]),
        sampling=args.sampling,
        normalize=args.normalize,
        inline_slice=_range_pair(args.inline_range),
        crossline_slice=_range_pair(args.crossline_range),
        horizon_file=args.horizon_file,
        horizon_shape=tuple(args.horizon_shape) if args.horizon_shape else None,
        horizon_dtype=args.horizon_dtype,
        horizon_endian=args.horizon_endian,
        horizon_order=args.horizon_order,
        horizon_key=args.horizon_key,
        horizon_scale=args.horizon_scale,
        horizon_offset=args.horizon_offset,
        horizon_shift=args.horizon_shift,
        skip_invalid_horizon=args.skip_invalid_horizon,
        horizon_unit=args.horizon_unit,
        horizon_coordinates=args.horizon_coordinates,
        max_fill_distance_factor=args.max_fill_distance_factor,
        low_confidence_distance_factor=args.low_confidence_distance_factor,
        upper_horizon_file=args.upper_horizon_file,
        lower_horizon_file=args.lower_horizon_file,
        crop_to_common=args.crop_to_common,
        fill_horizon_nans=args.fill_horizon_nans,
        interval_center_mode=args.interval_center_mode,
        interval_fraction=args.interval_fraction,
        interval_margin=args.interval_margin,
        interval_window_mode=args.interval_window_mode,
        interval_coverage=args.interval_coverage,
        interval_anchor_offset=args.interval_anchor_offset,
        interval_padding_mode=args.interval_padding_mode,
        segy_axes=(
            args.segy_inline_origin,
            args.segy_crossline_origin,
            args.segy_inline_step,
            args.segy_crossline_step,
        ) if all(value is not None for value in (
            args.segy_inline_origin,
            args.segy_crossline_origin,
            args.segy_inline_step,
            args.segy_crossline_step,
        )) else None,
        return_normalization=True,
    )
    parameters = {
        "shape": args.shape,
        "dtype": args.dtype,
        "endian": args.endian,
        "order": args.order,
        "segy_inline_field": args.segy_inline_field,
        "segy_crossline_field": args.segy_crossline_field,
        "segy_strict": args.segy_strict,
        "horizon": args.horizon,
        "window": args.window,
        "stride": args.stride,
        "sampling": args.sampling,
        "normalize": args.normalize,
        "horizon_file": str(Path(args.horizon_file).resolve()) if args.horizon_file else None,
        "upper_horizon_file": str(Path(args.upper_horizon_file).resolve()) if args.upper_horizon_file else None,
        "lower_horizon_file": str(Path(args.lower_horizon_file).resolve()) if args.lower_horizon_file else None,
        "interval_center_mode": args.interval_center_mode,
        "horizon_scale": args.horizon_scale,
        "horizon_offset": args.horizon_offset,
        "horizon_shift": args.horizon_shift,
        "interval_fraction": args.interval_fraction,
        "interval_margin": args.interval_margin,
        "interval_window_mode": args.interval_window_mode,
        "interval_coverage": args.interval_coverage,
        "interval_anchor_offset": args.interval_anchor_offset,
        "interval_padding_mode": args.interval_padding_mode,
        "horizon_unit": args.horizon_unit,
        "horizon_coordinates": args.horizon_coordinates,
        "max_fill_distance_factor": args.max_fill_distance_factor,
        "low_confidence_distance_factor": args.low_confidence_distance_factor,
        "crop_to_common": args.crop_to_common,
        "fill_horizon_nans": args.fill_horizon_nans,
        "skip_invalid_horizon": args.skip_invalid_horizon,
    }
    save_samples(
        args.output,
        samples,
        positions,
        args.input,
        volume_shape,
        parameters,
        normalization_stats=stats,
    )
    print("samples shape:", samples.shape)
    print("positions shape:", positions.shape)
    print("finite:", bool(np.isfinite(samples).all()))
    print("output:", Path(args.output).resolve())


if __name__ == "__main__":
    main()
