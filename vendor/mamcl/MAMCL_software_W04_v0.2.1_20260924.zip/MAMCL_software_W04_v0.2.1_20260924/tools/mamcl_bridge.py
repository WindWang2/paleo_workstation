from __future__ import annotations

import random
import os
import sys
from pathlib import Path

import numpy as np


RESOURCE_ROOT = Path(os.environ.get(
    "MAMCL_RESOURCE_ROOT",
    getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]),
))
SOURCE = RESOURCE_ROOT / "seismicfacies" / "src" / "seismicface"
SOURCE_TEXT = str(SOURCE)
if SOURCE_TEXT in sys.path:
    sys.path.remove(SOURCE_TEXT)
sys.path.insert(0, SOURCE_TEXT)


def _torch():
    try:
        import torch
    except ImportError as exc:
        raise ImportError("MAMCL运行需要PyTorch及其依赖") from exc
    return torch


def set_seed(seed):
    torch = _torch()
    seed = int(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def install_actual_attention():
    import math
    torch = _torch()
    from layers.SelfAttention_Family import FullAttention
    if getattr(FullAttention, "_mamcl_actual_attention", False):
        return
    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None):
        _, _, _, embedding = queries.shape
        scale = (
            self.scale.to(queries.device) / math.sqrt(embedding)
            if isinstance(self.scale, torch.Tensor)
            else (self.scale / math.sqrt(embedding) if self.scale is not None else 1.0 / math.sqrt(embedding))
        )
        scores = torch.einsum("blhe,bshe->bhls", queries, keys)
        if attn_mask is not None:
            scores = scores.masked_fill(attn_mask, -torch.inf)
        weight = self.weight
        if isinstance(weight, torch.Tensor):
            weight = weight.to(queries.device)
        logits = scale * scores + weight
        actual = torch.softmax(logits, dim=-1)
        dropped = self.dropout(actual)
        output = torch.einsum("bhls,bshd->blhd", dropped, values)
        collect_attention = getattr(self, "_mamcl_collect_attention", True)
        return output.contiguous(), actual.detach().clone() if self.output_attention and collect_attention else None

    FullAttention.forward = forward
    FullAttention._mamcl_actual_attention = True


def choose_device(requested="auto"):
    torch = _torch()
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("请求了CUDA，但当前PyTorch环境不可用CUDA")
    return device


def _configured_gaussian_sigma():
    try:
        import config
        return float(getattr(config, "GAUSSIAN_SIGMA", 1.5))
    except Exception:
        return 1.5


def _configured_gaussian_peak_mode():
    try:
        import config
        return str(getattr(config, "GAUSSIAN_PEAK_MODE", "center"))
    except Exception:
        return "center"


def _configured_dcl_topk():
    try:
        import config
        return int(getattr(config, "DCL_TOPK", 0))
    except Exception:
        return 0


def _configured_dcl_position_weighting():
    try:
        import config
        return bool(getattr(config, "DCL_POSITION_WEIGHTING", False))
    except Exception:
        return False


def _configured_spatial_consistency():
    try:
        import config
        return {
            "enabled": bool(getattr(config, "SPATIAL_CONSISTENCY_ENABLED", True)),
            "weight": float(getattr(config, "SPATIAL_CONSISTENCY_WEIGHT", 0.03)),
            "neighbors": int(getattr(config, "SPATIAL_CONSISTENCY_NEIGHBORS", 4)),
            "distance_scale": float(getattr(config, "SPATIAL_CONSISTENCY_DISTANCE_SCALE", 16.0)),
        }
    except Exception:
        return {"enabled": True, "weight": 0.03, "neighbors": 4, "distance_scale": 16.0}


def gaussian_window_values(encoder):
    window = getattr(encoder[1], "window", None)
    if window is None:
        return None
    if hasattr(window, "detach"):
        window = window.detach().cpu().numpy()
    return np.asarray(window, dtype=np.float32).reshape(-1)


def _configured_well_supervision():
    try:
        import config
        return {
            "enabled": bool(getattr(config, "WELL_SUPERVISION_ENABLED", False)),
            "weight": float(getattr(config, "WELL_LOSS_WEIGHT", 0.20)),
        }
    except Exception:
        return {"enabled": False, "weight": 0.20}


def optimizer_scheduler_info(algorithm):
    groups = getattr(algorithm.optimizer, "param_groups", [])
    info = {
        "optimizer": type(algorithm.optimizer).__name__,
        "actual_learning_rates": [float(group.get("lr", 0.0)) for group in groups],
        "warmup_scheduler": None,
        "main_scheduler": None,
        "dcl_topk": int(getattr(getattr(algorithm, "dcl", None), "topk", 0)),
        "dcl_position_weighting_applied": bool(
            getattr(getattr(algorithm, "dcl", None), "position_weighting_applied", False)
        ),
        "spatial_consistency": {
            "enabled": bool(getattr(algorithm, "spatial_consistency_enabled", False)),
            "weight": float(getattr(algorithm, "spatial_consistency_weight", 0.0)),
            "neighbors": int(getattr(getattr(algorithm, "spatial_consistency", None), "neighbors", 0)),
            "distance_scale": float(getattr(getattr(algorithm, "spatial_consistency", None), "distance_scale", 0.0)),
        },
        "well_supervision": {"enabled": bool(getattr(algorithm, "well_supervision_enabled", False)), "weight": float(getattr(algorithm, "well_loss_weight", 0.0))},
    }
    warmup = getattr(algorithm, "warmupscheduler", None)
    if warmup is not None:
        info["warmup_scheduler"] = {
            "class": type(warmup).__name__,
            "last_epoch": int(getattr(warmup, "last_epoch", -1)),
            "base_lrs": [float(value) for value in getattr(warmup, "base_lrs", [])],
        }
    main = getattr(algorithm, "mainscheduler", None)
    if main is not None:
        info["main_scheduler"] = {
            "class": type(main).__name__,
            "last_epoch": int(getattr(main, "last_epoch", -1)),
            "base_lrs": [float(value) for value in getattr(main, "base_lrs", [])],
            "eta_min": float(getattr(main, "eta_min", 0.0)),
            "T_0": int(getattr(main, "T_0", 0)),
        }
    return info


def _apply_gaussian_sigma(encoder, seqlen, sigma, peak_mode=None):
    if sigma is None:
        return
    sigma = float(sigma)
    if sigma <= 0:
        raise ValueError("GAUSSIAN_SIGMA必须大于0")
    token_transformer = encoder[1]
    if not hasattr(token_transformer, "gauss_window"):
        raise AttributeError("当前iTransformer没有gauss_window方法")
    if peak_mode is None:
        peak_mode = _configured_gaussian_peak_mode()
    token_transformer.window = token_transformer.gauss_window(
        int(seqlen), sigma, peak_mode=peak_mode,
    )
    token_transformer.window.requires_grad = False


def build_encoder(samples_shape, gaussian_sigma=None, gaussian_peak_mode=None):
    install_actual_attention()
    from encoder_list import transformer_encoder

    if len(samples_shape) != 4:
        raise ValueError("samples_shape必须是[N,M,ext,L]")
    _, attributes, ext, seqlen = [int(x) for x in samples_shape]
    if ext != 1:
        raise ValueError("当前原始transformer_encoder适配器要求ext=1")
    encoder = transformer_encoder(attributes, seqlen=seqlen, ext=ext)
    if gaussian_sigma is None:
        gaussian_sigma = _configured_gaussian_sigma()
    _apply_gaussian_sigma(encoder, seqlen, gaussian_sigma, gaussian_peak_mode)
    return encoder


def build_algorithm(samples_shape, spatial_shape, batch_size, device, lr=0.2, gaussian_sigma=None):
    from ssl_algorithms import ts_tcc_channelT

    encoder = build_encoder(samples_shape, gaussian_sigma=gaussian_sigma)
    algorithm = ts_tcc_channelT(
        64,
        encoder,
        tuple(int(x) for x in spatial_shape[:2]),
        device=device,
        batch_size=batch_size,
        lr=lr,
    )
    target_lr = float(lr)
    try:
        import config
    except ImportError:
        config = None
    warmup_epochs = max(int(getattr(config, "LR_WARMUP_EPOCHS", 10)), 1)
    scheduler_t0 = max(int(getattr(config, "LR_SCHEDULER_T0", 500)), 1)
    min_factor = float(getattr(config, "LR_MIN_FACTOR", 0.25))
    if not 0.0 <= min_factor <= 1.0:
        raise ValueError("LR_MIN_FACTOR必须在[0,1]范围内")
    groups = algorithm.optimizer.param_groups
    for group in groups:
        group["lr"] = target_lr
    warmup = getattr(algorithm, "warmupscheduler", None)
    if warmup is not None:
        warmup.lr_lambdas = [
            (lambda epoch, n=warmup_epochs: min((epoch + 1) / float(n), 1.0))
            for _ in warmup.lr_lambdas
        ]
        warmup.base_lrs = [target_lr] * len(groups)
        warmup.last_epoch = 0
        warmup._last_lr = [target_lr / float(warmup_epochs)] * len(groups)
        for group in groups:
            group["lr"] = target_lr / float(warmup_epochs)
    main = getattr(algorithm, "mainscheduler", None)
    if main is not None:
        main.base_lrs = [target_lr] * len(groups)
        main.T_0 = scheduler_t0
        main.T_i = scheduler_t0
        main.T_cur = -1
        if hasattr(main, "eta_min"):
            main.eta_min = target_lr * min_factor
    dcl = getattr(algorithm, "dcl", None)
    if dcl is not None:
        dcl.topk = _configured_dcl_topk()
        dcl.position_weighting_applied = _configured_dcl_position_weighting()
        if dcl.topk < 0 or dcl.topk >= int(batch_size):
            raise ValueError(
                f"DCL_TOPK必须在[0, batch_size)范围内：{dcl.topk}"
            )
    well = _configured_well_supervision()
    if well["weight"] < 0:
        raise ValueError("WELL_LOSS_WEIGHT不能小于0")
    algorithm.well_supervision_enabled = well["enabled"]
    algorithm.well_loss_weight = well["weight"]
    spatial = _configured_spatial_consistency()
    if spatial["weight"] < 0:
        raise ValueError("SPATIAL_CONSISTENCY_WEIGHT不能小于0")
    if spatial["neighbors"] < 1:
        raise ValueError("SPATIAL_CONSISTENCY_NEIGHBORS必须大于0")
    if spatial["distance_scale"] <= 0:
        raise ValueError("SPATIAL_CONSISTENCY_DISTANCE_SCALE必须大于0")
    algorithm.spatial_consistency_enabled = spatial["enabled"]
    algorithm.spatial_consistency_weight = spatial["weight"]
    if hasattr(algorithm, "spatial_consistency"):
        algorithm.spatial_consistency.neighbors = spatial["neighbors"]
        algorithm.spatial_consistency.distance_scale = spatial["distance_scale"]
    return algorithm.to(device)


def extract_h(encoder, samples, device, batch_size=64):
    torch = _torch()
    fe, te = encoder
    fe = fe.to(device).eval()
    te = te.to(device).eval()
    outputs = []
    tensor = torch.as_tensor(samples, dtype=torch.float32)
    with torch.inference_mode():
        for start in range(0, tensor.shape[0], batch_size):
            batch = tensor[start:start + batch_size].to(device, non_blocking=True)
            features, _ = fe(batch, mode="notrain")
            token, _ = te(features, epoch=50, attn_mask=None)
            outputs.append(token.reshape(token.shape[0], -1).cpu())
    return torch.cat(outputs, dim=0).numpy()


def save_checkpoint(path, algorithm, config=None, epoch=0):
    torch = _torch()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "fe": algorithm.encoder.state_dict(),
        "te": algorithm.token_transformer.state_dict(),
        "projection_head": algorithm.projection_head.state_dict(),
        "cls": algorithm.cls.state_dict(),
        "optimizer": algorithm.optimizer.state_dict(),
        "warmup_scheduler": getattr(algorithm, "warmupscheduler", None).state_dict() if getattr(algorithm, "warmupscheduler", None) is not None else None,
        "main_scheduler": getattr(algorithm, "mainscheduler", None).state_dict() if getattr(algorithm, "mainscheduler", None) is not None else None,
        "input_contract": getattr(algorithm, "input_contract", None),
        "epoch": int(epoch),
        "config": dict(config or {}),
    }
    torch.save(payload, path)
    return path


def load_algorithm_checkpoint(path, algorithm, device):
    torch = _torch()
    payload = torch.load(path, map_location=device)
    algorithm.encoder.load_state_dict(payload["fe"])
    algorithm.token_transformer.load_state_dict(payload["te"])
    algorithm.projection_head.load_state_dict(payload["projection_head"])
    algorithm.cls.load_state_dict(payload["cls"])
    if payload.get("optimizer") is not None:
        algorithm.optimizer.load_state_dict(payload["optimizer"])
    if payload.get("warmup_scheduler") is not None and getattr(algorithm, "warmupscheduler", None) is not None:
        algorithm.warmupscheduler.load_state_dict(payload["warmup_scheduler"])
    if payload.get("main_scheduler") is not None and getattr(algorithm, "mainscheduler", None) is not None:
        algorithm.mainscheduler.load_state_dict(payload["main_scheduler"])
    return payload, int(payload.get("epoch", 0))


def load_encoder_checkpoint(path, samples_shape, device):
    torch = _torch()
    payload = torch.load(path, map_location=device)
    contract = payload.get("input_contract") or {}
    encoder = build_encoder(
        samples_shape,
        gaussian_sigma=contract.get("gaussian_sigma"),
        gaussian_peak_mode=contract.get("gaussian_peak_mode"),
    )
    encoder[0].load_state_dict(payload["fe"])
    encoder[1].load_state_dict(payload["te"])
    return tuple(module.to(device).eval() for module in encoder), payload
