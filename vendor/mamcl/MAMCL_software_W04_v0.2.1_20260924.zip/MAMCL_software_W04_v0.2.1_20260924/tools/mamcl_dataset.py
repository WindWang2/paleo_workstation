from __future__ import annotations

import numpy as np


def _torch():
    try:
        import torch
        from torch.utils.data import DataLoader, Dataset
    except ImportError as exc:
        raise ImportError("mamcl_dataset需要在PyTorch环境中运行") from exc
    return torch, DataLoader, Dataset


def make_dataset(samples, positions, noise_std=0.2, well_labels=None, well_weights=None, well_mask=None):
    torch, _, Dataset = _torch()
    samples = np.asarray(samples, dtype=np.float32)
    positions = np.asarray(positions, dtype=np.int64)
    if samples.ndim != 4 or positions.shape != (samples.shape[0], 2):
        raise ValueError("samples或positions形状不符合[N,M,1,L]与[N,2]")
    if noise_std < 0:
        raise ValueError("noise_std不能小于0")
    optional = {}
    if well_labels is not None:
        optional["well_labels"] = np.asarray(well_labels, dtype=np.float32)
        if optional["well_labels"].shape[0] != samples.shape[0]:
            raise ValueError("well_labels样本数与samples不一致")
    if well_weights is not None:
        optional["well_weights"] = np.asarray(well_weights, dtype=np.float32).reshape(-1)
    if well_mask is not None:
        optional["well_mask"] = np.asarray(well_mask, dtype=bool).reshape(-1)
    for key, values in optional.items():
        if values.shape[0] != samples.shape[0]:
            raise ValueError(f"{key}样本数与samples不一致")

    class _Dataset(Dataset):
        def __len__(self):
            return samples.shape[0]

        def __getitem__(self, index):
            original = torch.from_numpy(samples[index])
            view1 = original + noise_std * torch.randn_like(original)
            view2 = original + noise_std * torch.randn_like(original)
            result = {
                "transformed_samples": [view1, view2],
                "position": torch.from_numpy(positions[index]),
                "sample_ori": original,
            }
            for key, values in optional.items():
                item = values[index]
                if isinstance(item, np.generic):
                    item = item.item()
                result[key] = torch.as_tensor(item)
            return result

    return _Dataset()


def make_dataloader(samples, positions, batch_size=32, noise_std=0.2, shuffle=True, drop_last=True, num_workers=0, well_labels=None, well_weights=None, well_mask=None):
    torch, DataLoader, _ = _torch()
    if batch_size <= 0:
        raise ValueError("batch_size必须大于0")
    dataset = make_dataset(samples, positions, noise_std=noise_std, well_labels=well_labels, well_weights=well_weights, well_mask=well_mask)
    if drop_last and len(dataset) < batch_size:
        raise ValueError("样本数小于batch_size，无法满足原始DCLW的固定批大小要求")
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        drop_last=drop_last,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
    )
