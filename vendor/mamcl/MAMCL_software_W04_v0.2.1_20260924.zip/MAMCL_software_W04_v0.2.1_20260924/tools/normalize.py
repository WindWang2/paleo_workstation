import numpy as np


def fit_normalization(samples, method="source"):
    samples = np.asarray(samples, dtype=np.float32)
    if samples.ndim != 4 or not np.isfinite(samples).all():
        raise ValueError("samples必须是有限的[N,M,ext,L]数组")

    method = str(method).lower()
    centers = []
    scales = []
    lowers = []
    uppers = []
    for attribute in range(samples.shape[1]):
        current = samples[:, attribute]
        if method in {"source", "xnorm", "per_attribute"}:
            lower, upper = np.percentile(current, [1.0, 99.0])
            current = np.clip(current, lower, upper)
            lowers.append(float(lower))
            uppers.append(float(upper))
            center = float(np.mean(current, dtype=np.float64))
            scale = float(np.std(current, dtype=np.float64))
        elif method == "zscore":
            center = float(np.mean(current, dtype=np.float64))
            scale = float(np.std(current, dtype=np.float64))
        elif method == "robust":
            center = float(np.median(current))
            scale = float(1.4826 * np.median(np.abs(current - center)))
        elif method == "none":
            center, scale = 0.0, 1.0
        else:
            raise ValueError("method必须是per_attribute、source、xnorm、zscore、robust或none")
        if scale <= np.finfo(np.float32).eps:
            raise ValueError(f"属性{attribute}尺度过小，无法归一化")
        centers.append(center)
        scales.append(scale)

    stats = {
        "method": method,
        "per_attribute": True,
        "attribute_count": int(samples.shape[1]),
        "center": np.asarray(centers, dtype=np.float32),
        "scale": np.asarray(scales, dtype=np.float32),
    }
    if method in {"source", "xnorm", "per_attribute"}:
        stats["lower"] = np.asarray(lowers, dtype=np.float32)
        stats["upper"] = np.asarray(uppers, dtype=np.float32)
    return stats


def apply_normalization(samples, stats):
    samples = np.asarray(samples, dtype=np.float32)
    if samples.ndim != 4 or not np.isfinite(samples).all():
        raise ValueError("samples必须是有限的[N,M,ext,L]数组")
    method = str(stats.get("method", "source")).lower()
    center = np.asarray(stats["center"], dtype=np.float32)
    scale = np.asarray(stats["scale"], dtype=np.float32)
    if center.shape != (samples.shape[1],) or scale.shape != center.shape:
        raise ValueError("归一化参数数量与属性数量不一致")
    if np.any(scale <= np.finfo(np.float32).eps):
        raise ValueError("归一化scale必须为正")
    values = samples
    if method in {"source", "xnorm", "per_attribute"} and "lower" in stats and "upper" in stats:
        lower = np.asarray(stats["lower"], dtype=np.float32)
        upper = np.asarray(stats["upper"], dtype=np.float32)
        if lower.shape != center.shape or upper.shape != center.shape:
            raise ValueError("归一化截断参数数量与属性数量不一致")
        values = np.clip(values, lower[None, :, None, None], upper[None, :, None, None])
    return ((values - center[None, :, None, None]) /
            scale[None, :, None, None]).astype(np.float32)


def normalize_samples(samples, method="source", stats=None, return_stats=False):
    method = str(method).lower()
    if stats is None:
        stats = fit_normalization(samples, method)
    elif str(stats.get("method", method)).lower() != method:
        raise ValueError("归一化方法与已有参数不一致")
    normalized = apply_normalization(samples, stats)
    if return_stats:
        return normalized, stats
    return normalized
