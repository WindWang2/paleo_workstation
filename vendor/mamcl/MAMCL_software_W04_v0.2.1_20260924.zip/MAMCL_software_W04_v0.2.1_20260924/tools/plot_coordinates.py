from __future__ import annotations

from pathlib import Path
from collections import OrderedDict

import numpy as np


_COORDINATE_CACHE = OrderedDict()
_COORDINATE_CACHE_LIMIT = 2


def _index_coordinates(shape: tuple[int, int]) -> dict:
    rows, cols = (int(shape[0]), int(shape[1]))
    inline = np.arange(rows, dtype=np.float64)
    crossline = np.arange(cols, dtype=np.float64)
    x, y = np.meshgrid(crossline, inline, indexing="xy")
    return {
        "x": x,
        "y": y,
        "xlabel": "crossline index",
        "ylabel": "inline index",
        "mode": "index",
        "source": "array indices",
        "inline_origin": 0.0,
        "inline_step": 1.0,
        "crossline_origin": 0.0,
        "crossline_step": 1.0,
    }


def _zgy_coordinates(path: Path, shape: tuple[int, int], mode: str) -> dict:
    try:
        from pyzgy.accessors import SeismicReader
    except ImportError as exc:
        raise ImportError("绘制ZGY真实坐标需要安装pyzgy") from exc

    with SeismicReader(str(path)) as reader:
        full_shape = (int(reader.n_ilines), int(reader.n_xlines))
        origin = tuple(float(value) for value in reader.annotstart)
        step = tuple(float(value) for value in reader.annotinc)
        if len(origin) != 2 or len(step) != 2 or any(value <= 0 for value in step):
            raise ValueError("ZGY水平坐标起点或步长无效")
        rows, cols = (int(shape[0]), int(shape[1]))
        if rows > full_shape[0] or cols > full_shape[1]:
            raise ValueError(f"输出空间shape {shape} 大于ZGY空间shape {full_shape}")
        inline_values = origin[0] + np.arange(rows, dtype=np.float64) * step[0]
        crossline_values = origin[1] + np.arange(cols, dtype=np.float64) * step[1]
        inline_grid, crossline_grid = np.meshgrid(inline_values, crossline_values, indexing="ij")

        if mode == "inline_crossline":
            return {
                "x": crossline_grid,
                "y": inline_grid,
                "xlabel": "Crossline",
                "ylabel": "Inline",
                "mode": "inline_crossline",
                "source": str(path.resolve()),
                "inline_origin": origin[0],
                "inline_step": step[0],
                "crossline_origin": origin[1],
                "crossline_step": step[1],
            }

        corners = getattr(reader, "corners", None)
        corners = np.asarray(corners, dtype=np.float64) if corners is not None else None
        if corners is None or corners.ndim != 2 or corners.shape[0] < 3 or corners.shape[1] < 2:
            raise ValueError("ZGY文件没有至少三个有效物理X/Y角点")
        if not np.isfinite(corners[:, :2]).all():
            raise ValueError("ZGY物理X/Y角点包含NaN或Inf")
        inline_increment = (corners[1, :2] - corners[0, :2]) / float(max(full_shape[0] - 1, 1))
        crossline_increment = (corners[2, :2] - corners[0, :2]) / float(max(full_shape[1] - 1, 1))
        row_indices, col_indices = np.indices((rows, cols), dtype=np.float64)
        world_x = corners[0, 0] + row_indices * inline_increment[0] + col_indices * crossline_increment[0]
        world_y = corners[0, 1] + row_indices * inline_increment[1] + col_indices * crossline_increment[1]
        return {
            "x": world_x,
            "y": world_y,
            "xlabel": "X coordinate",
            "ylabel": "Y coordinate",
            "mode": "world",
            "source": str(path.resolve()),
            "inline_origin": origin[0],
            "inline_step": step[0],
            "crossline_origin": origin[1],
            "crossline_step": step[1],
            "corners": corners[:, :2].tolist(),
        }


def _npz_coordinates(path: Path, shape: tuple[int, int], mode: str) -> dict:
    with np.load(path, allow_pickle=False) as archive:
        if "x" not in archive.files or "y" not in archive.files:
            raise ValueError("NPZ没有x/y坐标数组")
        x = np.asarray(archive["x"], dtype=np.float64)
        y = np.asarray(archive["y"], dtype=np.float64)
    if x.ndim == 1 and y.ndim == 1:
        if x.size != shape[1] or y.size != shape[0]:
            raise ValueError("NPZ一维x/y坐标长度与空间shape不一致")
        x, y = np.meshgrid(x, y, indexing="xy")
    if x.shape != shape or y.shape != shape:
        raise ValueError(f"NPZ坐标shape与空间shape不一致：{x.shape}, {y.shape}, {shape}")
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("NPZ坐标包含NaN或Inf")
    return {
        "x": x,
        "y": y,
        "xlabel": "X coordinate" if mode == "world" else "x",
        "ylabel": "Y coordinate" if mode == "world" else "y",
        "mode": mode,
        "source": str(path.resolve()),
    }


def _segy_coordinates(
    path: Path,
    shape: tuple[int, int],
    mode: str,
    inline_field: int,
    crossline_field: int,
    source_x_field: int,
    source_y_field: int,
    coordinate_scalar_field: int,
) -> dict:
    """Build a map-grid coordinate surface from SEG-Y trace headers."""
    try:
        import segyio
    except ImportError as exc:
        raise ImportError("绘制SEG-Y真实坐标需要安装segyio") from exc

    from segy_windows import _axis_values

    with segyio.open(str(path), strict=False, ignore_geometry=True) as handle:
        trace_count = int(handle.tracecount)
        axes = _axis_values(
            None, path, int(inline_field), int(crossline_field), shape
        )
        inline_origin, crossline_origin, inline_step, crossline_step = axes
        rows, cols = shape
        inline_values = inline_origin + np.arange(rows, dtype=np.float64) * inline_step
        crossline_values = crossline_origin + np.arange(cols, dtype=np.float64) * crossline_step
        inline_grid, crossline_grid = np.meshgrid(inline_values, crossline_values, indexing="ij")
        if mode == "inline_crossline":
            return {
                "x": crossline_grid,
                "y": inline_grid,
                "xlabel": "Crossline",
                "ylabel": "Inline",
                "mode": "inline_crossline",
                "source": str(path.resolve()),
                "inline_origin": inline_origin,
                "inline_step": inline_step,
                "crossline_origin": crossline_origin,
                "crossline_step": crossline_step,
            }

        world_x = np.full(shape, np.nan, dtype=np.float64)
        world_y = np.full(shape, np.nan, dtype=np.float64)
        counts = np.zeros(shape, dtype=np.uint16)
        for trace_index in range(trace_count):
            header = handle.header[trace_index]
            iline = int(header[int(inline_field)])
            xline = int(header[int(crossline_field)])
            row_float = (iline - inline_origin) / inline_step
            col_float = (xline - crossline_origin) / crossline_step
            row, col = int(round(row_float)), int(round(col_float))
            if (abs(row_float - row) > 1e-5 or abs(col_float - col) > 1e-5
                    or not (0 <= row < rows and 0 <= col < cols)):
                continue
            scalar = int(header[int(coordinate_scalar_field)])
            factor = float(scalar) if scalar > 0 else (1.0 / abs(scalar) if scalar < 0 else 1.0)
            x = float(header[int(source_x_field)]) * factor
            y = float(header[int(source_y_field)]) * factor
            if not np.isfinite((x, y)).all():
                continue
            if counts[row, col] == 0:
                world_x[row, col], world_y[row, col] = x, y
            else:
                world_x[row, col] += x
                world_y[row, col] += y
            counts[row, col] += 1

    known = counts > 0
    if int(known.sum()) < 3:
        raise ValueError("SEG-Y道头中可用的SourceX/SourceY坐标不足")
    world_x[known] /= counts[known]
    world_y[known] /= counts[known]
    # Fit an affine survey transform and use it only to fill missing headers;
    # actual trace coordinates remain untouched.
    rr, cc = np.indices(shape, dtype=np.float64)
    design = np.column_stack((np.ones(int(known.sum())), rr[known], cc[known]))
    coefficients_x, *_ = np.linalg.lstsq(design, world_x[known], rcond=None)
    coefficients_y, *_ = np.linalg.lstsq(design, world_y[known], rcond=None)
    missing = ~known
    if missing.any():
        missing_design = np.column_stack((np.ones(int(missing.sum())), rr[missing], cc[missing]))
        world_x[missing] = missing_design @ coefficients_x
        world_y[missing] = missing_design @ coefficients_y
    return {
        "x": world_x,
        "y": world_y,
        "xlabel": "X coordinate",
        "ylabel": "Y coordinate",
        "mode": "world",
        "source": str(path.resolve()),
        "inline_origin": inline_origin,
        "inline_step": inline_step,
        "crossline_origin": crossline_origin,
        "crossline_step": crossline_step,
        "trace_count": trace_count,
        "mapped_trace_cells": int(known.sum()),
        "coordinate_scalar_field": int(coordinate_scalar_field),
    }


def load_plot_coordinates(
    path: str | Path | None,
    shape: tuple[int, int] | list[int],
    mode: str = "world",
    allow_fallback: bool = True,
    segy_inline_field: int = 9,
    segy_crossline_field: int = 21,
    segy_source_x_field: int = 73,
    segy_source_y_field: int = 77,
    segy_coordinate_scalar_field: int = 71,
) -> dict:
    """Return a 2-D coordinate grid aligned with [inline, crossline] data."""
    shape = (int(shape[0]), int(shape[1]))
    if len(shape) != 2 or any(value <= 0 for value in shape):
        raise ValueError(f"坐标空间shape无效：{shape}")
    mode = str(mode or "world").lower()
    if mode not in {"world", "inline_crossline", "index"}:
        raise ValueError("plot coordinate mode must be world, inline_crossline, or index")
    if mode == "index" or path is None:
        return _index_coordinates(shape)
    path = Path(path)
    try:
        stat = path.stat()
        cache_key = (
            str(path.resolve()), stat.st_size, stat.st_mtime_ns, shape, mode,
            int(segy_inline_field), int(segy_crossline_field), int(segy_source_x_field),
            int(segy_source_y_field), int(segy_coordinate_scalar_field),
        )
        if cache_key in _COORDINATE_CACHE:
            _COORDINATE_CACHE.move_to_end(cache_key)
            return _COORDINATE_CACHE[cache_key]
        if path.suffix.lower() == ".zgy":
            result = _zgy_coordinates(path, shape, mode)
        elif path.suffix.lower() in {".sgy", ".segy"}:
            result = _segy_coordinates(
                path, shape, mode, segy_inline_field, segy_crossline_field,
                segy_source_x_field, segy_source_y_field, segy_coordinate_scalar_field,
            )
        elif path.suffix.lower() == ".npz":
            result = _npz_coordinates(path, shape, mode)
        else:
            raise ValueError(f"文件格式没有可读取的真实空间坐标：{path.suffix}")
    except (ImportError, OSError, ValueError, TypeError) as exc:
        if not allow_fallback:
            raise
        fallback = _index_coordinates(shape)
        fallback["fallback_reason"] = f"{type(exc).__name__}: {exc}"
        fallback["requested_mode"] = mode
        result = fallback
    if "cache_key" in locals():
        _COORDINATE_CACHE[cache_key] = result
        _COORDINATE_CACHE.move_to_end(cache_key)
        while len(_COORDINATE_CACHE) > _COORDINATE_CACHE_LIMIT:
            _COORDINATE_CACHE.popitem(last=False)
    return result


def crop_coordinates(coordinates: dict, bbox: tuple[int, int, int, int]) -> dict:
    row0, row1, col0, col1 = (int(value) for value in bbox)
    x = np.asarray(coordinates["x"])[row0:row1, col0:col1]
    y = np.asarray(coordinates["y"])[row0:row1, col0:col1]
    result = dict(coordinates)
    result["x"] = x
    result["y"] = y
    result["crop_bbox"] = [row0, row1, col0, col1]
    return result


def coordinate_metadata(coordinates: dict) -> dict:
    result = {
        "mode": str(coordinates.get("mode", "index")),
        "source": coordinates.get("source"),
        "xlabel": coordinates.get("xlabel"),
        "ylabel": coordinates.get("ylabel"),
        "shape": list(np.asarray(coordinates["x"]).shape),
    }
    for key in ("inline_origin", "inline_step", "crossline_origin", "crossline_step", "requested_mode", "fallback_reason", "crop_bbox"):
        if key in coordinates:
            value = coordinates[key]
            result[key] = value.item() if isinstance(value, np.ndarray) and value.ndim == 0 else value
    if "corners" in coordinates:
        result["corners"] = coordinates["corners"]
    x = np.asarray(coordinates["x"], dtype=float)
    y = np.asarray(coordinates["y"], dtype=float)
    if np.isfinite(x).any() and np.isfinite(y).any():
        result["x_range"] = [float(np.nanmin(x)), float(np.nanmax(x))]
        result["y_range"] = [float(np.nanmin(y)), float(np.nanmax(y))]
    return result
