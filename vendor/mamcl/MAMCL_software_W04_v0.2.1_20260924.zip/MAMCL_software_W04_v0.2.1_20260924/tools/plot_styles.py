from __future__ import annotations

from pathlib import Path

from well_overlay import scatter_wells

import numpy as np


CLUSTER_COLOR_PALETTE = (
    "#1E88E5",
    "#FFB300",
    "#00A878",
    "#F01818",
    "#8E44AD",
    "#00ACC1",
    "#EC407A",
    "#7CB342",
    "#8D6E63",
)


def paper_cluster_colors(clusters: int):
    clusters = int(clusters)
    if clusters <= 0:
        raise ValueError("clusters必须大于0")
    if clusters <= len(CLUSTER_COLOR_PALETTE):
        return list(CLUSTER_COLOR_PALETTE[:clusters])
    import matplotlib.pyplot as plt

    cmap = plt.get_cmap("tab20", clusters)
    return [cmap(index) for index in range(clusters)]


def cluster_color_metadata(clusters: int):
    colors = paper_cluster_colors(clusters)
    return {
        "class_index_base": 0,
        "class_colors": {str(index): str(color) for index, color in enumerate(colors)},
        "display_labels": {str(index): f"Class {index + 1}" for index in range(len(colors))},
    }


def display_bbox(*arrays):
    masks = []
    for array in arrays:
        if array is None:
            continue
        value = np.asarray(array)
        if value.ndim != 2:
            raise ValueError("display_bbox只接受二维数组")
        if np.issubdtype(value.dtype, np.integer):
            masks.append(value >= 0)
        else:
            masks.append(np.isfinite(value))
    if not masks:
        raise ValueError("display_bbox没有输入数组")
    mask = np.logical_or.reduce(masks)
    indices = np.argwhere(mask)
    if indices.size == 0:
        return (0, mask.shape[0], 0, mask.shape[1])
    row0, col0 = indices.min(axis=0)
    row1, col1 = indices.max(axis=0) + 1
    return int(row0), int(row1), int(col0), int(col1)


def crop_2d(array, bbox):
    row0, row1, col0, col1 = bbox
    return np.asarray(array)[row0:row1, col0:col1]


def save_paper_cluster_map(
    grid,
    clusters,
    output_path,
    base=None,
    title=None,
    overlay_alpha=0.82,
    dpi=400,
    coordinates=None,
    well_points=None,
    well_style=None,
):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, Normalize
    from matplotlib.cm import ScalarMappable
    from matplotlib.colors import ListedColormap

    grid = np.asarray(grid)
    if grid.ndim != 2:
        raise ValueError("grid必须是二维数组")
    clusters = int(clusters)
    if clusters <= 1:
        raise ValueError("clusters必须大于1")
    if base is not None:
        base = np.asarray(base)
        if base.shape != grid.shape:
            raise ValueError("base与grid形状不一致")
    bbox = display_bbox(grid, base)
    cropped_grid = crop_2d(grid, bbox)
    cropped_base = crop_2d(base, bbox) if base is not None else None
    if coordinates is None:
        from plot_coordinates import load_plot_coordinates, crop_coordinates

        coordinates = load_plot_coordinates(None, grid.shape, mode="index")
    else:
        if not isinstance(coordinates, dict) or "x" not in coordinates or "y" not in coordinates:
            raise ValueError("coordinates必须包含x和y二维坐标网格")
        if np.asarray(coordinates["x"]).shape != grid.shape or np.asarray(coordinates["y"]).shape != grid.shape:
            raise ValueError("coordinates与grid形状不一致")
        from plot_coordinates import crop_coordinates
    cropped_coordinates = crop_coordinates(coordinates, bbox)
    x_coordinates = np.asarray(cropped_coordinates["x"], dtype=float)
    y_coordinates = np.asarray(cropped_coordinates["y"], dtype=float)

    figure, axis = plt.subplots(figsize=(12.0, 8.2), constrained_layout=False)
    figure.subplots_adjust(left=0.025, right=0.975, top=0.965, bottom=0.13)
    if cropped_base is not None and np.isfinite(cropped_base).any():
        finite = cropped_base[np.isfinite(cropped_base)].astype(np.float32)
        low, high = np.percentile(finite, [1.0, 99.0])
        if not np.isfinite(low) or not np.isfinite(high) or low == high:
            low, high = float(np.min(finite)), float(np.max(finite))
        if low == high:
            low, high = low - 1.0, high + 1.0
        from attribute_plots import _paper_colormap

        base_image = axis.pcolormesh(
            x_coordinates,
            y_coordinates,
            np.ma.masked_invalid(cropped_base),
            shading="auto",
            edgecolors="none",
            linewidth=0.0,
            antialiased=False,
            cmap=_paper_colormap(),
            norm=Normalize(vmin=low, vmax=high),
        )
        base_image.set_rasterized(True)

    colors = paper_cluster_colors(clusters)
    cluster_cmap = ListedColormap(colors, name=f"paper_clusters_{clusters}")
    cluster_cmap.set_bad((1.0, 1.0, 1.0, 0.0))
    norm = BoundaryNorm(np.arange(-0.5, clusters + 0.5, 1.0), clusters)
    labels = np.ma.masked_less(cropped_grid, 0)
    overlay = axis.pcolormesh(
        x_coordinates,
        y_coordinates,
        labels,
        shading="auto",
        edgecolors="none",
        linewidth=0.0,
        antialiased=False,
        cmap=cluster_cmap,
        norm=norm,
        alpha=float(overlay_alpha),
    )
    overlay.set_rasterized(True)
    scatter_wells(
        axis,
        well_points,
        cropped_coordinates,
        valid_mask=np.asarray(cropped_grid) >= 0,
        **dict(well_style or {}),
    )
    axis.set_xlabel(str(coordinates.get("xlabel", "X coordinate")))
    axis.set_ylabel(str(coordinates.get("ylabel", "Y coordinate")))
    axis.set_aspect("equal", adjustable="box")
    if title:
        axis.set_title(str(title), fontsize=14, pad=4)
    mapper = ScalarMappable(norm=norm, cmap=cluster_cmap)
    mapper.set_array(np.arange(clusters, dtype=np.float32))
    colorbar = figure.colorbar(
        mapper,
        ax=axis,
        orientation="horizontal",
        boundaries=np.arange(-0.5, clusters + 0.5, 1.0),
        ticks=np.arange(clusters),
        fraction=0.045,
        pad=0.035,
        aspect=42,
    )
    colorbar.ax.set_xticklabels([str(index + 1) for index in range(clusters)])
    colorbar.set_label("Class", labelpad=2)
    colorbar.ax.tick_params(length=2, pad=1, labelsize=9)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output_path, dpi=int(dpi), facecolor="white")
    plt.close(figure)
    return bbox
