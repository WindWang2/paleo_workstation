from __future__ import annotations

from pathlib import Path
import re
from typing import Sequence

import numpy as np


RAW_SUFFIXES = {".dat", ".bin", ".raw"}
SEGY_SUFFIXES = {".sgy", ".segy"}
INLINE_INVALID_Z_LIMIT = 1.0e12


def validate_volume(volume: np.ndarray, name: str = "volume") -> np.ndarray:


    if not isinstance(volume, np.ndarray):
        raise TypeError(f"{name} 必须是 numpy.ndarray")
    if volume.ndim != 3:
        raise ValueError(f"{name} 必须是三维数组，实际 ndim={volume.ndim}")
    if not np.issubdtype(volume.dtype, np.number):
        raise TypeError(f"{name} 必须是数值数组，实际 dtype={volume.dtype}")
    if not np.isfinite(volume).all():
        raise ValueError(f"{name} 包含 NaN 或 Inf")
    return volume


def read_npy_volume(path: str | Path) -> np.ndarray:

    path = Path(path)
    if path.suffix.lower() != ".npy":
        raise ValueError("read_npy_volume 只接受 .npy 文件")
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path}")

    volume = np.asarray(np.load(path, allow_pickle=False))
    return validate_volume(volume, str(path))


def read_npz_volume(
    path: str | Path,
    key: str | None = None,
) -> np.ndarray:

    path = Path(path)
    if path.suffix.lower() != ".npz":
        raise ValueError("read_npz_volume 只接受 .npz 文件")
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path}")

    with np.load(path, allow_pickle=False) as archive:
        keys = list(archive.files)
        if key is None:
            if len(keys) != 1:
                raise ValueError(
                    f"NPZ包含多个数组 {keys}，请指定 key"
                )
            key = keys[0]
        if key not in keys:
            raise KeyError(f"NPZ中找不到 key={key!r}，可用键为 {keys}")
        volume = np.asarray(archive[key])

    return validate_volume(volume, f"{path}:{key}")


def _byte_order(endian: str) -> str:
    aliases = {
        "big": ">",
        "be": ">",
        ">": ">",
        "little": "<",
        "le": "<",
        "<": "<",
        "native": "=",
        "=": "=",
    }
    try:
        return aliases[endian.lower()]
    except KeyError as exc:
        raise ValueError(
            "endian 必须是 big、little、native、> 或 <"
        ) from exc


def read_raw_volume(
    path: str | Path,
    shape: Sequence[int],
    dtype: str | np.dtype,
    endian: str,
    order: str = "C",
) -> np.ndarray:

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path}")

    shape = tuple(int(value) for value in shape)
    if len(shape) != 3 or any(value <= 0 for value in shape):
        raise ValueError(f"shape必须是三个正整数，实际为 {shape}")
    if order not in {"C", "F"}:
        raise ValueError("order 只能是 'C' 或 'F'")

    file_dtype = np.dtype(dtype).newbyteorder(_byte_order(endian))
    values = np.fromfile(path, dtype=file_dtype)
    expected = int(np.prod(shape))
    if values.size != expected:
        raise ValueError(
            f"文件元素数不匹配：实际 {values.size}，期望 {expected}；"
            "请检查shape、dtype、文件完整性"
        )

    native_dtype = np.dtype(dtype).newbyteorder("=")
    volume = values.reshape(shape, order=order).astype(
        native_dtype,
        copy=False,
    )
    return validate_volume(volume, str(path))


def read_segy_volume(
    path: str | Path,
    iline: int = 189,
    xline: int = 193,
    strict: bool = True,
    **kwargs,
) -> np.ndarray:

    del kwargs
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path}")
    try:
        import segyio  # type: ignore
    except ImportError as exc:
        raise ImportError(
            "读取SEG-Y需要安装segyio，或先将SEG-Y导出为.npy"
        ) from exc

    with segyio.open(
        str(path),
        iline=int(iline),
        xline=int(xline),
        strict=bool(strict),
    ) as handle:
        volume = np.asarray(segyio.tools.cube(handle))
    return validate_volume(volume, str(path))


def read_surface(
    path: str | Path,
    shape: Sequence[int] | None = None,
    dtype: str | np.dtype = "float32",
    endian: str = "native",
    order: str = "C",
    key: str | None = None,
    allow_invalid: bool = False,
) -> np.ndarray:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path}")
    suffix = path.suffix.lower()
    smi_horizon = suffix in RAW_SUFFIXES and _looks_like_smi_horizon(path)
    inline_horizon = suffix in RAW_SUFFIXES and _looks_like_inline_horizon(path)
    if suffix == ".npy":
        surface = np.asarray(np.load(path, allow_pickle=False))
    elif suffix == ".npz":
        with np.load(path, allow_pickle=False) as archive:
            keys = list(archive.files)
            selected = key
            if selected is None:
                if len(keys) != 1:
                    raise ValueError(f"NPZ包含多个数组 {keys}，请指定key")
                selected = keys[0]
            if selected not in keys:
                raise KeyError(f"NPZ中找不到key={selected!r}")
            surface = np.asarray(archive[selected])
    elif smi_horizon:
        surface = read_smi_horizon(path, shape=shape)
    elif inline_horizon:
        surface = read_inline_horizon(path, shape=shape)
    elif suffix in RAW_SUFFIXES:
        if shape is None or len(tuple(shape)) != 2:
            raise ValueError("二维裸二进制层位必须提供shape=(n_inline,n_crossline)")
        shape = tuple(int(value) for value in shape)
        file_dtype = np.dtype(dtype).newbyteorder(_byte_order(endian))
        values = np.fromfile(path, dtype=file_dtype)
        expected = int(np.prod(shape))
        if values.size != expected:
            raise ValueError(f"层位元素数不匹配：实际{values.size}，期望{expected}")
        native_dtype = np.dtype(dtype).newbyteorder("=")
        surface = values.reshape(shape, order=order).astype(native_dtype, copy=False)
    else:
        raise ValueError(f"不支持的层位文件格式：{suffix}")
    if surface.ndim != 2:
        raise ValueError(f"层位必须是二维数组，实际shape={surface.shape}")
    if not np.issubdtype(surface.dtype, np.number):
        raise TypeError("层位必须是数值数组")
    if not allow_invalid and not smi_horizon and not inline_horizon and not np.isfinite(surface).all():
        raise ValueError("层位包含NaN或Inf")
    return surface


def _looks_like_smi_horizon(path: Path) -> bool:
    with path.open("rb") as handle:
        prefix = handle.read(1024 * 1024)
    prefix = prefix.lstrip(b"\xef\xbb\xbf \t\r\n")
    return prefix.startswith(b"# XYZInlineCrossline")


def _looks_like_inline_horizon(path: Path) -> bool:
    with path.open("rb") as handle:
        prefix = handle.read(1024 * 1024).decode("utf-8", errors="ignore")
    return re.search(r"\bINLINE\s*:\s*[-+]?\d+(?:\.\d+)?\s+XLINE\s*[:;]", prefix, re.IGNORECASE) is not None


def _iter_inline_rows(path: Path):
    pattern = re.compile(
        r"INLINE\s*:\s*([-+]?\d+(?:\.\d+)?)\s+"
        r"XLINE\s*[:;]\s*([-+]?\d+(?:\.\d+)?)\s+"
        r"([-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?)\s+"
        r"([-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?)\s+"
        r"([-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?)",
        re.IGNORECASE,
    )
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            match = pattern.search(line)
            if match is None:
                continue
            inline, crossline, _, _, z = (float(value) for value in match.groups())
            yield z, inline, crossline


def _iter_inline_world_rows(path: Path):
    pattern = re.compile(
        r"INLINE\s*:\s*([-+]?\d+(?:\.\d+)?)\s+"
        r"XLINE\s*[:;]\s*([-+]?\d+(?:\.\d+)?)\s+"
        r"([-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?)\s+"
        r"([-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?)\s+"
        r"([-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?)",
        re.IGNORECASE,
    )
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            match = pattern.search(line)
            if match is None:
                continue
            inline, crossline, x, y, z = (float(value) for value in match.groups())
            yield z, inline, crossline, x, y


def read_inline_horizon(path: str | Path, shape: Sequence[int] | None = None) -> np.ndarray:
    path = Path(path)
    rows = list(_iter_inline_rows(path))
    if not rows:
        raise ValueError(f"INLINE/XLINE层位没有有效数据行：{path}")
    inlines = np.unique(np.asarray([row[1] for row in rows]))
    crosslines = np.unique(np.asarray([row[2] for row in rows]))
    output_shape = tuple(int(value) for value in shape) if shape is not None else (inlines.size, crosslines.size)
    if output_shape != (inlines.size, crosslines.size):
        raise ValueError(f"层位shape与INLINE/XLINE网格不一致：{output_shape} != {(inlines.size, crosslines.size)}")
    inline_index = {value: index for index, value in enumerate(inlines)}
    crossline_index = {value: index for index, value in enumerate(crosslines)}
    total = np.zeros(output_shape, dtype=np.float64)
    count = np.zeros(output_shape, dtype=np.int32)
    for z, inline, crossline in rows:
        if not np.isfinite(z) or abs(z) > INLINE_INVALID_Z_LIMIT:
            continue
        i = inline_index[inline]
        j = crossline_index[crossline]
        total[i, j] += z
        count[i, j] += 1
    surface = np.full(output_shape, np.nan, dtype=np.float32)
    valid = count > 0
    surface[valid] = (total[valid] / count[valid]).astype(np.float32)
    return surface


def read_inline_horizon_world(
    path: str | Path,
    shape: Sequence[int] | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    path = Path(path)
    rows = list(_iter_inline_world_rows(path))
    if not rows:
        raise ValueError(f"INLINE/XLINE层位没有有效物理坐标行：{path}")
    inlines = np.unique(np.asarray([row[1] for row in rows], dtype=np.float64))
    crosslines = np.unique(np.asarray([row[2] for row in rows], dtype=np.float64))
    output_shape = tuple(int(value) for value in shape) if shape is not None else (inlines.size, crosslines.size)
    if output_shape != (inlines.size, crosslines.size):
        raise ValueError(
            f"层位shape与INLINE/XLINE网格不一致：{output_shape} != {(inlines.size, crosslines.size)}"
        )
    inline_index = {value: index for index, value in enumerate(inlines)}
    crossline_index = {value: index for index, value in enumerate(crosslines)}
    z_total = np.zeros(output_shape, dtype=np.float64)
    xy_total = np.zeros((*output_shape, 2), dtype=np.float64)
    count = np.zeros(output_shape, dtype=np.int32)
    for z, inline, crossline, x, y in rows:
        if not np.isfinite(z) or abs(z) > INLINE_INVALID_Z_LIMIT:
            continue
        if not np.isfinite(x) or not np.isfinite(y):
            continue
        i = inline_index[inline]
        j = crossline_index[crossline]
        z_total[i, j] += z
        xy_total[i, j, 0] += x
        xy_total[i, j, 1] += y
        count[i, j] += 1
    surface = np.full(output_shape, np.nan, dtype=np.float32)
    world_x = np.full(output_shape, np.nan, dtype=np.float64)
    world_y = np.full(output_shape, np.nan, dtype=np.float64)
    valid = count > 0
    surface[valid] = (z_total[valid] / count[valid]).astype(np.float32)
    world_x[valid] = xy_total[valid, 0] / count[valid]
    world_y[valid] = xy_total[valid, 1] / count[valid]
    if not valid.any():
        raise ValueError(f"INLINE/XLINE层位没有有效物理坐标：{path}")
    return surface, world_x, world_y


def read_inline_axes(path: str | Path):
    path = Path(path)
    rows = list(_iter_inline_rows(path))
    if not rows:
        raise ValueError(f"INLINE/XLINE层位没有有效坐标：{path}")
    inlines = np.unique(np.asarray([row[1] for row in rows], dtype=np.float64))
    crosslines = np.unique(np.asarray([row[2] for row in rows], dtype=np.float64))
    if inlines.size < 1 or crosslines.size < 1:
        raise ValueError("INLINE/XLINE层位坐标为空")
    inline_step = float(np.median(np.diff(inlines))) if inlines.size > 1 else 1.0
    crossline_step = float(np.median(np.diff(crosslines))) if crosslines.size > 1 else 1.0
    if inline_step <= 0 or crossline_step <= 0:
        raise ValueError("INLINE/XLINE层位坐标步长无效")
    return float(inlines[0]), float(crosslines[0]), inline_step, crossline_step


def _smi_header(path: Path):
    grid_shape = None
    reference = {}
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line.startswith("#"):
                break
            match = re.search(r"Grid_size:\s*(\d+)x(\d+)", line)
            if match:
                grid_shape = (int(match.group(1)), int(match.group(2)))
            match = re.match(r"#\s*P([123]):\s*([^,]+),\s*([^,]+),", line)
            if match:
                reference[int(match.group(1))] = (
                    float(match.group(2)),
                    float(match.group(3)),
                )
    return grid_shape, reference


def _iter_smi_rows(path: Path):
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            text = line.strip()
            if not text or text.startswith("#"):
                continue
            fields = text.split()
            if len(fields) < 5:
                continue
            try:
                yield (
                    float(fields[2]),
                    float(fields[3]),
                    float(fields[4]),
                )
            except ValueError:
                continue


def read_smi_horizon(
    path: str | Path,
    shape: Sequence[int] | None = None,
) -> np.ndarray:
    path = Path(path)
    header_shape, reference = _smi_header(path)
    requested_shape = tuple(int(value) for value in shape) if shape is not None else None
    if requested_shape is not None and len(requested_shape) != 2:
        raise ValueError("SMI层位shape必须是二维")
    output_shape = requested_shape or header_shape
    inline_values = []
    crossline_values = []
    for _, inline, crossline in _iter_smi_rows(path):
        inline_values.append(inline)
        crossline_values.append(crossline)
    if not inline_values:
        raise ValueError(f"SMI层位没有有效数据行：{path}")
    inline_unique = np.unique(np.asarray(inline_values))
    crossline_unique = np.unique(np.asarray(crossline_values))
    if output_shape is None:
        output_shape = (inline_unique.size, crossline_unique.size)
    if len(output_shape) != 2 or any(value <= 0 for value in output_shape):
        raise ValueError(f"无法确定SMI层位shape：{output_shape}")

    if 1 in reference and 2 in reference:
        inline_origin = reference[1][0]
        crossline_origin = reference[1][1]
        crossline_span = reference[2][1] - reference[1][1]
    else:
        inline_origin = float(inline_unique.min())
        crossline_origin = float(crossline_unique.min())
        crossline_span = 0.0
    if 2 in reference and 3 in reference:
        inline_span = reference[3][0] - reference[2][0]
    else:
        inline_span = 0.0
    if output_shape[0] > 1 and inline_span != 0.0:
        inline_step = inline_span / (output_shape[0] - 1)
    else:
        differences = np.diff(inline_unique)
        inline_step = float(np.median(differences[differences > 0])) if np.any(differences > 0) else 1.0
    if output_shape[1] > 1 and crossline_span != 0.0:
        crossline_step = crossline_span / (output_shape[1] - 1)
    else:
        differences = np.diff(crossline_unique)
        crossline_step = float(np.median(differences[differences > 0])) if np.any(differences > 0) else 1.0

    total = np.zeros(output_shape, dtype=np.float64)
    count = np.zeros(output_shape, dtype=np.int32)
    for z, inline, crossline in _iter_smi_rows(path):
        inline_index = int(round((inline - inline_origin) / inline_step))
        crossline_index = int(round((crossline - crossline_origin) / crossline_step))
        if not (0 <= inline_index < output_shape[0] and 0 <= crossline_index < output_shape[1]):
            continue
        total[inline_index, crossline_index] += z
        count[inline_index, crossline_index] += 1
    surface = np.full(output_shape, np.nan, dtype=np.float32)
    valid = count > 0
    surface[valid] = (total[valid] / count[valid]).astype(np.float32)
    return surface


def read_smi_axes(path: str | Path, shape: Sequence[int] | None = None):
    path = Path(path)
    if _looks_like_inline_horizon(path):
        return read_inline_axes(path)
    if not _looks_like_smi_horizon(path):
        return None
    header_shape, reference = _smi_header(path)
    output_shape = tuple(int(value) for value in shape) if shape is not None else header_shape
    if output_shape is None or len(output_shape) != 2:
        raise ValueError("无法确定SMI层位空间shape")
    if not {1, 2, 3}.issubset(reference):
        raise ValueError("SMI层位缺少P1/P2/P3空间参考点")
    inline_origin = reference[1][0]
    crossline_origin = reference[1][1]
    inline_step = (reference[3][0] - reference[2][0]) / max(output_shape[0] - 1, 1)
    crossline_step = (reference[2][1] - reference[1][1]) / max(output_shape[1] - 1, 1)
    if inline_step <= 0 or crossline_step <= 0:
        raise ValueError("SMI层位空间步长必须为正")
    return (
        float(inline_origin), float(crossline_origin),
        float(inline_step), float(crossline_step),
    )


def load_surface(path: str | Path, **kwargs) -> np.ndarray:
    return read_surface(path, **kwargs)


def load_volume(path: str | Path, **kwargs) -> np.ndarray:

    suffix = Path(path).suffix.lower()
    if suffix == ".npy":
        return read_npy_volume(path)
    if suffix == ".npz":
        return read_npz_volume(path, key=kwargs.get("key"))
    if suffix in RAW_SUFFIXES:
        raw_keys = {"shape", "dtype", "endian", "order"}
        raw_kwargs = {key: kwargs[key] for key in raw_keys if key in kwargs}
        return read_raw_volume(path, **raw_kwargs)
    if suffix in SEGY_SUFFIXES:
        return read_segy_volume(path, **kwargs)
    raise ValueError(
        f"不支持的文件格式 {suffix!r}；支持.npy/.npz/.dat/.bin/.raw/.sgy/.segy"
    )
