import hashlib
import os
import ast
import struct
import json
import shutil
import zipfile
import sys
import traceback
import re
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

import numpy as np


@contextmanager
def capture_log(path):
    class Tee:
        def __init__(self, original, handle):
            self.original, self.handle = original, handle
        def write(self, text):
            self.original.write(text)
            self.handle.write(text)
            self.handle.flush()
            return len(text)
        def flush(self):
            self.original.flush()
            self.handle.flush()
        def isatty(self):
            return False
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    original_out, original_err = sys.stdout, sys.stderr
    with path.open('a', encoding='utf-8') as handle:
        sys.stdout, sys.stderr = Tee(original_out, handle), Tee(original_err, handle)
        try:
            yield
        except BaseException:
            traceback.print_exc()
            raise
        finally:
            sys.stdout, sys.stderr = original_out, original_err


def bundle_metadata(path):
    with np.load(path, allow_pickle=False) as archive:
        return json.loads(str(archive['metadata'].item()))


def fingerprint(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def file_info(path):
    path = Path(path)
    info = {'path': str(path), 'exists': path.is_file()}
    if not info['exists']:
        return info
    info['bytes'] = path.stat().st_size
    def header(handle):
        version = np.lib.format.read_magic(handle)
        width = 2 if version == (1, 0) else 4
        length = struct.unpack('<H' if width == 2 else '<I', handle.read(width))[0]
        if length > 1048576:
            raise ValueError('NPY header too large')
        parsed = ast.literal_eval(handle.read(length).decode('utf-8' if version == (3, 0) else 'latin1'))
        return {'shape': list(parsed['shape']), 'dtype': str(np.dtype(parsed['descr'])), 'fortran_order': parsed['fortran_order']}
    try:
        if path.suffix == '.npy':
            with path.open('rb') as handle:
                info.update(header(handle))
        elif path.suffix == '.npz':
            with zipfile.ZipFile(path) as archive:
                info['arrays'] = {}
                for name in archive.namelist():
                    if name.endswith('.npy'):
                        with archive.open(name) as handle:
                            info['arrays'][name[:-4]] = header(handle)
    except Exception as error:
        info['inspection_error'] = str(error)
    return info


def _load_run_settings(run_dir):
    path = Path(run_dir) / 'run_all_settings.json'
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _slug(value, fallback):
    text = str(value or fallback).strip()
    text = re.sub(r'[^0-9A-Za-z._-]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('._-')
    return text or fallback


def _path_stem(value, fallback):
    if value is None or str(value).strip() in {'', 'None'}:
        return fallback
    return _slug(Path(str(value)).stem, fallback)


def _archive_name(run_dir):
    run_dir = Path(run_dir)
    settings = _load_run_settings(run_dir)
    timestamp = settings.get('RUN_TIMESTAMP') or settings.get('ARCHIVE_TIMESTAMP')
    if not timestamp:
        log_paths = sorted(run_dir.glob('run_*.log'))
        if log_paths:
            timestamp = log_paths[-1].stem.removeprefix('run_')
    if not timestamp:
        timestamp = datetime.now().astimezone().strftime('%Y%m%d_%H%M%S')
    timestamp = _slug(timestamp, datetime.now().strftime('%Y%m%d_%H%M%S'))
    epochs = _slug(settings.get('EPOCHS', 'na'), 'na')
    if settings.get('INTERVAL_MODE'):
        upper = _path_stem(settings.get('UPPER_HORIZON_FILE'), 'upper')
        lower = _path_stem(settings.get('LOWER_HORIZON_FILE'), 'lower')
        segment = f'{upper}_to_{lower}'
    else:
        segment = _path_stem(settings.get('HORIZON_FILE'), 'single_horizon')
    return f'MAMCL_{segment}_e{epochs}_{timestamp}.zip'


def _filesystem_path(path):
    value = str(Path(path).resolve())
    if os.name == 'nt' and not value.startswith('\\\\?\\'):
        return '\\\\?\\' + value
    return value


def package_results(run_dir):
    run_dir = Path(run_dir)
    result_dir = run_dir / 'result'
    output = run_dir / _archive_name(run_dir)
    print('packaging review archive:', output.resolve(), flush=True)
    for old in run_dir.glob('*results_for_review.zip'):
        if old != output:
            old.unlink()
    for old in (run_dir / 'result.zip', run_dir / 'results_for_review.zip'):
        if old != output and old.is_file():
            old.unlink()
    if result_dir.exists():
        shutil.rmtree(result_dir)
    result_dir.mkdir(parents=True, exist_ok=True)
    settings = _load_run_settings(run_dir)
    include_review_arrays = bool(settings.get('INCLUDE_REVIEW_ARRAYS', False))
    review_extensions = {'.png', '.jpg', '.jpeg', '.svg', '.pdf', '.log', '.txt', '.json', '.csv'}
    included = []
    excluded_large = []
    for path in sorted(run_dir.rglob('*')):
        if not path.is_file():
            continue
        if result_dir in path.parents or path == output:
            continue
        relative = path.relative_to(run_dir)
        include = path.suffix.lower() in review_extensions
        if include_review_arrays and relative.as_posix() == 'losses.npy':
            include = True
        if include_review_arrays and relative.parts and relative.parts[0] == 'analysis' and path.suffix.lower() == '.npy':
            include = True
        if include:
            destination = result_dir / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)
            included.append({'path': relative.as_posix(), 'bytes': int(path.stat().st_size)})
        elif path.suffix.lower() in {'.pt', '.npz', '.npy'}:
            excluded_large.append({'path': relative.as_posix(), 'bytes': int(path.stat().st_size)})
    manifest = {
        'format': 'MAMCL review result v1',
        'source_run_dir': str(run_dir.resolve()),
        'archive_name': output.name,
        'created': datetime.now().astimezone().isoformat(timespec='seconds'),
        'included_file_count': len(included),
        'included_files': included,
        'excluded_large_file_count': len(excluded_large),
        'excluded_large_files': excluded_large,
        'include_review_arrays': include_review_arrays,
        'excluded_reason': '原始样本、特征、聚类NPZ和checkpoint不复制到review结果包',
    }
    (result_dir / 'result_manifest.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8'
    )
    files = sorted(p for p in result_dir.rglob('*') if p.is_file())
    print('review files:', len(files), flush=True)
    temporary = output.with_suffix('.zip.tmp')
    with zipfile.ZipFile(_filesystem_path(temporary), 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            # PNG/JPEG files are already compressed; ZIP_STORED avoids spending
            # CPU recompressing them while preserving the same archive content.
            compression = (
                zipfile.ZIP_STORED
                if path.suffix.lower() in {'.png', '.jpg', '.jpeg'}
                else zipfile.ZIP_DEFLATED
            )
            archive.write(
                _filesystem_path(path),
                path.relative_to(result_dir).as_posix(),
                compress_type=compression,
            )
    os.replace(_filesystem_path(temporary), _filesystem_path(output))
    print('review archive bytes:', output.stat().st_size, flush=True)
    return output
