from __future__ import annotations

import argparse
import time
from result_io import fingerprint
import json
from pathlib import Path
import sys

import numpy as np

from dataset_io import load_bundle
from mamcl_bridge import (
    _torch,
    build_algorithm,
    build_encoder,
    choose_device,
    extract_h,
    load_algorithm_checkpoint,
    load_encoder_checkpoint,
    save_checkpoint,
    set_seed,
)
from mamcl_dataset import make_dataloader


def _interval_alignment(bundle):
    metadata = bundle.get("metadata", {})
    parameters = metadata.get("parameters", {}) if isinstance(metadata, dict) else {}
    alignment = parameters.get("horizon_alignment", {})
    return alignment if isinstance(alignment, dict) else {}


def _spatial_shape(bundle):
    alignment = _interval_alignment(bundle)
    crop_shape = alignment.get("crop_shape")
    if crop_shape is not None and len(crop_shape) >= 2:
        return tuple(int(x) for x in crop_shape[:2])
    metadata = bundle.get("metadata", {})
    volume_shape = metadata.get("volume_shape")
    if volume_shape is not None and len(volume_shape) >= 2:
        return tuple(int(x) for x in volume_shape[:2])
    positions = bundle["positions"]
    return tuple((positions.max(axis=0) + 1).tolist())


def _grid_positions(bundle):
    positions = np.asarray(bundle["positions"], dtype=np.int64)
    spatial = _spatial_shape(bundle)
    alignment = _interval_alignment(bundle)
    crop_index = alignment.get("crop_index")
    if crop_index is None or len(crop_index) != 4:
        local = positions
    else:
        row0, row1, col0, col1 = (int(value) for value in crop_index)
        absolute = (
            np.all(positions[:, 0] >= row0)
            and np.all(positions[:, 0] < row1)
            and np.all(positions[:, 1] >= col0)
            and np.all(positions[:, 1] < col1)
        )
        already_local = (
            np.all(positions[:, 0] >= 0)
            and np.all(positions[:, 0] < spatial[0])
            and np.all(positions[:, 1] >= 0)
            and np.all(positions[:, 1] < spatial[1])
        )
        if absolute:
            local = positions - np.asarray([row0, col0], dtype=np.int64)
        elif already_local:
            local = positions
        else:
            raise ValueError(
                "positions既不在公共裁剪的全局范围内，也不是有效的裁剪局部坐标："
                f"crop_index={crop_index}, spatial={spatial}, "
                f"position_min={positions.min(axis=0).tolist()}, "
                f"position_max={positions.max(axis=0).tolist()}"
            )
    if (
        np.any(local < 0)
        or np.any(local[:, 0] >= spatial[0])
        or np.any(local[:, 1] >= spatial[1])
    ):
        raise ValueError("转换后的positions超出公共裁剪网格")
    return local


def _plot_coordinate_info(bundle, path, mode, allow_fallback=False):
    from plot_coordinates import crop_coordinates, load_plot_coordinates

    import config as runtime_config

    coordinate_options = {
        "segy_inline_field": getattr(runtime_config, "SEGY_INLINE_FIELD", 9),
        "segy_crossline_field": getattr(runtime_config, "SEGY_CROSSLINE_FIELD", 21),
        "segy_source_x_field": getattr(runtime_config, "SEGY_SOURCE_X_FIELD", 73),
        "segy_source_y_field": getattr(runtime_config, "SEGY_SOURCE_Y_FIELD", 77),
        "segy_coordinate_scalar_field": getattr(runtime_config, "SEGY_COORDINATE_SCALAR_FIELD", 71),
    }

    spatial = _spatial_shape(bundle)
    alignment = _interval_alignment(bundle)
    crop_index = alignment.get("crop_index")
    metadata = bundle.get("metadata", {})
    volume_shape = metadata.get("volume_shape") if isinstance(metadata, dict) else None
    if crop_index is not None and len(crop_index) == 4 and volume_shape is not None and len(volume_shape) >= 2:
        full_shape = tuple(int(value) for value in volume_shape[:2])
        coordinates = load_plot_coordinates(
            path, full_shape, mode=mode, allow_fallback=allow_fallback, **coordinate_options
        )
        coordinates = crop_coordinates(coordinates, tuple(int(value) for value in crop_index))
    else:
        coordinates = load_plot_coordinates(
            path, spatial, mode=mode, allow_fallback=allow_fallback, **coordinate_options
        )
    if np.asarray(coordinates["x"]).shape != spatial or np.asarray(coordinates["y"]).shape != spatial:
        raise ValueError(f"绘图坐标shape与聚类网格不一致：coordinates={np.asarray(coordinates['x']).shape}, grid={spatial}")
    return coordinates


def _attribute_plot_base(bundle, spatial_shape):
    samples = np.asarray(bundle["samples"], dtype=np.float32)
    parameters = bundle.get("metadata", {}).get("parameters", {})
    mode = str(parameters.get("interval_window_mode", "")).lower()
    sample_index = 0 if mode in {"upper_anchor_coverage", "upper_anchor_down", "downward_coverage"} else samples.shape[-1] // 2
    values = samples[:, 0, 0, sample_index].astype(np.float32, copy=True)
    normalization = bundle.get("metadata", {}).get("normalization")
    if normalization is not None:
        center = np.asarray(normalization.get("center"), dtype=np.float32)
        scale = np.asarray(normalization.get("scale"), dtype=np.float32)
        if center.ndim == 1 and center.shape[0] == samples.shape[1] and scale.shape == center.shape:
            values = values * scale[0] + center[0]
    result = np.full(tuple(int(value) for value in spatial_shape), np.nan, dtype=np.float32)
    positions = _grid_positions(bundle)
    result[positions[:, 0], positions[:, 1]] = values
    return result


def _move_batch(batch, device):
    result = {
        "transformed_samples": [x.to(device, non_blocking=True) for x in batch["transformed_samples"]],
        "position": batch["position"].to(device, non_blocking=True),
        "sample_ori": batch["sample_ori"].to(device, non_blocking=True),
    }
    for key in ("well_labels", "well_weights", "well_mask"):
        if key in batch:
            result[key] = batch[key].to(device, non_blocking=True)
    return result


def extract_h_and_attribute_attention(encoder, samples, device, batch_size=64):
    torch = _torch()
    samples = np.asarray(samples, dtype=np.float32)
    if samples.ndim != 4:
        raise ValueError("samples必须是[N,M,ext,L]四维数组")
    fe, te = encoder
    fe_was_training = fe.training
    te_was_training = te.training
    fe = fe.to(device).eval()
    te = te.to(device).eval()
    h_outputs = []
    attention_outputs = []
    attribute_count = int(samples.shape[1])
    with torch.inference_mode():
        tensor = torch.as_tensor(samples, dtype=torch.float32)
        for start in range(0, tensor.shape[0], batch_size):
            batch = tensor[start:start + batch_size].to(device, non_blocking=True)
            features, _ = fe(batch, mode="notrain")
            token, attention_layers = te(features, epoch=50, attn_mask=None)
            h_outputs.append(token.reshape(token.shape[0], -1).cpu())
            layer_weights = []
            for attention in attention_layers:
                if attention is None or attention.ndim != 4:
                    continue
                cls_to_tokens = attention[:, :, 0, 1:].mean(dim=1)
                token_count = int(cls_to_tokens.shape[1])
                if token_count % attribute_count != 0:
                    raise ValueError(
                        "Transformer token数不能按属性数整除："
                        f"tokens={token_count}, attributes={attribute_count}"
                    )
                tokens_per_attribute = token_count // attribute_count
                layer_weights.append(
                    cls_to_tokens.reshape(
                        cls_to_tokens.shape[0], attribute_count, tokens_per_attribute
                    ).sum(dim=-1)
                )
            if not layer_weights:
                raise ValueError("Transformer没有返回可记录的attention")
            attention_outputs.append(torch.stack(layer_weights, dim=0).mean(dim=0).cpu())
    fe.train(fe_was_training)
    te.train(te_was_training)
    return (
        torch.cat(h_outputs, dim=0).numpy().astype(np.float32),
        torch.cat(attention_outputs, dim=0).numpy().astype(np.float32),
    )


def _attribute_attention_from_algorithm(algorithm, steps):
    value = getattr(algorithm, "attn", None)
    if value is None:
        return None
    if hasattr(value, "detach"):
        value = value.detach().cpu().numpy()
    value = np.asarray(value, dtype=np.float32)
    count = int(getattr(algorithm, "attn_count", 0))
    return value / max(count if count > 0 else int(steps), 1)


def _similarity_from_algorithm(algorithm):
    values = getattr(algorithm, "dist", None)
    if not values:
        return np.empty(0, dtype=np.float32)
    converted = []
    for value in values:
        if hasattr(value, "detach"):
            value = value.detach().cpu().numpy()
        converted.append(np.asarray(value, dtype=np.float32).reshape(-1))
    if not converted:
        return np.empty(0, dtype=np.float32)
    return np.concatenate(converted, axis=0)


def _running_stats_summary(values):
    values = values or {}
    count = int(values.get("count", 0))
    if count <= 0:
        return {"count": 0, "mean": None, "std": None}
    mean = float(values.get("sum", 0.0)) / count
    variance = max(float(values.get("sum_sq", 0.0)) / count - mean * mean, 0.0)
    return {"count": count, "mean": mean, "std": float(np.sqrt(variance))}


def _array_stats_summary(values):
    values = np.asarray(values, dtype=np.float64).reshape(-1)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return {
            "count": 0, "mean": None, "std": None,
            "min": None, "max": None, "q05": None, "q50": None, "q95": None,
        }
    return {
        "count": int(values.size),
        "mean": float(values.mean()),
        "std": float(values.std()),
        "min": float(values.min()),
        "max": float(values.max()),
        "q05": float(np.percentile(values, 5)),
        "q50": float(np.percentile(values, 50)),
        "q95": float(np.percentile(values, 95)),
    }


def _algorithm_similarity_values(algorithm, name):
    diagnostics = getattr(algorithm, "mamcl_diagnostics", {}) or {}
    return np.asarray(diagnostics.get(name, []), dtype=np.float32)


def _algorithm_diagnostics(algorithm):
    raw = getattr(algorithm, "mamcl_diagnostics", {}) or {}
    mask = raw.get("mask", {})
    token_count_by_attribute = [int(value) for value in mask.get("token_count_by_attribute", [])]
    hidden_by_attribute = [int(value) for value in mask.get("hidden_by_attribute", [])]
    hidden_ratio_by_attribute = [
        float(hidden / count) if count else None
        for hidden, count in zip(hidden_by_attribute, token_count_by_attribute)
    ]
    return {
        "noise": _running_stats_summary(raw.get("noise")),
        "h": _running_stats_summary(raw.get("h")),
        "z": _running_stats_summary(raw.get("z")),
        "mask": {
            "batches": int(mask.get("batches", 0)),
            "hidden_count": int(mask.get("hidden_count", 0)),
            "token_count": int(mask.get("token_count", 0)),
            "hidden_ratio": (
                float(mask.get("hidden_count", 0)) / float(mask.get("token_count", 1))
                if mask.get("token_count", 0) else None
            ),
            "hidden_by_attribute": hidden_by_attribute,
            "token_count_by_attribute": token_count_by_attribute,
            "hidden_ratio_by_attribute": hidden_ratio_by_attribute,
        },
        "positive_similarity": _array_stats_summary(raw.get("positive_similarity", [])),
        "negative_similarity": _array_stats_summary(raw.get("negative_similarity", [])),
        "spatial_consistency": _running_stats_summary(raw.get("spatial_consistency")),
        "well_constraint": _running_stats_summary(raw.get("well_constraint")),
    }


def _write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )


def _limit_values(values, limit, seed):
    values = np.asarray(values, dtype=np.float32).reshape(-1)
    if limit <= 0 or values.size <= limit:
        return values
    indices = np.linspace(0, values.size - 1, int(limit), dtype=np.int64)
    return values[indices]


def _append_training_log(path, message):
    with Path(path).open("a", encoding="utf-8") as handle:
        handle.write(message.rstrip("\n") + "\n")


def _selected_plot_epochs(count):
    count = int(count)
    if count <= 0:
        return []
    if count >= 500:
        preferred = [5, 20, 40, 70, 500]
    elif count >= 70:
        preferred = [5, 20, 40, 70, count]
    else:
        preferred = np.rint(np.linspace(1, count, min(5, count))).astype(int).tolist()
    return sorted(set(max(1, min(count, int(epoch))) for epoch in preferred))


def _density_curve(values, x_grid):
    values = np.asarray(values, dtype=np.float64).reshape(-1)
    values = values[np.isfinite(values)]
    if values.size < 2 or np.allclose(values, values[0]):
        if values.size == 0:
            return np.zeros_like(x_grid), "empty"
        center = float(values[0])
        width = max((float(x_grid[-1]) - float(x_grid[0])) / 250.0, 1e-3)
        density = np.exp(-0.5 * ((x_grid - center) / width) ** 2)
        density /= max(float(np.trapezoid(density, x_grid)), 1e-12)
        return density, "gaussian fallback"
    try:
        from scipy.stats import gaussian_kde
        density = gaussian_kde(values)(x_grid)
        return np.asarray(density, dtype=np.float64), "Gaussian KDE"
    except Exception:
        histogram, edges = np.histogram(values, bins=120, range=(x_grid[0], x_grid[-1]), density=True)
        centers = (edges[:-1] + edges[1:]) * 0.5
        return np.interp(x_grid, centers, histogram, left=0.0, right=0.0), "normalized histogram fallback"


def _reduce_centers_2d(center_array):
    flattened = center_array.reshape(-1, center_array.shape[-1])
    try:
        from umap import UMAP
        reducer = UMAP(
            n_components=2,
            n_neighbors=min(15, max(2, flattened.shape[0] - 1)),
            min_dist=0.1,
            metric="euclidean",
            random_state=0,
        )
        coordinates = reducer.fit_transform(flattened)
        return coordinates.reshape(center_array.shape[0], center_array.shape[1], 2), "UMAP"
    except Exception:
        try:
            from sklearn.decomposition import PCA
            coordinates = PCA(n_components=2, random_state=0).fit_transform(flattened)
            return coordinates.reshape(center_array.shape[0], center_array.shape[1], 2), "PCA fallback (umap-learn unavailable)"
        except Exception:
            return center_array[..., :2], "first two h dimensions fallback"


def _match_centers(previous, current):
    if previous is None:
        return current
    try:
        from scipy.optimize import linear_sum_assignment
        distances = ((previous[:, None, :] - current[None, :, :]) ** 2).sum(axis=-1)
        _, columns = linear_sum_assignment(distances)
        return current[columns]
    except ImportError:
        remaining = list(range(current.shape[0]))
        order = []
        for point in previous:
            index = min(remaining, key=lambda item: float(((point - current[item]) ** 2).sum()))
            order.append(index)
            remaining.remove(index)
        return current[np.asarray(order, dtype=np.int64)]


def _extract_h_preserving_mode(algorithm, samples, device, batch_size):
    torch = _torch()
    fe, te = algorithm.encoder, algorithm.token_transformer
    fe_was_training = fe.training
    te_was_training = te.training
    fe.eval()
    te.eval()
    output = []
    with torch.inference_mode():
        tensor = torch.as_tensor(samples, dtype=torch.float32)
        for start in range(0, tensor.shape[0], batch_size):
            batch = tensor[start:start + batch_size].to(device, non_blocking=True)
            features, _ = fe(batch, mode="notrain")
            token, _ = te(features, epoch=50, attn_mask=None)
            output.append(token.reshape(token.shape[0], -1).cpu())
    fe.train(fe_was_training)
    te.train(te_was_training)
    return torch.cat(output, dim=0).numpy().astype(np.float32)


def _plot_training_analysis(
    run_dir,
    attribute_names,
    attention_by_epoch,
    similarity_by_epoch,
    centers,
    positive_similarity_by_epoch=None,
    negative_similarity_by_epoch=None,
):
    if not attention_by_epoch:
        return
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("warning: 未安装matplotlib，跳过训练分析图")
        return

    analysis_dir = Path(run_dir) / "analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    epochs = np.arange(1, len(attention_by_epoch) + 1)
    attention_array = np.stack(attention_by_epoch, axis=0)
    np.save(analysis_dir / "attribute_attention_by_epoch.npy", attention_array)
    for epoch, values in enumerate(similarity_by_epoch, start=1):
        np.save(analysis_dir / f"similarity_distribution_epoch_{epoch:03d}.npy", values)
    positive_similarity_by_epoch = positive_similarity_by_epoch or []
    negative_similarity_by_epoch = negative_similarity_by_epoch or []
    for epoch, values in enumerate(positive_similarity_by_epoch, start=1):
        np.save(analysis_dir / f"positive_similarity_epoch_{epoch:03d}.npy", values)
    for epoch, values in enumerate(negative_similarity_by_epoch, start=1):
        np.save(analysis_dir / f"negative_similarity_epoch_{epoch:03d}.npy", values)
    center_array = None
    if centers:
        center_array = np.stack(centers, axis=0)
        np.save(analysis_dir / "cluster_centers_by_epoch.npy", center_array)

    figure, axis = plt.subplots(figsize=(10, 5), constrained_layout=True)
    for attribute, name in enumerate(attribute_names):
        # A one-epoch smoke test has only one x value, so a plain line has
        # no visible segment. Markers keep the diagnostic figure meaningful.
        axis.plot(
            epochs,
            attention_array[:, attribute],
            marker="o" if len(epochs) == 1 else None,
            markersize=5 if len(epochs) == 1 else None,
            linewidth=1.8,
            label=name,
        )
    finite_attention = attention_array[np.isfinite(attention_array)]
    if finite_attention.size:
        low = float(np.min(finite_attention))
        high = float(np.max(finite_attention))
        if high <= low:
            margin = max(abs(low) * 0.05, 0.01)
        else:
            margin = max((high - low) * 0.08, 0.005)
        axis.set_ylim(low - margin, high + margin)
    axis.set_xlabel("epoch")
    axis.set_ylabel("attribute-summed CLS attention")
    axis.set_title("Attribute attention during pretraining")
    axis.legend(fontsize=7, ncol=2)
    figure.savefig(analysis_dir / "attribute_attention_by_epoch.png", dpi=220)
    plt.close(figure)

    selected_similarity_epochs = _selected_plot_epochs(len(similarity_by_epoch))
    selected_values = [similarity_by_epoch[epoch - 1] for epoch in selected_similarity_epochs]
    finite_similarity = np.concatenate(
        [np.asarray(values, dtype=np.float32).reshape(-1) for values in selected_values if np.asarray(values).size],
        axis=0,
    ) if any(np.asarray(values).size for values in selected_values) else np.empty(0, dtype=np.float32)
    similarity_xlim = (-1.0, 1.0) if finite_similarity.size and float(np.nanmin(finite_similarity)) < 0.0 else (0.0, 1.0)
    x_grid = np.linspace(similarity_xlim[0], similarity_xlim[1], 500)
    figure, axis = plt.subplots(figsize=(8, 5), constrained_layout=True)
    colors = plt.get_cmap("PuBu_r")(np.linspace(0.16, 0.86, max(len(selected_similarity_epochs), 1)))
    density_methods = []
    for color, epoch, values in zip(colors, selected_similarity_epochs, selected_values):
        density, method = _density_curve(values, x_grid)
        density_methods.append(method)
        axis.plot(x_grid, density, color=color, linewidth=1.5, label=f"Epoch={epoch}")
        axis.fill_between(x_grid, density, color=color, alpha=0.28)
    axis.set_xlim(*similarity_xlim)
    axis.set_xlabel("Similarity")
    axis.set_ylabel("Density")
    axis.set_title("Similarity distribution during pretraining")
    if selected_similarity_epochs:
        axis.legend(fontsize=8, frameon=True)
    figure.savefig(analysis_dir / "similarity_density_by_epoch.png", dpi=220)
    plt.close(figure)

    similarity_pair_count = min(
        len(positive_similarity_by_epoch), len(negative_similarity_by_epoch)
    )
    if similarity_pair_count:
        selected_pair_epochs = _selected_plot_epochs(similarity_pair_count)
        x_grid_pair = np.linspace(-1.0, 1.0, 500)
        figure, axis = plt.subplots(figsize=(9, 5), constrained_layout=True)
        colors = plt.get_cmap("PuBu_r")(
            np.linspace(0.16, 0.86, max(len(selected_pair_epochs), 1))
        )
        for color, epoch in zip(colors, selected_pair_epochs):
            positive_density, _ = _density_curve(
                positive_similarity_by_epoch[epoch - 1], x_grid_pair
            )
            negative_density, _ = _density_curve(
                negative_similarity_by_epoch[epoch - 1], x_grid_pair
            )
            axis.plot(
                x_grid_pair, positive_density, color=color, linewidth=1.8,
                label=f"Epoch={epoch} positive",
            )
            axis.plot(
                x_grid_pair, negative_density, color=color, linewidth=1.4,
                linestyle="--", label=f"Epoch={epoch} negative",
            )
        axis.set_xlim(-1.0, 1.0)
        axis.set_xlabel("Cosine similarity")
        axis.set_ylabel("Density")
        axis.set_title("Positive and negative view similarity")
        axis.legend(fontsize=7, ncol=2)
        figure.savefig(analysis_dir / "positive_negative_similarity_by_epoch.png", dpi=220)
        plt.close(figure)

    cluster_reducer = None
    if center_array is not None:
        center_files = sorted(analysis_dir.glob("cluster_centers_epoch_*.npy"))
        center_epochs = [int(p.stem.rsplit("_", 1)[1]) for p in center_files]
        if len(center_epochs) != len(center_array):
            center_epochs = list(range(1, len(center_array)+1))
        np.save(analysis_dir / "cluster_center_epochs.npy", center_epochs)
        coordinates, cluster_reducer = _reduce_centers_2d(center_array)
        np.save(analysis_dir / "cluster_centers_2d_by_epoch.npy", coordinates.astype(np.float32))
        figure, axis = plt.subplots(figsize=(7, 6), constrained_layout=True)
        from plot_styles import paper_cluster_colors

        cluster_colors = paper_cluster_colors(coordinates.shape[1])
        light_color = np.asarray([0.92, 0.92, 0.92, 1.0], dtype=np.float64)
        for cluster in range(coordinates.shape[1]):
            path = coordinates[:, cluster, :]
            base_color = np.asarray(plt.matplotlib.colors.to_rgba(cluster_colors[cluster]), dtype=np.float64)
            fractions = np.linspace(0.08, 1.0, coordinates.shape[0])
            point_colors = [light_color * (1.0 - fraction) + base_color * fraction for fraction in fractions]
            for index in range(max(path.shape[0] - 1, 0)):
                axis.plot(
                    path[index:index + 2, 0],
                    path[index:index + 2, 1],
                    color=point_colors[index + 1],
                    linewidth=1.1,
                    alpha=0.85,
                )
            axis.scatter(path[:, 0], path[:, 1], color=point_colors, s=20, alpha=0.95, edgecolors="none")
        axis.set_facecolor("white")
        axis.set_xlabel(f"{cluster_reducer} 1")
        axis.set_ylabel(f"{cluster_reducer} 2")
        axis.set_title("Cluster-center evolution")
        axis.text(
            0.02,
            0.98,
            "early epoch: light\nlate epoch: saturated",
            transform=axis.transAxes,
            va="top",
            ha="left",
            fontsize=8,
            color="0.25",
            bbox={"facecolor": "white", "edgecolor": "0.8", "alpha": 0.85},
        )
        legend_axis = axis.inset_axes([0.56, 0.03, 0.41, 0.22])
        legend_axis.set_facecolor("white")
        for cluster in range(coordinates.shape[1]):
            base_color = np.asarray(plt.matplotlib.colors.to_rgba(cluster_colors[cluster]), dtype=np.float64)
            gradient = np.stack(
                [light_color * (1.0 - fraction) + base_color * fraction for fraction in np.linspace(0.08, 1.0, 80)],
                axis=0,
            )[None, :, :]
            legend_axis.imshow(gradient, aspect="auto", extent=[0, 1, cluster, cluster + 0.7])
        legend_axis.set_xlim(0, 1)
        legend_axis.set_ylim(coordinates.shape[1], -0.4)
        legend_axis.set_yticks(np.arange(coordinates.shape[1]) + 0.35)
        legend_axis.set_yticklabels([f"Class {index + 1}" for index in range(coordinates.shape[1])], fontsize=7)
        legend_axis.set_xticks([0, 1])
        legend_axis.set_xticklabels([f"Epoch={center_epochs[0]}", f"Epoch={center_epochs[-1]}"], fontsize=7)
        for spine in legend_axis.spines.values():
            spine.set_edgecolor("0.75")
        figure.savefig(analysis_dir / "cluster_centers_evolution.png", dpi=220)
        plt.close(figure)

    with (analysis_dir / "analysis_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "attribute_names": [str(name) for name in attribute_names],
                "attention_definition": "actual pre-dropout softmax attention used by FullAttention, averaged over Transformer layers and heads, then summed over the eight tokens belonging to each attribute; CLS query",
                "similarity_definition": "within-batch cosine similarity of ct1, excluding the diagonal",
                "positive_similarity_definition": "cosine similarity between z from the two independently noised and masked views of the same sample",
                "negative_similarity_definition": "cosine similarity between z from different samples in the same batch; diagonal pairs are excluded",
                "diagnostics_sampling": "first training batch of each epoch; diagnostics do not affect gradients",
                "similarity_plot_epochs": selected_similarity_epochs,
                "positive_negative_plot_epochs": _selected_plot_epochs(similarity_pair_count),
                "similarity_density_method": sorted(set(density_methods)),
                "similarity_xlim": list(similarity_xlim),
                "cluster_feature": "64-dimensional h",
                "cluster_center_note": "K-Means labels are anonymous and may permute between epochs",
                "cluster_reducer": cluster_reducer,
                "cluster_plot_note": "Each path tracks one matched cluster center through epochs; each class keeps a fixed color and becomes more saturated from the first to the last epoch",
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )


def _check(bundle, device, batch_size):
    torch = _torch()
    samples = bundle["samples"]
    if samples.shape[0] < batch_size:
        raise ValueError("样本数小于check batch_size")
    batch = torch.as_tensor(samples[:batch_size], dtype=torch.float32, device=device)
    encoder = build_encoder(samples.shape)
    fe, te = encoder[0].to(device).eval(), encoder[1].to(device).eval()
    from model import proj_head

    projection = proj_head(64, 32, 16).to(device).eval()
    with torch.no_grad():
        cnn, _ = fe(batch, mode="notrain")
        h, attention = te(cnn, epoch=1, attn_mask=None)
        z = projection(h)
        representations = torch.cat([z, z], dim=0)
        similarity = torch.nn.functional.cosine_similarity(
            representations[:, None, :], representations[None, :, :], dim=-1
        )
        attr_mask = torch.zeros((batch_size, int(samples.shape[1])), dtype=torch.bool, device=device)
        attr_mask[:, 0] = True
        token_mask = attr_mask.repeat_interleave(8, dim=1)
        token_mask = torch.cat([torch.zeros((batch_size, 1), dtype=torch.bool, device=device), token_mask], dim=1)
        token_count = int(cnn.shape[1]) + 1
        mask = token_mask.unsqueeze(1).repeat(1, token_count, 1).unsqueeze(1)
        h_masked, masked_attention = te(cnn, epoch=1, attn_mask=mask)
    checks = {
        "input": torch.isfinite(batch).all(),
        "cnn": torch.isfinite(cnn).all(),
        "h": torch.isfinite(h).all(),
        "z": torch.isfinite(z).all(),
        "similarity": torch.isfinite(similarity).all(),
        "masked h": torch.isfinite(h_masked).all(),
    }
    if not all(bool(value) for value in checks.values()):
        failed = [name for name, value in checks.items() if not bool(value)]
        raise RuntimeError(f"forward检查失败：{failed}")
    if tuple(cnn.shape[1:]) != (int(samples.shape[1]) * 8, int(samples.shape[2]), int(samples.shape[3])):
        raise RuntimeError(f"CNN输出shape不符合属性token约定：{tuple(cnn.shape)}")
    if tuple(h.shape) != (batch_size, 64) or tuple(z.shape) != (batch_size, 16):
        raise RuntimeError("h/z输出维度不符合MAMCL约定")
    if tuple(similarity.shape) != (2 * batch_size, 2 * batch_size):
        raise RuntimeError("相似度矩阵维度错误")
    print(f"input: shape={tuple(batch.shape)}, finite={bool(checks['input'])}")
    print(f"cnn: shape={tuple(cnn.shape)}, finite={bool(checks['cnn'])}")
    print(f"h: shape={tuple(h.shape)}, finite={bool(checks['h'])}")
    print(f"z: shape={tuple(z.shape)}, finite={bool(checks['z'])}")
    print(f"similarity: shape={tuple(similarity.shape)}, finite={bool(checks['similarity'])}")
    print(f"attention mask: shape={tuple(mask.shape)}, finite={bool(torch.isfinite(mask.float()).all())}")
    print(f"masked h: shape={tuple(h_masked.shape)}, finite={bool(checks['masked h'])}")
    print(f"attention layers: {len(attention)}")
    print(f"masked attention layers: {len(masked_attention)}")
    print(f"device: {device}")
    print("PASS: generic MAMCL forward check")


def _train(bundle, args, device):
    torch = _torch()
    samples = bundle["samples"]
    positions = bundle["positions"]
    train_samples = samples
    train_positions = positions
    train_safe_only = bool(getattr(args, "train_safe_only", False))
    masks = bundle.get("masks", {})
    train_mask = masks.get("train_mask")
    if train_safe_only and train_mask is not None:
        train_mask = np.asarray(train_mask, dtype=bool)
        if train_mask.shape != (samples.shape[0],) or not train_mask.any():
            raise ValueError("train_mask无效或没有安全训练样本")
        train_samples = samples[train_mask]
        train_positions = positions[train_mask]
    elif train_safe_only:
        print("warning: bundle没有train_mask，训练将使用全部样本")
    well_labels = well_weights = well_mask = None
    well_report = {"status": "disabled"}
    if bool(getattr(__import__("config"), "WELL_SUPERVISION_ENABLED", False)):
        from well_supervision import build_well_supervision
        coordinate_info = _plot_coordinate_info(
            bundle, getattr(args, "coordinate_path", None),
            mode=getattr(args, "coordinate_mode", "world"), allow_fallback=False,
        )
        import config as _config
        well_bundle = dict(bundle)
        well_bundle["positions"] = train_positions
        well_positions = _grid_positions(well_bundle)
        well_labels, well_weights, well_mask, well_report = build_well_supervision(
            well_positions, coordinate_info,
            getattr(_config, "WELL_CSV_PATH", None), getattr(_config, "WELL_XLSX_PATH", None),
            encoding=getattr(_config, "WELL_CSV_ENCODING", "gbk"),
            group=getattr(_config, "WELL_GROUP", ""), segments=getattr(_config, "WELL_SEGMENTS", ()),
            mode=getattr(_config, "WELL_DECAY_MODE", "neighbor_merge"),
            sigma_factor=getattr(_config, "WELL_SIGMA_FACTOR", 0.5),
            min_weight=getattr(_config, "WELL_MIN_WEIGHT", 0.05),
            max_neighbors=getattr(_config, "WELL_MAX_NEIGHBORS", 3),
            min_confidence=getattr(_config, "WELL_MIN_CONFIDENCE", 0.60),
            fallback_weight=getattr(_config, "WELL_FALLBACK_WEIGHT", 0.35),
        )
        (Path(args.output_dir) / "analysis").mkdir(parents=True, exist_ok=True)
        _write_json(Path(args.output_dir) / "analysis" / "well_supervision_qc.json", well_report)
        print("well supervision:", json.dumps(well_report, ensure_ascii=False, sort_keys=True))
    loader = make_dataloader(
        train_samples,
        train_positions,
        batch_size=args.batch_size,
        noise_std=args.noise_std,
        shuffle=True,
        drop_last=True,
        num_workers=args.num_workers,
        well_labels=well_labels, well_weights=well_weights, well_mask=well_mask,
    )
    run_dir = Path(args.output_dir)
    (run_dir / "png").mkdir(parents=True, exist_ok=True)
    analysis_dir = run_dir / "analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    training_log = run_dir / "training.log"
    start_line = (
        f"start epochs={args.epochs} batch_size={args.batch_size} "
        f"noise_std={args.noise_std} lr={args.lr} seed={getattr(args, 'seed', 42)} "
        f"train_samples={len(train_samples)} total_samples={len(samples)} safe_only={train_safe_only}"
    )
    if getattr(args, "resume", None):
        if not training_log.exists():
            _append_training_log(training_log, start_line)
    else:
        training_log.write_text(start_line + "\n", encoding="utf-8")
    if not getattr(args, "resume", None):
        for pattern in (
            "attribute_attention_epoch_*.npy",
            "attribute_attention_sum_epoch_*.npy",
            "similarity_distribution_epoch_*.npy",
            "positive_similarity_epoch_*.npy",
            "negative_similarity_epoch_*.npy",
            "runtime_diagnostics_epoch_*.json",
            "runtime_diagnostics.json",
            "runtime_config.json",
            "gaussian_window.json",
            "cluster_centers_epoch_*.npy",
        ):
            for stale_path in analysis_dir.glob(pattern):
                stale_path.unlink()
    algorithm = build_algorithm(
        samples.shape,
        _spatial_shape(bundle),
        args.batch_size,
        device,
        lr=args.lr,
    )
    bridge = __import__("mamcl_bridge")
    gaussian_window = bridge.gaussian_window_values(
        (algorithm.encoder, algorithm.token_transformer)
    )
    algorithm.input_contract = {
        "attribute_names": bundle["attribute_names"],
        "sample_shape": list(samples.shape[1:]),
        "normalization": bundle.get("metadata", {}).get("normalization"),
        "gaussian_sigma": bridge._configured_gaussian_sigma(),
        "gaussian_peak_mode": bridge._configured_gaussian_peak_mode(),
        "gaussian_window": gaussian_window.tolist() if gaussian_window is not None else None,
        "dcl_topk": int(getattr(getattr(algorithm, "dcl", None), "topk", 0)),
        "dcl_position_weighting_applied": bool(
            getattr(getattr(algorithm, "dcl", None), "position_weighting_applied", False)
        ),
        "spatial_consistency": {
            "enabled": bool(getattr(algorithm, "spatial_consistency_enabled", False)),
            "weight": float(getattr(algorithm, "spatial_consistency_weight", 0.0)),
            "neighbors": int(getattr(getattr(algorithm, "spatial_consistency", None), "neighbors", 0)),
            "distance_scale": float(getattr(getattr(algorithm, "spatial_consistency", None), "distance_scale", 0.0)),
        },
        "well_supervision": {
            "enabled": bool(getattr(algorithm, "well_supervision_enabled", False)),
            "weight": float(getattr(algorithm, "well_loss_weight", 0.0)),
            "qc": well_report,
        },
    }
    runtime_config = {
        "optimizer_scheduler": bridge.optimizer_scheduler_info(algorithm),
        "gaussian": {
            "sigma": bridge._configured_gaussian_sigma(),
            "peak_mode": bridge._configured_gaussian_peak_mode(),
            "weights": gaussian_window.tolist() if gaussian_window is not None else None,
            "sum": float(gaussian_window.sum()) if gaussian_window is not None else None,
        },
        "contrastive_loss": {
            "class": type(getattr(algorithm, "dcl", None)).__name__ if getattr(algorithm, "dcl", None) is not None else None,
            "topk": int(getattr(getattr(algorithm, "dcl", None), "topk", 0)),
            "position_weighting_applied": bool(
                getattr(getattr(algorithm, "dcl", None), "position_weighting_applied", False)
            ),
        },
        "diagnostics_sampling": "first training batch of each epoch; diagnostics do not affect gradients",
        "normalization": bundle.get("metadata", {}).get("normalization"),
        "train_safe_only": train_safe_only,
        "train_sample_count": int(len(train_samples)),
        "total_sample_count": int(len(samples)),
    }
    _write_json(analysis_dir / "runtime_config.json", runtime_config)
    _write_json(analysis_dir / "gaussian_window.json", runtime_config["gaussian"])
    _append_training_log(
        training_log,
        "runtime_config=" + json.dumps(runtime_config, ensure_ascii=False, sort_keys=True),
    )
    start_epoch = 0
    resume_path = getattr(args, "resume", None)
    if resume_path:
        resume_path = Path(resume_path)
        if not resume_path.exists():
            raise FileNotFoundError(f"续训checkpoint不存在：{resume_path}")
        payload, start_epoch = load_algorithm_checkpoint(resume_path, algorithm, device)
        print(f"resume: {resume_path.resolve()} epoch={start_epoch}")
    losses = []
    attention_by_epoch = []
    similarity_by_epoch = []
    positive_similarity_by_epoch = []
    negative_similarity_by_epoch = []
    runtime_diagnostics_by_epoch = []
    cluster_centers = []
    analysis_clusters = int(getattr(args, "analysis_clusters", 4))
    analysis_feature_batch = int(getattr(args, "analysis_feature_batch", args.batch_size))
    analysis_max_samples = int(getattr(args, "analysis_max_samples", 0))
    analysis_max_similarity = int(getattr(args, "analysis_max_similarity", 20000))
    analysis_every = max(int(getattr(args, "analysis_every", 1)), 1)
    checkpoint_interval = max(int(getattr(args, "checkpoint_interval", 1)), 1)
    for epoch in range(start_epoch + 1, args.epochs + 1):
        epoch_started = time.perf_counter()
        actual_lr = float(algorithm.optimizer.param_groups[0]["lr"])
        epoch_losses = []
        epoch_well_losses = []
        for step, batch in enumerate(loader):
            result, _ = algorithm.update([_move_batch(batch, device)], step, epoch, str(run_dir))
            value = float(result["Total_loss"])
            epoch_losses.append(value)
            if "well_loss" in result:
                epoch_well_losses.append(float(result["well_loss"]))
            losses.append(value)
        algorithm.update_lr(epoch)
        import matplotlib.pyplot as plt
        plt.close('all')
        epoch_line = f"epoch={epoch} steps={len(epoch_losses)} loss={np.mean(epoch_losses):.6f}"
        if epoch_well_losses:
            epoch_line += f" well_loss={np.mean(epoch_well_losses):.6f}"
        print(epoch_line)
        next_lr = float(algorithm.optimizer.param_groups[0]["lr"])
        _append_training_log(
            training_log,
            epoch_line
            + f" lr={actual_lr:.8g} next_lr={next_lr:.8g}"
            + f" training_seconds={time.perf_counter()-epoch_started:.3f}",
        )
        epoch_attention_sum = _attribute_attention_from_algorithm(algorithm, 1)
        epoch_similarity = _limit_values(
            _similarity_from_algorithm(algorithm), analysis_max_similarity, args.seed,
        )
        if epoch_attention_sum is not None:
            epoch_attention = epoch_attention_sum
            attention_by_epoch.append(epoch_attention)
            np.save(analysis_dir / f"attribute_attention_epoch_{epoch:03d}.npy", epoch_attention)
            np.save(analysis_dir / f"attribute_attention_sum_epoch_{epoch:03d}.npy", epoch_attention_sum)
        else:
            attention_by_epoch.append(np.zeros(samples.shape[1], dtype=np.float32))
        similarity_by_epoch.append(epoch_similarity)
        np.save(analysis_dir / f"similarity_distribution_epoch_{epoch:03d}.npy", epoch_similarity)
        epoch_diagnostics = _algorithm_diagnostics(algorithm)
        positive_similarity = _algorithm_similarity_values(
            algorithm, "positive_similarity",
        )
        negative_similarity = _algorithm_similarity_values(
            algorithm, "negative_similarity",
        )
        positive_similarity_by_epoch.append(positive_similarity)
        negative_similarity_by_epoch.append(negative_similarity)
        np.save(analysis_dir / f"positive_similarity_epoch_{epoch:03d}.npy", positive_similarity)
        np.save(analysis_dir / f"negative_similarity_epoch_{epoch:03d}.npy", negative_similarity)
        runtime_diagnostics_by_epoch.append(
            {
                "epoch": int(epoch),
                "loss": float(np.mean(epoch_losses)),
                "learning_rate": actual_lr,
                "next_learning_rate": next_lr,
                **epoch_diagnostics,
            }
        )
        _write_json(
            analysis_dir / f"runtime_diagnostics_epoch_{epoch:03d}.json",
            runtime_diagnostics_by_epoch[-1],
        )
        np.save(run_dir / "losses.npy", np.asarray(losses, dtype=np.float32))
        try:
            from kmeans_pytorch import kmeans as kmeans_torch
            if epoch % analysis_every != 0:
                algorithm.reset_attn()
                if epoch % checkpoint_interval == 0:
                    save_checkpoint(
                        run_dir / "checkpoint.pt", algorithm,
                        {"samples_shape": list(samples.shape), "epoch": epoch},
                        epoch=epoch,
                    )
                continue
            analysis_samples = train_samples
            if analysis_max_samples > 0:
                requested = analysis_max_samples
                actual = min(requested, len(train_samples))
                if actual < requested:
                    print(
                        f"analysis sample cap reduced: requested={requested} "
                        f"available={len(train_samples)}"
                    )
                indices = np.random.default_rng(args.seed).choice(
                    len(train_samples), actual, replace=False,
                )
                analysis_samples = train_samples[indices]
            epoch_features = _extract_h_preserving_mode(
                algorithm,
                analysis_samples,
                device,
                analysis_feature_batch,
            )
            if analysis_clusters <= 1 or analysis_clusters > epoch_features.shape[0]:
                raise ValueError("analysis_clusters必须大于1且不超过分析样本数")
            torch = _torch()
            analysis_tensor = torch.as_tensor(
                epoch_features, dtype=torch.float32, device=device
            )
            _, centers = kmeans_torch(
                X=analysis_tensor,
                num_clusters=analysis_clusters,
                distance="euclidean",
                device=device,
            )
            centers = centers.detach().cpu().numpy().astype(np.float32)
            previous = cluster_centers[-1] if cluster_centers else None
            centers = _match_centers(previous, centers)
            cluster_centers.append(centers)
            np.save(analysis_dir / f"cluster_centers_epoch_{epoch:03d}.npy", centers)
        except ImportError:
            print("warning: 未安装kmeans-pytorch，跳过每epoch聚类中心")
        algorithm.reset_attn()
        if epoch % checkpoint_interval == 0:
            save_checkpoint(
                run_dir / "checkpoint.pt",
                algorithm,
                {"samples_shape": list(samples.shape), "epoch": epoch},
                epoch=epoch,
            )
    _plot_training_analysis(
        run_dir,
        bundle["attribute_names"],
        attention_by_epoch,
        similarity_by_epoch,
        cluster_centers,
        positive_similarity_by_epoch,
        negative_similarity_by_epoch,
    )
    _write_json(
        analysis_dir / "runtime_diagnostics.json",
        {
            "version": "mamcl-runtime-diagnostics-v1",
            "runtime_config": runtime_config,
            "epochs": runtime_diagnostics_by_epoch,
        },
    )
    checkpoint = save_checkpoint(
        run_dir / "checkpoint.pt",
        algorithm,
        {
            "samples_shape": list(samples.shape),
            "spatial_shape": list(_spatial_shape(bundle)),
            "batch_size": args.batch_size,
            "epochs": args.epochs,
            "noise_std": args.noise_std,
            "analysis_clusters": analysis_clusters,
            "seed": int(getattr(args, "seed", 42)),
            "lr": float(args.lr),
            "dcl_topk": int(getattr(getattr(algorithm, "dcl", None), "topk", 0)),
            "dcl_position_weighting_applied": bool(
                getattr(getattr(algorithm, "dcl", None), "position_weighting_applied", False)
            ),
            "optimizer_scheduler": bridge.optimizer_scheduler_info(algorithm),
        },
        epoch=args.epochs,
    )
    np.save(run_dir / "losses.npy", np.asarray(losses, dtype=np.float32))
    _append_training_log(training_log, f"finished epoch={args.epochs}")
    print("checkpoint:", checkpoint.resolve())
    print("analysis:", analysis_dir.resolve())


def _features(bundle, args, device):
    samples = bundle["samples"]
    if args.checkpoint:
        encoder, payload = load_encoder_checkpoint(args.checkpoint, samples.shape, device)
        contract = payload.get("input_contract")
        if contract:
            bridge = __import__("mamcl_bridge")
            current = {
                "attribute_names": bundle["attribute_names"],
                "sample_shape": list(samples.shape[1:]),
                "normalization": bundle.get("metadata", {}).get("normalization"),
                "gaussian_sigma": bridge._configured_gaussian_sigma(),
                "gaussian_peak_mode": bridge._configured_gaussian_peak_mode(),
            }
            if any(contract.get(key) != value for key, value in current.items()):
                raise ValueError("预测输入与模型不一致：请核对属性顺序、窗口和训练归一化参数")
        else:
            print("warning: legacy checkpoint has no input contract; input compatibility cannot be verified")
    else:
        encoder = build_encoder(samples.shape)
        print("warning: 未提供checkpoint，当前h是随机初始化模型的特征")
    features = extract_h(encoder, samples, device, batch_size=args.feature_batch)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    np.save(output_dir / "features_h.npy", features.astype(np.float32))
    np.save(output_dir / "positions.npy", bundle["positions"])
    print(f"h: shape={features.shape}, finite={bool(np.isfinite(features).all())}")
    print("features:", (output_dir / "features_h.npy").resolve())
    return features


def _spatial_cluster_metrics(grid):
    grid = np.asarray(grid, dtype=np.int32)
    valid = grid >= 0
    valid_count = int(valid.sum())
    metrics = {
        "valid_cell_count": valid_count,
        "horizontal_pair_count": 0,
        "vertical_pair_count": 0,
        "same_horizontal_pair_count": 0,
        "same_vertical_pair_count": 0,
        "spatial_continuity": None,
        "spatial_transition_rate": None,
        "isolated_fraction": None,
    }
    if grid.ndim != 2 or valid_count == 0:
        return metrics
    horizontal_valid = valid[:, 1:] & valid[:, :-1]
    vertical_valid = valid[1:, :] & valid[:-1, :]
    horizontal_pairs = int(horizontal_valid.sum())
    vertical_pairs = int(vertical_valid.sum())
    same_horizontal = int((horizontal_valid & (grid[:, 1:] == grid[:, :-1])).sum())
    same_vertical = int((vertical_valid & (grid[1:, :] == grid[:-1, :])).sum())
    pair_count = horizontal_pairs + vertical_pairs
    same_pair_count = same_horizontal + same_vertical
    metrics.update(
        {
            "horizontal_pair_count": horizontal_pairs,
            "vertical_pair_count": vertical_pairs,
            "same_horizontal_pair_count": same_horizontal,
            "same_vertical_pair_count": same_vertical,
            "spatial_continuity": float(same_pair_count / pair_count) if pair_count else None,
            "spatial_transition_rate": float(1.0 - same_pair_count / pair_count) if pair_count else None,
        }
    )
    padded = np.pad(grid, 1, mode="constant", constant_values=-1)
    center = padded[1:-1, 1:-1]
    valid_neighbor_count = np.zeros_like(grid, dtype=np.int16)
    same_neighbor_count = np.zeros_like(grid, dtype=np.int16)
    for neighbor in (
        padded[:-2, 1:-1],
        padded[2:, 1:-1],
        padded[1:-1, :-2],
        padded[1:-1, 2:],
    ):
        pair_valid = (center >= 0) & (neighbor >= 0)
        valid_neighbor_count += pair_valid.astype(np.int16)
        same_neighbor_count += (pair_valid & (neighbor == center)).astype(np.int16)
    considered = valid & (valid_neighbor_count > 0)
    if considered.any():
        metrics["isolated_fraction"] = float(
            ((same_neighbor_count == 0) & considered).sum() / considered.sum()
        )
    return metrics


def _cluster(bundle, args, device):
    samples = bundle["samples"]
    if args.checkpoint:
        encoder, payload = load_encoder_checkpoint(args.checkpoint, samples.shape, device)
        contract = payload.get("input_contract")
        if contract:
            bridge = __import__("mamcl_bridge")
            current = {
                "attribute_names": bundle["attribute_names"],
                "sample_shape": list(samples.shape[1:]),
                "normalization": bundle.get("metadata", {}).get("normalization"),
                "gaussian_sigma": bridge._configured_gaussian_sigma(),
                "gaussian_peak_mode": bridge._configured_gaussian_peak_mode(),
            }
            if any(contract.get(key) != value for key, value in current.items()):
                raise ValueError("预测输入与模型不一致：请核对属性顺序、窗口和训练归一化参数")
        else:
            print("warning: legacy checkpoint has no input contract; input compatibility cannot be verified")
    else:
        encoder = build_encoder(samples.shape)
        print("warning: 未提供checkpoint，当前h和attention是随机初始化模型的结果")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    code_root = Path(__file__).parent.parent / "seismicfacies" / "src"
    implementation_path = Path(__file__)
    if code_root.is_dir():
        model_code = {
            str(p.relative_to(Path(__file__).parent.parent)): fingerprint(p)
            for p in code_root.rglob("*.py")
            if p.is_file()
        }
    else:
        # In a PyInstaller build implementation modules live in the archive
        # and have no corresponding filesystem file. Keep a stable marker so
        # feature-cache validation still works without crashing.
        model_code = {"frozen_bundle": "pyinstaller"}
    signature = {
        "checkpoint": fingerprint(args.checkpoint) if args.checkpoint else None,
        "bundle": fingerprint(bundle["path"]),
        "sigma": __import__("mamcl_bridge")._configured_gaussian_sigma(),
        "model_code": model_code,
        "implementation": fingerprint(implementation_path) if implementation_path.is_file() else "pyinstaller_bundle",
    }
    manifest = output_dir / "feature_cache.json"
    cache_paths = [output_dir / name for name in ("features_h.npy", "attribute_attention.npy", "positions.npy")]
    reuse = False
    if getattr(args, "reuse_features", False) and args.checkpoint and manifest.exists() and all(p.exists() for p in cache_paths):
        try:
            reuse = json.loads(manifest.read_text(encoding="utf-8")) == signature
        except (ValueError, OSError):
            pass
    if reuse:
        features = np.load(cache_paths[0], mmap_mode="r")
        attribute_attention = np.load(cache_paths[1], mmap_mode="r")
        print("reusing verified feature cache")
    else:
        features, attribute_attention = extract_h_and_attribute_attention(encoder, samples, device, batch_size=args.feature_batch)
        np.save(cache_paths[0], features)
        np.save(cache_paths[1], attribute_attention)
        np.save(cache_paths[2], bundle["positions"])
        manifest.write_text(json.dumps(signature), encoding="utf-8")
    print(f"h: shape={features.shape}, finite={bool(np.isfinite(features).all())}")
    print(f"attribute attention: shape={attribute_attention.shape}, finite={bool(np.isfinite(attribute_attention).all())}")
    print("attribute attention file:", (output_dir / "attribute_attention.npy").resolve())
    try:
        from kmeans_pytorch import kmeans as kmeans_torch
    except ImportError as exc:
        raise ImportError("cluster模式需要kmeans-pytorch") from exc
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap
    from plot_styles import cluster_color_metadata, paper_cluster_colors, save_paper_cluster_map
    spatial = _spatial_shape(bundle)
    grid = np.full(spatial, -1, dtype=np.int32)
    positions = _grid_positions(bundle)
    paper_base = _attribute_plot_base(bundle, spatial)
    coordinate_mode = getattr(args, "coordinate_mode", "world")
    coordinate_info = _plot_coordinate_info(
        bundle,
        getattr(args, "coordinate_path", None),
        mode=coordinate_mode,
        allow_fallback=str(coordinate_mode).lower() == "index",
    )
    if "fallback_reason" in coordinate_info:
        print("coordinate warning:", coordinate_info["fallback_reason"])
    cluster_argument = getattr(args, "clusters", 4)
    if isinstance(cluster_argument, (int, np.integer)):
        cluster_values = [int(cluster_argument)]
    else:
        cluster_values = sorted(set(int(value) for value in cluster_argument))
    if not cluster_values:
        raise ValueError("clusters不能为空")

    torch = _torch()
    import config as runtime_config
    postprocess_mode = str(getattr(runtime_config, "POSTPROCESS_MODE", "majority_vote")).lower()
    if postprocess_mode not in {"none", "majority_vote", "probability_smoothing"}:
        raise ValueError("POSTPROCESS_MODE必须是none、majority_vote或probability_smoothing")
    # Keep the full feature matrix on CPU. Only the fit subset and one distance
    # batch are moved to the accelerator, which avoids a second full GPU copy.
    feature_tensor = torch.as_tensor(features, dtype=torch.float32, device="cpu")
    kmeans_safe_only = bool(getattr(args, "kmeans_safe_only", False))
    masks = bundle.get("masks", {})
    fit_mask = masks.get("train_mask") if kmeans_safe_only else None
    if fit_mask is None:
        if kmeans_safe_only:
            print("warning: bundle没有train_mask，K-Means将使用全部特征")
        fit_mask = np.ones(features.shape[0], dtype=bool)
    fit_mask = np.asarray(fit_mask, dtype=bool)
    if fit_mask.shape != (features.shape[0],) or not fit_mask.any():
        raise ValueError("K-Means fit_mask无效或没有可用特征")
    fit_count = int(fit_mask.sum())
    fit_indices = np.flatnonzero(fit_mask)
    max_fit = int(getattr(args, "kmeans_max_fit_samples", 0) or 0)
    if max_fit > 0 and fit_indices.size > max_fit:
        fit_indices = np.random.default_rng(int(getattr(args, "seed", 42))).choice(
            fit_indices, size=max_fit, replace=False
        )
        fit_indices.sort()
        print(f"K-Means fit cap: {max_fit}/{fit_count} samples")
    fit_tensor = feature_tensor[torch.as_tensor(fit_indices, dtype=torch.long)].to(device=device)
    fit_sample_count = int(fit_indices.size)
    for clusters in cluster_values:
        if clusters <= 1 or clusters > fit_sample_count:
            raise ValueError(
                f"clusters必须大于1且不超过实际K-Means拟合样本数：{clusters}, {fit_sample_count}"
            )
        _, centers = kmeans_torch(
            X=fit_tensor,
            num_clusters=clusters,
            distance="euclidean",
            device=device,
        )
        centers = centers.to(device=device, dtype=torch.float32)
        if not bool(torch.isfinite(centers).all()):
            raise RuntimeError(
                f"K={clusters} 聚类中心出现NaN/Inf，通常表示某个类别没有样本；"
                "请减少聚类数或重新设置SEED"
            )
        centers_np = centers.detach().cpu().numpy().astype(np.float32)
        batch_size = max(1, int(getattr(args, "distance_batch", 8192)))
        labels = np.empty(len(features), dtype=np.int32)
        confidence = np.empty(len(features), dtype=np.float32)
        entropy = np.empty(len(features), dtype=np.float32)
        probabilities_grid = (
            np.full((*spatial, clusters), np.nan, dtype=np.float16)
            if postprocess_mode == "probability_smoothing" else None
        )
        grid.fill(-1)
        inertia = 0.0
        save_distances = getattr(args, "save_distance_maps", False)
        distance_map = np.full((*spatial, clusters), -1.0, dtype=np.float32) if save_distances else None
        for start in range(0, len(features), batch_size):
            stop = min(start + batch_size, len(features))
            batch_features = feature_tensor[start:stop].to(device=device, non_blocking=True)
            distances = torch.cdist(batch_features, centers)
            cluster_ids = torch.argmin(distances, dim=1).to(device=device, dtype=torch.long)
            probabilities = torch.softmax(-distances / 0.20, dim=1)
            confidence[start:stop] = probabilities.max(dim=1).values.detach().cpu().numpy().astype(np.float32)
            entropy[start:stop] = (-(probabilities * torch.log(probabilities.clamp_min(1e-8))).sum(dim=1)).detach().cpu().numpy().astype(np.float32)
            labels[start:stop] = cluster_ids.detach().cpu().numpy().astype(np.int32)
            if probabilities_grid is not None:
                pos = positions[start:stop]
                probabilities_grid[pos[:, 0], pos[:, 1], :] = probabilities.detach().cpu().numpy().astype(np.float16)
            assigned = distances[torch.arange(stop-start, device=device), cluster_ids]
            inertia += float(assigned.double().square().sum().cpu())
            if distance_map is not None:
                pos = positions[start:stop]
                distance_map[pos[:, 0], pos[:, 1]] = distances.cpu().numpy()
            del batch_features, distances, cluster_ids, assigned
        grid[positions[:, 0], positions[:, 1]] = labels
        confidence_grid = np.full(spatial, np.nan, dtype=np.float32)
        entropy_grid = np.full(spatial, np.nan, dtype=np.float32)
        confidence_grid[positions[:, 0], positions[:, 1]] = confidence
        entropy_grid[positions[:, 0], positions[:, 1]] = entropy
        spatial_metrics = _spatial_cluster_metrics(grid)
        output = output_dir / f"clusters_k{clusters}.npz"
        np.savez_compressed(
            output,
            labels=labels,
            grid=grid,
            cluster_centers=centers_np,
            inertia=np.asarray(inertia),
            fit_mask=fit_mask,
            fit_count=np.asarray(fit_count, dtype=np.int64),
            fit_sample_count=np.asarray(fit_sample_count, dtype=np.int64),
            spatial_continuity=np.asarray(
                spatial_metrics["spatial_continuity"]
                if spatial_metrics["spatial_continuity"] is not None else -1.0,
                dtype=np.float32,
            ),
            spatial_transition_rate=np.asarray(
                spatial_metrics["spatial_transition_rate"]
                if spatial_metrics["spatial_transition_rate"] is not None else -1.0,
                dtype=np.float32,
            ),
            isolated_fraction=np.asarray(
                spatial_metrics["isolated_fraction"]
                if spatial_metrics["isolated_fraction"] is not None else -1.0,
                dtype=np.float32,
            ),
            horizontal_pair_count=np.asarray(
                spatial_metrics["horizontal_pair_count"], dtype=np.int64,
            ),
            vertical_pair_count=np.asarray(
                spatial_metrics["vertical_pair_count"], dtype=np.int64,
            ),
            confidence=confidence,
            entropy=entropy,
            confidence_grid=confidence_grid,
            entropy_grid=entropy_grid,
            confidence_temperature=np.asarray(0.20, dtype=np.float32),
            **({"probabilities_grid": probabilities_grid} if probabilities_grid is not None else {}),
        )
        _write_json(
            output_dir / f"clusters_k{clusters}_spatial_metrics.json",
            spatial_metrics,
        )
        grid_image = np.ma.masked_equal(grid, -1)
        cluster_cmap = ListedColormap(
            paper_cluster_colors(clusters),
            name=f"bright_clusters_{clusters}",
        )
        _write_json(output_dir / f"cluster_colors_k{clusters}.json", cluster_color_metadata(clusters))
        cluster_cmap.set_bad("white")
        cluster_norm = BoundaryNorm(np.arange(-0.5, clusters + 0.5, 1.0), clusters)
        figure, axis = plt.subplots(figsize=(10, 10), constrained_layout=True)
        image = axis.pcolormesh(
            coordinate_info["x"],
            coordinate_info["y"],
            grid_image,
            shading="auto",
            edgecolors="none",
            linewidth=0.0,
            antialiased=False,
            cmap=cluster_cmap,
            norm=cluster_norm,
        )
        figure.colorbar(image, ax=axis, label="cluster id")
        axis.set_xlabel(str(coordinate_info.get("xlabel", "X coordinate")))
        axis.set_ylabel(str(coordinate_info.get("ylabel", "Y coordinate")))
        axis.set_aspect("equal", adjustable="box")
        axis.set_title(f"Kmeans-{clusters}")
        figure.savefig(output_dir / f"Kmeans_{clusters}_labels.png", dpi=400)
        plt.close(figure)
        paper_path = output_dir / f"Kmeans_{clusters}.png"
        save_paper_cluster_map(
            grid,
            clusters,
            paper_path,
            base=paper_base,
            overlay_alpha=0.82,
            dpi=400,
            coordinates=coordinate_info,
            well_points=getattr(args, "well_points", None),
            well_style=getattr(args, "well_style", None),
        )
        grid.astype(np.float32).tofile(output_dir / f"Kmeans_{clusters}.dat")
        if distance_map is not None:
            distance_map.tofile(output_dir / f"Kmeans_{clusters}_dist_map.dat")
        for cluster_id in range(clusters):
            mask = (grid == cluster_id).astype(np.float32)
            figure, axis = plt.subplots(figsize=(10, 10), constrained_layout=True)
            mask_cmap = ListedColormap(["white", paper_cluster_colors(clusters)[cluster_id]])
            axis.pcolormesh(
                coordinate_info["x"],
                coordinate_info["y"],
                mask,
                shading="auto",
            edgecolors="none",
            linewidth=0.0,
            antialiased=False,
                cmap=mask_cmap,
                vmin=0,
                vmax=1,
            )
            axis.set_xlabel(str(coordinate_info.get("xlabel", "X coordinate")))
            axis.set_ylabel(str(coordinate_info.get("ylabel", "Y coordinate")))
            axis.set_aspect("equal", adjustable="box")
            axis.set_title(f"Kmeans-{clusters}, class {cluster_id}")
            figure.savefig(output_dir / f"kmeans_{clusters}_{cluster_id}c.png", dpi=400)
            plt.close(figure)
            selected = samples[labels == cluster_id]
            if selected.shape[0] == 0:
                continue
            mean_sample = selected.mean(axis=0, dtype=np.float32)
            attribute_count = int(mean_sample.shape[0])
            figure, axes = plt.subplots(
                1, attribute_count, figsize=(max(attribute_count, 1), 5),
                squeeze=False, constrained_layout=True,
            )
            for attribute in range(attribute_count):
                axis = axes[0, attribute]
                axis.plot(mean_sample[attribute, 0], np.arange(mean_sample.shape[-1]))
                axis.set_title(f"attr_{attribute}")
            figure.savefig(output_dir / f"kmeans_{clusters}_{cluster_id}c_attr.png", dpi=400)
            plt.close(figure)
        print(f"K={clusters}")
        print("cluster labels:", output.resolve())
        print("cluster counts:", np.bincount(labels, minlength=clusters).tolist())
        print("kmeans fit count:", fit_count, "predict count:", int(labels.size))
        print("inertia:", inertia)
        print(
            "spatial continuity:", spatial_metrics["spatial_continuity"],
            "transition rate:", spatial_metrics["spatial_transition_rate"],
            "isolated fraction:", spatial_metrics["isolated_fraction"],
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--mode", choices=["check", "train", "features", "cluster"], default="check")
    parser.add_argument("--checkpoint")
    parser.add_argument("--output-dir", default="runs/mamcl")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--feature-batch", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--noise-std", type=float, default=0.2)
    parser.add_argument("--lr", type=float, default=0.2)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--clusters", type=int, default=6)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--analysis-clusters", type=int, default=4)
    parser.add_argument("--analysis-feature-batch", type=int, default=128)
    parser.add_argument("--analysis-max-samples", type=int, default=20000)
    parser.add_argument("--analysis-max-similarity", type=int, default=20000)
    parser.add_argument("--analysis-every", type=int, default=1)
    parser.add_argument("--checkpoint-interval", type=int, default=1)
    parser.add_argument("--resume")
    parser.add_argument("--coordinate-path")
    parser.add_argument("--coordinate-mode", choices=["world", "inline_crossline", "index"], default="world")
    args = parser.parse_args()
    set_seed(args.seed)
    bundle = load_bundle(args.bundle)
    device = choose_device(args.device)
    if args.mode == "check":
        _check(bundle, device, args.batch_size)
    elif args.mode == "train":
        _train(bundle, args, device)
    elif args.mode == "features":
        _features(bundle, args, device)
    else:
        _cluster(bundle, args, device)


if __name__ == "__main__":
    main()
