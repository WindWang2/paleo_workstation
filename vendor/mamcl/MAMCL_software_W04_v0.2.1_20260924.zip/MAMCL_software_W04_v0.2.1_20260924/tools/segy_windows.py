from __future__ import annotations

from pathlib import Path

import numpy as np

from extract_window import _stride_pair
from normalize import fit_normalization, apply_normalization


def _open_segy(path, iline, xline):
    try:
        import segyio  # type: ignore
    except ImportError as exc:
        raise ImportError("读取SEG-Y需要安装segyio") from exc
    return segyio.open(
        str(path),
        iline=int(iline),
        xline=int(xline),
        strict=False,
        ignore_geometry=True,
    )


def _sample_metadata(handle):
    samples = np.asarray(handle.samples, dtype=np.float64)
    if samples.size < 2:
        raise ValueError("SEG-Y至少需要两个垂向采样点")
    differences = np.diff(samples)
    if not np.allclose(differences, differences[0], rtol=1e-5, atol=1e-6):
        raise ValueError("SEG-Y垂向采样间隔不均匀")
    return int(samples.size), float(samples[0]), float(differences[0])


def _infer_axes(path, iline, xline, shape):
    with _open_segy(path, iline, xline) as handle:
        inline_min = None
        inline_max = None
        crossline_min = None
        crossline_max = None
        for index in range(handle.tracecount):
            header = handle.header[index]
            inline = int(header[int(iline)])
            crossline = int(header[int(xline)])
            inline_min = inline if inline_min is None else min(inline_min, inline)
            inline_max = inline if inline_max is None else max(inline_max, inline)
            crossline_min = crossline if crossline_min is None else min(crossline_min, crossline)
            crossline_max = crossline if crossline_max is None else max(crossline_max, crossline)
    if shape[0] < 1 or shape[1] < 1:
        raise ValueError(f"空间shape无效：{shape}")
    inline_step = ((inline_max - inline_min) / (shape[0] - 1)) if shape[0] > 1 else 1.0
    crossline_step = ((crossline_max - crossline_min) / (shape[1] - 1)) if shape[1] > 1 else 1.0
    if inline_step <= 0 or crossline_step <= 0:
        raise ValueError("无法从SEG-Y道头推断空间坐标轴")
    if not float(inline_step).is_integer() or not float(crossline_step).is_integer():
        raise ValueError("SEG-Y线号范围与层位网格不匹配，请提供空间坐标轴参数")
    return float(inline_min), float(crossline_min), float(inline_step), float(crossline_step)


def _axis_values(axes, path, iline, xline, shape):
    if axes is None:
        return _infer_axes(path, iline, xline, shape)
    if len(axes) != 4 or any(value is None for value in axes):
        raise ValueError("segy_axes必须为(inline_origin,crossline_origin,inline_step,crossline_step)")
    values = tuple(float(value) for value in axes)
    if values[2] <= 0 or values[3] <= 0:
        raise ValueError("SEG-Y空间步长必须为正")
    return values


def _center_indices(horizon, sample_start, sample_interval, horizon_unit, scale, offset, shift):
    values = np.asarray(horizon, dtype=np.float64) * float(scale) + float(offset)
    unit = str(horizon_unit).lower()
    if unit in {"ms", "millisecond", "milliseconds"}:
        centers = (values - sample_start) / sample_interval
    elif unit in {"s", "sec", "second", "seconds"}:
        centers = (values * 1000.0 - sample_start) / sample_interval
    elif unit in {"sample", "samples", "index"}:
        centers = values
    else:
        raise ValueError("horizon_unit必须是ms、s或samples")
    return centers + float(shift)


def _sample_positions(horizon, centers, window, stride, sampling, skip_invalid, inline_slice=None, crossline_slice=None):
    if sampling not in {"integer", "linear"}:
        raise ValueError("sampling必须是integer或linear")
    inline_step, crossline_step = _stride_pair(stride)
    finite = np.isfinite(horizon) & np.isfinite(centers)
    if not skip_invalid and not finite.all():
        raise ValueError("层位包含无效值")
    n_inline, n_crossline = horizon.shape
    positions = []
    inline_start, inline_stop = inline_slice or (0, n_inline)
    crossline_start, crossline_stop = crossline_slice or (0, n_crossline)
    if not (0 <= inline_start < inline_stop <= n_inline):
        raise ValueError("inline_slice超出范围")
    if not (0 <= crossline_start < crossline_stop <= n_crossline):
        raise ValueError("crossline_slice超出范围")
    for inline in range(inline_start, inline_stop, inline_step):
        for crossline in range(crossline_start, crossline_stop, crossline_step):
            if not finite[inline, crossline]:
                continue
            center = float(centers[inline, crossline])
            if sampling == "integer" and not center.is_integer():
                raise ValueError("integer取样要求换算后的层位为整数采样点")
            if center - window < 0:
                continue
            positions.append((inline, crossline))
    if not positions:
        raise ValueError("没有可用的层位窗口")
    return np.asarray(positions, dtype=np.int64)


def _trace_window(trace, center, window, sampling):
    offsets = np.arange(-window, window + 1, dtype=np.float64)
    indices = float(center) + offsets
    if indices[0] < 0 or indices[-1] >= trace.size:
        return None
    if sampling == "integer":
        return np.asarray(trace[indices.astype(np.int64)], dtype=np.float32)
    left = np.floor(indices).astype(np.int64)
    right = np.minimum(left + 1, trace.size - 1)
    fraction = indices - left
    return np.asarray(trace[left] * (1.0 - fraction) + trace[right] * fraction, dtype=np.float32)


def read_segy_windows(
    path,
    horizon,
    positions,
    axes,
    iline,
    xline,
    window,
    centers,
    sampling,
):
    horizon_shape = tuple(int(value) for value in horizon.shape)
    inline_origin, crossline_origin, inline_step, crossline_step = axes
    index_grid = np.full(horizon_shape, -1, dtype=np.int64)
    index_grid[positions[:, 0], positions[:, 1]] = np.arange(positions.shape[0])
    output = np.empty((positions.shape[0], 1, 1, 2 * int(window) + 1), dtype=np.float32)
    seen = np.zeros(positions.shape[0], dtype=np.bool_)
    volume_shape = None
    with _open_segy(path, iline, xline) as handle:
        sample_count, sample_start, sample_interval = _sample_metadata(handle)
        volume_shape = (horizon_shape[0], horizon_shape[1], sample_count)
        for trace_index in range(handle.tracecount):
            header = handle.header[trace_index]
            inline_value = int(header[int(iline)])
            crossline_value = int(header[int(xline)])
            inline_index_float = (inline_value - inline_origin) / inline_step
            crossline_index_float = (crossline_value - crossline_origin) / crossline_step
            inline_index = int(round(inline_index_float))
            crossline_index = int(round(crossline_index_float))
            if (abs(inline_index_float - inline_index) > 1e-5 or
                    abs(crossline_index_float - crossline_index) > 1e-5 or
                    not (0 <= inline_index < horizon_shape[0] and 0 <= crossline_index < horizon_shape[1])):
                continue
            sample_index = int(index_grid[inline_index, crossline_index])
            if sample_index < 0:
                continue
            if seen[sample_index]:
                raise ValueError(f"SEG-Y存在重复空间位置：{inline_value},{crossline_value}")
            trace = np.asarray(handle.trace[trace_index], dtype=np.float32)
            if trace.size != sample_count or not np.isfinite(trace).all():
                raise ValueError(f"SEG-Y道{trace_index}长度或数值无效")
            sample = _trace_window(trace, centers[inline_index, crossline_index], window, sampling)
            if sample is None:
                continue
            output[sample_index, 0, 0, :] = sample
            seen[sample_index] = True
    if not seen.all():
        missing = int((~seen).sum())
        raise ValueError(f"SEG-Y缺少层位目标位置：{missing}个")
    return output, volume_shape, sample_start, sample_interval


def prepare_segy_samples(
    input_paths,
    horizon,
    window,
    stride,
    sampling,
    normalize,
    iline,
    xline,
    horizon_unit,
    horizon_scale,
    horizon_offset,
    horizon_shift,
    skip_invalid_horizon,
    axes=None,
    normalization_stats=None,
    inline_slice=None,
    crossline_slice=None,
):
    if not input_paths or not all(Path(path).suffix.lower() in {".sgy", ".segy"} for path in input_paths):
        raise ValueError("prepare_segy_samples只接受SEG-Y属性体")
    horizon = np.asarray(horizon, dtype=np.float64)
    if horizon.ndim != 2:
        raise ValueError("层位必须是二维数组")
    with _open_segy(input_paths[0], iline, xline) as handle:
        sample_count, sample_start, sample_interval = _sample_metadata(handle)
        volume_shape = (horizon.shape[0], horizon.shape[1], sample_count)
    actual_axes = _axis_values(axes, input_paths[0], iline, xline, horizon.shape)
    centers = _center_indices(
        horizon, sample_start, sample_interval, horizon_unit,
        horizon_scale, horizon_offset, horizon_shift,
    )
    positions = _sample_positions(
        horizon, centers, window, stride, sampling, skip_invalid_horizon,
        inline_slice=inline_slice, crossline_slice=crossline_slice,
    )
    sample_length = 2 * int(window) + 1
    raw = np.empty((positions.shape[0], len(input_paths), 1, sample_length), dtype=np.float32)
    for attribute_index, path in enumerate(input_paths):
        samples, current_shape, current_start, current_interval = read_segy_windows(
            path, horizon, positions, actual_axes, iline, xline,
            window, centers, sampling,
        )
        if current_shape != volume_shape or not np.isclose(current_start, sample_start) or not np.isclose(current_interval, sample_interval):
            raise ValueError(f"属性SEG-Y采样轴不一致：{path}")
        raw[:, attribute_index:attribute_index + 1] = samples
        del samples
    stats = normalization_stats or fit_normalization(raw, normalize)
    samples = apply_normalization(raw, stats)
    return samples, positions, volume_shape, stats
