from __future__ import annotations

import numpy as np


def remove_small_components(grid, min_size=0, connectivity=8):
    """Replace tiny labelled components by the dominant touching neighbour.

    The original -1 mask is preserved. A value of zero disables the extra
    pass, so the baseline majority-smoothed map remains reproducible.
    """
    values = np.asarray(grid, dtype=np.int32)
    if values.ndim != 2:
        raise ValueError("cluster grid必须是二维数组")
    min_size = int(min_size)
    if min_size <= 1:
        return values.copy(), {"min_size": min_size, "removed_components": 0, "changed_count": 0}
    if connectivity not in (4, 8):
        raise ValueError("connectivity必须是4或8")
    try:
        from scipy import ndimage
    except ImportError as error:
        raise ImportError("连通域清理需要 scipy") from error

    result = values.copy()
    structure = ndimage.generate_binary_structure(2, 2 if connectivity == 8 else 1)
    changed = 0
    removed = 0
    for cluster_id in np.unique(values):
        if cluster_id < 0:
            continue
        mask = values == int(cluster_id)
        labels, count = ndimage.label(mask, structure=structure)
        if count == 0:
            continue
        sizes = np.bincount(labels.ravel())
        for component_id in np.flatnonzero(sizes < min_size):
            if component_id == 0:
                continue
            component = labels == component_id
            ring = ndimage.binary_dilation(component, structure=structure) & ~component
            neighbours = result[ring]
            neighbours = neighbours[neighbours >= 0]
            if neighbours.size == 0:
                continue
            unique, counts = np.unique(neighbours, return_counts=True)
            replacement = int(unique[int(np.argmax(counts))])
            changed += int(component.sum())
            removed += 1
            result[component] = replacement
    return result, {
        "min_size": min_size,
        "connectivity": connectivity,
        "removed_components": removed,
        "changed_count": changed,
    }


def majority_smooth_labels(grid, clusters, kernel_size=3, iterations=1, min_votes=None):
    values = np.asarray(grid, dtype=np.int32)
    if values.ndim != 2:
        raise ValueError("cluster grid必须是二维数组")
    clusters = int(clusters)
    if clusters < 2:
        raise ValueError("clusters必须大于1")
    kernel_size = int(kernel_size)
    if kernel_size < 3 or kernel_size % 2 == 0:
        raise ValueError("kernel_size必须是大于等于3的奇数")
    iterations = int(iterations)
    if iterations < 1:
        raise ValueError("iterations必须为正整数")
    if min_votes is None:
        min_votes = kernel_size * kernel_size // 2 + 1
    min_votes = int(min_votes)
    if min_votes < 1 or min_votes > kernel_size * kernel_size:
        raise ValueError("min_votes超出邻域大小")
    result = values.copy()
    radius = kernel_size // 2
    total_changed = 0
    for _ in range(iterations):
        padded = np.pad(result, radius, mode="constant", constant_values=-1)
        counts = np.zeros((*result.shape, clusters), dtype=np.int16)
        for di in range(kernel_size):
            for dj in range(kernel_size):
                neighbor = padded[di:di + result.shape[0], dj:dj + result.shape[1]]
                for cluster_id in range(clusters):
                    counts[..., cluster_id] += (neighbor == cluster_id)
        valid = (result >= 0) & (result < clusters)
        best = np.argmax(counts, axis=-1).astype(np.int32)
        best_count = np.max(counts, axis=-1)
        current_count = np.zeros(result.shape, dtype=np.int16)
        if valid.any():
            rows, cols = np.nonzero(valid)
            current_count[rows, cols] = counts[rows, cols, result[rows, cols]]
        replace = valid & (best_count >= min_votes) & (best_count > current_count)
        total_changed += int(replace.sum())
        result[replace] = best[replace]
    return result, {
        "kernel_size": kernel_size,
        "iterations": iterations,
        "min_votes": min_votes,
        "changed_count": total_changed,
    }


def probability_smooth_labels(grid, probabilities, sigma=1.0, iterations=1):
    """Smooth class probabilities over valid cells, then recover hard labels.

    Invalid cells (negative labels) remain invalid. Each probability channel is
    normalized by the locally smoothed valid-cell mask so the survey boundary
    does not pull probabilities toward zero.
    """
    labels = np.asarray(grid, dtype=np.int32)
    probs = np.asarray(probabilities, dtype=np.float32)
    if labels.ndim != 2 or probs.ndim != 3 or probs.shape[:2] != labels.shape:
        raise ValueError("概率平滑要求labels为(H,W)、probabilities为(H,W,K)，且空间尺寸一致")
    clusters = int(probs.shape[2])
    if clusters < 2:
        raise ValueError("probabilities至少需要两个类别")
    sigma = float(sigma)
    iterations = int(iterations)
    if not np.isfinite(sigma) or sigma <= 0 or iterations < 1:
        raise ValueError("概率平滑参数要求sigma>0且iterations>=1")
    valid = (labels >= 0) & (labels < clusters) & np.isfinite(probs).all(axis=2)
    if not valid.any():
        return labels.copy(), {"sigma": sigma, "iterations": iterations, "changed_count": 0}
    try:
        from scipy.ndimage import gaussian_filter
    except ImportError as error:
        raise ImportError("概率平滑需要 scipy") from error

    current = np.where(valid[..., None], probs, 0.0)
    current = np.maximum(current, 0.0)
    totals = current.sum(axis=2, keepdims=True)
    current = np.divide(current, totals, out=np.zeros_like(current), where=totals > 0)
    mask = valid.astype(np.float32)
    for _ in range(iterations):
        denominator = gaussian_filter(mask, sigma=sigma, mode="constant", cval=0.0)
        smoothed = np.zeros_like(current)
        for class_id in range(clusters):
            numerator = gaussian_filter(
                current[..., class_id] * mask,
                sigma=sigma,
                mode="constant",
                cval=0.0,
            )
            smoothed[..., class_id] = np.divide(
                numerator, denominator, out=np.zeros_like(numerator), where=denominator > 1e-8
            )
        totals = smoothed.sum(axis=2, keepdims=True)
        current = np.divide(smoothed, totals, out=np.zeros_like(smoothed), where=totals > 1e-8)
        current[~valid] = 0.0

    result = labels.copy()
    result[valid] = np.argmax(current[valid], axis=1).astype(np.int32)
    return result, {
        "sigma": sigma,
        "iterations": iterations,
        "changed_count": int(np.count_nonzero(result[valid] != labels[valid])),
        "valid_cells": int(valid.sum()),
    }
