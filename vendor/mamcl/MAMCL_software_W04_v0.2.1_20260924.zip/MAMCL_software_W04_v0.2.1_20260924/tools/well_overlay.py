from __future__ import annotations

import csv
import io
from pathlib import Path

import numpy as np


def _decode_csv(path: Path, encoding: str | None):
    raw = path.read_bytes()
    # Prefer UTF-8 detection (including BOM); decoding UTF-8 bytes as GBK can
    # succeed while corrupting Chinese column names.
    candidates = ["utf-8-sig", "utf-8", encoding, "gb18030", "gbk"]
    candidates = list(dict.fromkeys(value for value in candidates if value))
    for candidate in candidates:
        if not candidate:
            continue
        try:
            return raw.decode(candidate), candidate
        except UnicodeDecodeError:
            continue
    raise UnicodeDecodeError("unknown", raw, 0, min(len(raw), 1), "无法识别井位CSV编码")


def _normal(text):
    return str(text or "").strip().replace(" ", "").replace("_", "").lower()


def _find_column(headers, requested, axis):
    if requested:
        requested_norm = _normal(requested)
        for index, header in enumerate(headers):
            if _normal(header) == requested_norm:
                return index
    aliases = {
        "x": ("x坐标", "xcoordinate", "xcoord", "utmx", "x"),
        "y": ("y坐标", "ycoordinate", "ycoord", "utmy", "y"),
    }[axis]
    normalized = [_normal(header) for header in headers]
    for alias in aliases:
        for index, value in enumerate(normalized):
            if value == alias or value.endswith(alias):
                return index
    fallback = 3 if axis == "x" else 4
    if fallback < len(headers):
        return fallback
    raise ValueError(f"井位CSV缺少{axis.upper()}坐标列")


def _find_name_column(headers, requested=None):
    if isinstance(requested, (int, np.integer)):
        return int(requested) if 0 <= int(requested) < len(headers) else None
    if requested is not None and str(requested).strip() != "":
        requested_norm = _normal(requested)
        for index, header in enumerate(headers):
            if _normal(header) == requested_norm:
                return index
    aliases = ("井号", "井名", "wellname", "well", "name", "id")
    normalized = [_normal(header) for header in headers]
    for alias in aliases:
        alias_norm = _normal(alias)
        for index, value in enumerate(normalized):
            if value == alias_norm or value.endswith(alias_norm):
                return index
    return 0 if headers else None


def load_well_points(path, encoding="gbk", x_column=None, y_column=None, name_column=None):
    if path is None or str(path).strip() == "":
        return np.empty((0, 2), dtype=np.float64), {
            "path": None,
            "count": 0,
            "labels": [],
            "status": "disabled",
        }
    csv_path = Path(path)
    if not csv_path.exists():
        return np.empty((0, 2), dtype=np.float64), {
            "path": str(csv_path),
            "count": 0,
            "labels": [],
            "status": "missing",
        }
    try:
        text, used_encoding = _decode_csv(csv_path, encoding)
        reader = csv.reader(io.StringIO(text))
        try:
            headers = next(reader)
        except StopIteration as exc:
            raise ValueError(f"井位CSV为空：{csv_path}") from exc
        x_index = _find_column(headers, x_column, "x")
        y_index = _find_column(headers, y_column, "y")
        name_index = _find_name_column(headers, name_column)
    except Exception as error:
        raise ValueError(f"井位CSV解析失败：{csv_path}；{error}") from error
    values = []
    labels = []
    for row in reader:
        if max(x_index, y_index) >= len(row):
            continue
        try:
            x_value = float(str(row[x_index]).strip())
            y_value = float(str(row[y_index]).strip())
        except (TypeError, ValueError):
            continue
        if np.isfinite(x_value) and np.isfinite(y_value):
            values.append((x_value, y_value))
            labels.append(str(row[name_index]).strip() if name_index is not None and name_index < len(row) else "")
    points = np.asarray(values, dtype=np.float64).reshape(-1, 2)
    return points, {
        "path": str(csv_path.resolve()),
        "encoding": used_encoding,
        "headers": [str(value) for value in headers],
        "x_column": str(headers[x_index]),
        "y_column": str(headers[y_index]),
        "name_column": str(headers[name_index]) if name_index is not None else None,
        "labels": labels,
        "count": int(points.shape[0]),
        "status": "ok",
    }


def _nearest_grid_cells(points, x_grid, y_grid, return_distance=False):
    rows, cols = x_grid.shape
    row_index = np.full(points.shape[0], -1, dtype=np.int64)
    col_index = np.full(points.shape[0], -1, dtype=np.int64)
    point_distance = np.full(points.shape[0], np.inf, dtype=np.float64)
    finite_grid = np.isfinite(x_grid) & np.isfinite(y_grid)
    if rows >= 2 and cols >= 2 and finite_grid[0, 0] and finite_grid[1, 0] and finite_grid[0, 1]:
        origin = np.array([x_grid[0, 0], y_grid[0, 0]], dtype=np.float64)
        row_vector = np.array([x_grid[1, 0] - origin[0], y_grid[1, 0] - origin[1]], dtype=np.float64)
        col_vector = np.array([x_grid[0, 1] - origin[0], y_grid[0, 1] - origin[1]], dtype=np.float64)
        matrix = np.column_stack((row_vector, col_vector))
        if abs(float(np.linalg.det(matrix))) > 1e-12:
            coefficients = np.linalg.solve(matrix, (points - origin).T).T
            candidate_rows = np.rint(coefficients[:, 0]).astype(np.int64)
            candidate_cols = np.rint(coefficients[:, 1]).astype(np.int64)
            candidate_inside = (candidate_rows >= 0) & (candidate_rows < rows) & (candidate_cols >= 0) & (candidate_cols < cols)
            row_index[candidate_inside] = candidate_rows[candidate_inside]
            col_index[candidate_inside] = candidate_cols[candidate_inside]
            selected = np.flatnonzero(candidate_inside)
            if selected.size:
                selected_rows = candidate_rows[selected]
                selected_cols = candidate_cols[selected]
                point_distance[selected] = np.hypot(
                    points[selected, 0] - x_grid[selected_rows, selected_cols],
                    points[selected, 1] - y_grid[selected_rows, selected_cols],
                )
    unresolved = (row_index < 0) | (col_index < 0)
    if unresolved.any():
        flat = np.flatnonzero(finite_grid.ravel())
        if flat.size:
            grid_points = np.column_stack((x_grid.ravel()[flat], y_grid.ravel()[flat]))
            unresolved_indices = np.flatnonzero(unresolved)
            for point_index in unresolved_indices:
                candidate_distance = np.sum((grid_points - points[point_index]) ** 2, axis=1)
                nearest = int(flat[int(np.argmin(candidate_distance))])
                row_index[point_index], col_index[point_index] = np.unravel_index(nearest, x_grid.shape)
                row, col = row_index[point_index], col_index[point_index]
                point_distance[point_index] = float(np.hypot(
                    points[point_index, 0] - x_grid[row, col],
                    points[point_index, 1] - y_grid[row, col],
                ))
    if return_distance:
        return row_index, col_index, point_distance
    return row_index, col_index


def scatter_wells(
    axis,
    points,
    coordinates,
    size=38.0,
    color="#ff00ff",
    edge_color="#ffffff",
    edge_width=0.9,
    label=None,
    labels=None,
    label_size=8.0,
    valid_mask=None,
):
    if points is None:
        return 0
    points = np.asarray(points, dtype=np.float64)
    if points.size == 0:
        return 0
    if points.ndim == 0 or points.size % 2 != 0:
        return 0
    points = points.reshape(-1, 2)
    point_labels = None
    if labels is not None:
        candidate_labels = np.asarray(labels, dtype=object).reshape(-1)
        if candidate_labels.shape[0] == points.shape[0]:
            point_labels = candidate_labels
    x_grid = np.asarray(coordinates["x"], dtype=np.float64)
    y_grid = np.asarray(coordinates["y"], dtype=np.float64)
    finite_grid = np.isfinite(x_grid) & np.isfinite(y_grid)
    if not finite_grid.any():
        return 0
    finite_points = np.isfinite(points).all(axis=1)
    points = points[finite_points]
    if point_labels is not None:
        point_labels = point_labels[finite_points]
    if points.size == 0:
        return 0
    x_min, x_max = float(np.nanmin(x_grid[finite_grid])), float(np.nanmax(x_grid[finite_grid]))
    y_min, y_max = float(np.nanmin(y_grid[finite_grid])), float(np.nanmax(y_grid[finite_grid]))
    inside = (
        (points[:, 0] >= x_min) & (points[:, 0] <= x_max)
        & (points[:, 1] >= y_min) & (points[:, 1] <= y_max)
    )
    if valid_mask is not None:
        mask = np.asarray(valid_mask, dtype=bool)
        if mask.shape == x_grid.shape:
            row_index, col_index, cell_distance = _nearest_grid_cells(
                points, x_grid, y_grid, return_distance=True
            )
            cell_inside = (row_index >= 0) & (col_index >= 0)
            cell_valid = np.zeros(points.shape[0], dtype=bool)
            valid_cells = cell_inside.nonzero()[0]
            if valid_cells.size:
                cell_valid[valid_cells] = mask[row_index[valid_cells], col_index[valid_cells]]
                row_spacing = np.hypot(np.diff(x_grid, axis=0), np.diff(y_grid, axis=0))
                col_spacing = np.hypot(np.diff(x_grid, axis=1), np.diff(y_grid, axis=1))
                spacing_values = np.concatenate((row_spacing.ravel(), col_spacing.ravel()))
                spacing_values = spacing_values[np.isfinite(spacing_values) & (spacing_values > 0)]
                if spacing_values.size:
                    cell_tolerance = 0.6 * float(np.sqrt(2.0) * np.median(spacing_values))
                    cell_valid &= cell_distance <= cell_tolerance
            inside &= cell_valid
    points = points[inside]
    if point_labels is not None:
        point_labels = point_labels[inside]
    if points.size == 0:
        return 0
    kwargs = {
        "s": float(size),
        "c": color,
        "marker": "o",
        "edgecolors": edge_color,
        "linewidths": float(edge_width),
        "alpha": 1.0,
        "zorder": 20,
    }
    if label:
        kwargs["label"] = str(label)
    axis.scatter(points[:, 0], points[:, 1], **kwargs)
    if point_labels is not None:
        for (x_value, y_value), point_label in zip(points, point_labels):
            text = str(point_label).strip()
            if not text or text.lower() in {"nan", "none"}:
                continue
            axis.annotate(
                text,
                (float(x_value), float(y_value)),
                xytext=(4, 4),
                textcoords="offset points",
                fontsize=float(label_size),
                color=color,
                fontweight="bold",
                zorder=21,
                bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.72, "pad": 0.8},
            )
    return int(points.shape[0])
