from __future__ import annotations

import csv
import io
import json
import math
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import numpy as np

from well_overlay import load_well_points


LABEL_NAMES = ("delta_plain", "delta_front", "shallow_lake", "deep_lake")
LABEL_TEXT = {
    "delta_plain": ("三角洲平原",),
    "delta_front": ("三角洲前缘",),
    "shallow_lake": ("滨浅湖", "浅湖"),
    "deep_lake": ("中深湖", "深湖"),
}


def _text(value):
    return str(value or "").replace(" ", "").replace("\u3000", "").strip()


def _decode(path, encoding="gbk"):
    raw = Path(path).read_bytes()
    # Try Unicode encodings first so a UTF-8 CSV is not silently decoded as
    # GBK/GB18030 into mojibake (those codecs accept many arbitrary byte pairs).
    candidates = ["utf-8-sig", "utf-8", encoding, "gb18030", "gbk"]
    for name in dict.fromkeys(candidates):
        if not name:
            continue
        try:
            return raw.decode(name), name
        except UnicodeDecodeError:
            pass
    raise ValueError(f"无法识别CSV编码：{path}")


def _split_labels(value):
    value = _text(value)
    result = []
    for key, tokens in LABEL_TEXT.items():
        if any(token in value for token in tokens):
            result.append(key)
    return result


def _segment_matches(row_segment, requested_segments):
    """Match single and combined labels such as '一、二段'."""
    value = _text(row_segment)
    requested = tuple(_text(item) for item in (requested_segments or ()) if _text(item))
    if not requested:
        return True
    available = {value}
    available.update(number + "段" for number in re.findall(r"[一二三四五六七八九十]+", value))
    return any(item in available or item in value for item in requested)


def _parse_csv(path, encoding="gbk"):
    text, used = _decode(path, encoding)
    reader = csv.reader(io.StringIO(text))
    headers = next(reader, [])
    headers_norm = [_text(v) for v in headers]
    def find(names):
        for i, v in enumerate(headers_norm):
            if v in names:
                return i
        return None
    name_i = find({"井号"})
    x_i = find({"X坐标"})
    y_i = find({"Y坐标"})
    label_i = find({"沉积亚相"})
    if label_i is None:
        label_i = find({"沉积相"})
    missing = [label for label, index in (("井号", name_i), ("X坐标", x_i), ("Y坐标", y_i)) if index is None]
    if missing:
        raise ValueError(
            "井位CSV表头不符合标准，缺少：" + "、".join(missing)
            + "。必需列为：井号、X坐标、Y坐标；可附加沉积亚相或沉积相列"
        )
    rows = []
    seen_names = set()
    for line_number, row in enumerate(reader, start=2):
        if not any(str(value).strip() for value in row):
            continue
        if max(name_i, x_i, y_i) >= len(row):
            raise ValueError(f"井位CSV第{line_number}行列数不足；请检查是否有不完整记录")
        name = _text(row[name_i])
        if not name:
            raise ValueError(f"井位CSV第{line_number}行缺少井号")
        try:
            x, y = float(row[x_i]), float(row[y_i])
        except (TypeError, ValueError):
            raise ValueError(f"井位CSV第{line_number}行X/Y坐标不是数字") from None
        if not np.isfinite([x, y]).all():
            raise ValueError(f"井位CSV第{line_number}行X/Y坐标含NaN或Inf")
        if name in seen_names:
            raise ValueError(f"井位CSV井号重复：{name}。标准格式要求每口井只保留一行坐标")
        seen_names.add(name)
        rows.append({
            "name": name,
            "x": x, "y": y,
            "labels": _split_labels(row[label_i]) if label_i is not None and label_i < len(row) else [],
            "source": "csv",
        })
    return rows, used


def _xlsx_rows(path):
    """Read the first worksheet without openpyxl, preserving merged-row blanks."""
    with zipfile.ZipFile(path) as zf:
        shared = []
        if "xl/sharedStrings.xml" in zf.namelist():
            root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
            for si in root.findall("m:si", ns):
                shared.append("".join(node.text or "" for node in si.iter() if node.tag.endswith("}t")))
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
        rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
        relmap = {r.attrib["Id"]: r.attrib["Target"] for r in rels}
        sheet = wb.find("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheets/{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheet")
        target = relmap[sheet.attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]]
        if not target.startswith("xl/"):
            target = "xl/" + target.lstrip("/")
        root = ET.fromstring(zf.read(target))
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    rows = []
    for row in root.findall(".//m:sheetData/m:row", ns):
        values = {}
        for cell in row.findall("m:c", ns):
            ref = cell.attrib.get("r", "")
            letters = "".join(ch for ch in ref if ch.isalpha())
            if not letters:
                continue
            index = 0
            for ch in letters.upper():
                index = index * 26 + ord(ch) - 64
            index -= 1
            value = cell.find("m:v", ns)
            text = "" if value is None else value.text or ""
            if cell.attrib.get("t") == "s" and text:
                text = shared[int(text)]
            elif cell.attrib.get("t") == "inlineStr":
                text = "".join(n.text or "" for n in cell.iter() if n.tag.endswith("}t"))
            values[index] = text
        rows.append(values)
    return rows


def _parse_xlsx(path, group="恩平组", segments=("一段",)):
    rows = _xlsx_rows(path)
    if not rows:
        raise ValueError("井相Excel没有内容")
    header = {_text(value): index for index, value in rows[0].items() if _text(value)}
    well_index = header.get("井号")
    group_index = header.get("组")
    segment_index = header.get("段")
    facies_indices = [header[name] for name in ("沉积亚相", "沉积相") if name in header]
    missing = [name for name, index in (("井号", well_index), ("组", group_index), ("段", segment_index)) if index is None]
    if not facies_indices:
        missing.append("沉积亚相/沉积相")
    if missing:
        raise ValueError(
            "井相Excel首个工作表第1行表头不符合标准，缺少：" + "、".join(missing)
            + "。必需列为：井号、组、段、沉积亚相（或沉积相）"
        )
    result = []
    current_well = ""
    group = _text(group)
    segments = tuple(_text(v) for v in (segments or ()))
    for row in rows[1:]:
        if _text(row.get(well_index, "")):
            current_well = _text(row.get(well_index, ""))
        if not current_well:
            continue
        row_group = _text(row.get(group_index, ""))
        row_segment = _text(row.get(segment_index, ""))
        if group and group not in row_group:
            continue
        if segments and not _segment_matches(row_segment, segments):
            continue
        labels = []
        for facies_index in facies_indices:
            labels = _split_labels(row.get(facies_index, ""))
            if labels:
                break
        if labels:
            result.append({"name": current_well, "labels": labels, "source": "xlsx", "group": row_group, "segment": row_segment})
    return result


def validate_well_inputs(csv_path, xlsx_path, encoding="gbk", group="", segments=()):
    """Validate the documented CSV/XLSX column contract without model work."""
    csv_path = Path(csv_path)
    xlsx_path = Path(xlsx_path)
    if csv_path.suffix.lower() != ".csv":
        raise ValueError(f"井位文件必须是.csv：{csv_path}")
    if xlsx_path.suffix.lower() != ".xlsx":
        raise ValueError(f"井相文件必须是.xlsx：{xlsx_path}")
    if not csv_path.is_file():
        raise FileNotFoundError(f"井位CSV不存在：{csv_path}")
    if not xlsx_path.is_file():
        raise FileNotFoundError(f"井相Excel不存在：{xlsx_path}")
    csv_qc = validate_well_csv(csv_path, encoding)
    csv_rows, used_encoding = _parse_csv(csv_path, encoding)
    all_xlsx_rows = _parse_xlsx(xlsx_path, group="", segments=())
    group = _text(group)
    segments = tuple(_text(value) for value in (segments or ()) if _text(value))
    if group:
        xlsx_rows = [row for row in all_xlsx_rows if group in row["group"]]
    else:
        xlsx_rows = list(all_xlsx_rows)
    if segments:
        xlsx_rows = [row for row in xlsx_rows if _segment_matches(row["segment"], segments)]
    csv_names = {row["name"] for row in csv_rows if row["name"]}
    xlsx_names = {row["name"] for row in xlsx_rows if row["name"]}
    matched = csv_names & xlsx_names
    if not csv_rows:
        raise ValueError("井位CSV没有可用的有限X/Y坐标行")
    if not xlsx_rows:
        filters = f"（组={group or '不限'}，段={','.join(segments) or '不限'}）"
        raise ValueError("井相Excel中没有符合当前组/段筛选条件的沉积相记录" + filters)
    if not matched:
        raise ValueError(
            "井位CSV与井相Excel没有匹配井名；请确保两文件‘井号’值完全一致，且去掉多余空格"
        )
    return {
        **csv_qc,
        "xlsx_labeled_records": len(xlsx_rows),
        "xlsx_wells": len(xlsx_names),
        "matched_wells": len(matched),
        "group_filter": group or None,
        "segment_filter": list(segments),
        "unmatched_csv_wells": sorted(csv_names - xlsx_names),
    }


def validate_well_csv(csv_path, encoding="gbk"):
    """Validate the standard well-position CSV independently of supervision."""
    csv_path = Path(csv_path)
    if csv_path.suffix.lower() != ".csv":
        raise ValueError(f"井位文件必须是.csv：{csv_path}")
    if not csv_path.is_file():
        raise FileNotFoundError(f"井位CSV不存在：{csv_path}")
    rows, used_encoding = _parse_csv(csv_path, encoding)
    if not rows:
        raise ValueError("井位CSV没有可用的有限X/Y坐标行")
    return {
        "csv_encoding": used_encoding,
        "csv_rows": len(rows),
        "csv_wells": len({row["name"] for row in rows if row["name"]}),
    }


def _well_distributions(csv_rows, xlsx_rows, fallback_weight=0.35):
    by_name = {}
    for row in xlsx_rows:
        by_name.setdefault(row["name"], []).append(row["labels"])
    records = []
    for row in csv_rows:
        labels = by_name.get(row["name"], [])
        if labels:
            values = np.zeros(len(LABEL_NAMES), dtype=np.float32)
            for labels_row in labels:
                for label in labels_row:
                    values[LABEL_NAMES.index(label)] += 1.0
            values /= max(float(values.sum()), 1.0)
            confidence = float(values.max())
            source = "xlsx"
        else:
            values = np.zeros(len(LABEL_NAMES), dtype=np.float32)
            fallback = row.get("labels", [])
            for label in fallback:
                values[LABEL_NAMES.index(label)] += 1.0
            if values.sum() > 0:
                values /= values.sum()
                confidence = float(values.max() * float(fallback_weight))
                values *= float(fallback_weight)
                source = "csv_fallback"
            else:
                confidence = 0.0
                source = "unlabeled"
        records.append({**row, "distribution": values, "confidence": confidence, "label_source": source})
    return records


def build_well_supervision(positions, coordinate_info, csv_path, xlsx_path, encoding="gbk", group="", segments=(), mode="neighbor_merge", sigma_factor=0.5, min_weight=0.05, max_neighbors=3, min_confidence=0.60, fallback_weight=0.35):
    positions = np.asarray(positions, dtype=np.int64)
    count = int(positions.shape[0])
    empty = (np.zeros((count, len(LABEL_NAMES)), dtype=np.float32), np.zeros(count, dtype=np.float32), np.zeros(count, dtype=bool))
    report = {"status": "disabled", "sample_count": count, "labels": list(LABEL_NAMES)}
    csv_path = Path(csv_path) if csv_path else None
    xlsx_path = Path(xlsx_path) if xlsx_path else None
    if csv_path is None or not csv_path.exists():
        report.update(status="csv_missing", csv_path=str(csv_path) if csv_path else None)
        return (*empty, report)
    csv_rows, used_encoding = _parse_csv(csv_path, encoding)
    xlsx_rows = []
    if xlsx_path is not None and xlsx_path.exists():
        xlsx_rows = _parse_xlsx(xlsx_path, group=group, segments=segments)
    records = _well_distributions(csv_rows, xlsx_rows, fallback_weight=fallback_weight)
    records = [r for r in records if np.any(r["distribution"] > 0)]
    if not records:
        report.update(status="no_labeled_wells", csv_path=str(csv_path), xlsx_path=str(xlsx_path) if xlsx_path else None)
        return (*empty, report)
    wells_xy = np.asarray([[r["x"], r["y"]] for r in records], dtype=np.float64)
    wells_labels = np.asarray([r["distribution"] for r in records], dtype=np.float32)
    wells_conf = np.asarray([r["confidence"] for r in records], dtype=np.float32)
    xgrid = np.asarray(coordinate_info["x"], dtype=np.float64)
    ygrid = np.asarray(coordinate_info["y"], dtype=np.float64)
    sample_xy = np.column_stack((xgrid[positions[:, 0], positions[:, 1]], ygrid[positions[:, 0], positions[:, 1]]))
    finite = np.isfinite(sample_xy).all(axis=1)
    nearest_well_spacing = np.full(len(records), 1.0, dtype=np.float64)
    if len(records) > 1:
        pair = np.sqrt(np.sum((wells_xy[:, None, :] - wells_xy[None, :, :]) ** 2, axis=2))
        pair[pair == 0] = np.inf
        candidate_spacing = np.nanmin(pair, axis=1)
        finite_spacing = candidate_spacing[np.isfinite(candidate_spacing) & (candidate_spacing > 0)]
        if finite_spacing.size:
            nearest_well_spacing = candidate_spacing.copy()
            nearest_well_spacing[~np.isfinite(nearest_well_spacing)] = float(np.median(finite_spacing))
    sigma = np.maximum(float(sigma_factor) * nearest_well_spacing, 1e-6)
    k = min(max(int(max_neighbors), 1), len(records))
    labels_out = np.zeros((count, len(LABEL_NAMES)), dtype=np.float32)
    weights_out = np.zeros(count, dtype=np.float32)
    mask_out = np.zeros(count, dtype=bool)
    finite_indices = np.flatnonzero(finite)
    # Process samples in chunks. A full sample-by-well distance matrix would
    # otherwise consume hundreds of MB for a million-point survey.
    for chunk_start in range(0, finite_indices.size, 65536):
        chunk_indices = finite_indices[chunk_start:chunk_start + 65536]
        delta = sample_xy[chunk_indices, None, :] - wells_xy[None, :, :]
        chunk_distances = np.sqrt(np.sum(delta * delta, axis=2))
        chunk_weights = np.exp(-0.5 * (chunk_distances / sigma[None, :]) ** 2) * wells_conf[None, :]
        for local_index, index in enumerate(chunk_indices):
            order = np.argsort(chunk_distances[local_index])[:k]
            weights = chunk_weights[local_index, order].copy()
            weights[weights < float(min_weight)] = 0.0
            total = float(weights.sum())
            if total <= 0:
                continue
            labels = (weights[:, None] * wells_labels[order]).sum(axis=0)
            labels /= max(float(labels.sum()), 1e-8)
            if mode == "neighbor_merge":
                dominant = int(np.argmax(labels))
                if float(labels[dominant]) >= 0.75:
                    hard = np.zeros_like(labels)
                    hard[dominant] = 1.0
                    labels = hard
            confidence = float(labels.max())
            labels_out[index] = labels
            weights_out[index] = min(total, 1.0)
            mask_out[index] = confidence >= float(min_confidence)
    report.update({
        "status": "ok", "csv_path": str(csv_path.resolve()), "xlsx_path": str(xlsx_path.resolve()) if xlsx_path and xlsx_path.exists() else None,
        "csv_encoding": used_encoding, "group": group, "segments": list(segments), "mode": mode,
        "well_count": len(records), "sample_count": count, "labeled_sample_count": int(mask_out.sum()),
        "label_counts": dict(zip(LABEL_NAMES, np.sum(labels_out[mask_out], axis=0).round(4).tolist())),
        "sigma_min": float(np.min(sigma)), "sigma_median": float(np.median(sigma)), "sigma_max": float(np.max(sigma)),
        "min_weight": float(min_weight), "max_neighbors": int(max_neighbors), "min_confidence": float(min_confidence),
        "well_names": [r["name"] for r in records], "well_label_sources": {r["name"]: r["label_source"] for r in records},
    })
    return labels_out, weights_out, mask_out, report

