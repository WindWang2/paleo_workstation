from __future__ import annotations

import time
from pathlib import Path

import numpy as np


def _reader(path):
    try:
        from pyzgy.accessors import SeismicReader
    except ImportError as exc:
        raise ImportError("读取ZGY需要安装pyzgy及其依赖") from exc
    return SeismicReader(str(path))


def _metadata(reader):
    shape = (int(reader.n_ilines), int(reader.n_xlines), int(reader.n_samples))
    origin = tuple(float(x) for x in reader.annotstart)
    step = tuple(float(x) for x in reader.annotinc)
    zstart = float(reader.samples[0])
    zinc = float(reader.samples[1] - reader.samples[0])
    zunit = str(getattr(reader, "zunitname", "") or "").lower().strip()
    if zunit in {"unknown", "none", "null", "na", "n/a", "not available"}:
        zunit = ""
    if len(origin) != 2 or len(step) != 2 or any(x <= 0 for x in step):
        raise ValueError("ZGY水平坐标起点或步长无效")
    if shape[2] < 2 or zinc <= 0:
        raise ValueError("ZGY垂向采样轴无效")
    return shape, origin, step, zstart, zinc, zunit


def _world_grid(reader, shape=None):
    shape = tuple(int(value) for value in (shape or (reader.n_ilines, reader.n_xlines)))
    if len(shape) < 2:
        raise ValueError("ZGY空间shape无效")
    corners = getattr(reader, "corners", None)
    if corners is None or len(corners) < 3:
        raise ValueError("ZGY文件没有可用的物理X/Y角点坐标")
    corners = np.asarray(corners, dtype=np.float64)
    if corners.ndim != 2 or corners.shape[1] < 2 or not np.isfinite(corners[:, :2]).all():
        raise ValueError("ZGY物理X/Y角点坐标无效")
    n_inline, n_crossline = shape[:2]
    if n_inline > 1:
        inline_increment = (corners[1, :2] - corners[0, :2]) / float(n_inline - 1)
    else:
        inline_increment = np.zeros(2, dtype=np.float64)
    if n_crossline > 1:
        crossline_increment = (corners[2, :2] - corners[0, :2]) / float(n_crossline - 1)
    else:
        crossline_increment = np.zeros(2, dtype=np.float64)
    inline, crossline = np.indices((n_inline, n_crossline), dtype=np.float64)
    world_x = (
        corners[0, 0]
        + inline * inline_increment[0]
        + crossline * crossline_increment[0]
    )
    world_y = (
        corners[0, 1]
        + inline * inline_increment[1]
        + crossline * crossline_increment[1]
    )
    return world_x, world_y


def _vertical_indices(values, horizon_unit, zstart, zinc, zunit):
    values = np.asarray(values, dtype=np.float64)
    unit = str(horizon_unit).lower()
    zunit = str(zunit or "").lower().strip()
    if zunit in {"unknown", "none", "null", "na", "n/a", "not available"}:
        zunit = ""
    if unit in {"samples", "sample", "index"}:
        return values
    if unit in {"s", "sec", "second", "seconds"}:
        values = values * 1000.0
        unit = "ms"
    z_is_time = zunit in {"ms", "millisecond", "milliseconds", "s", "sec", "second", "seconds", "seismictwt", "seismicowt"}
    if not zunit and unit in {"ms", "millisecond", "milliseconds", "s", "sec", "second", "seconds"}:
        z_is_time = True
    if not z_is_time:
        raise ValueError(f"ZGY垂向单位为{zunit or 'unknown'}，不能与时间层位自动换算")
    if zunit in {"s", "sec", "second", "seconds"}:
        zstart *= 1000.0
        zinc *= 1000.0
    if unit not in {"ms", "millisecond", "milliseconds"}:
        raise ValueError("horizon_unit必须是samples、ms或s")
    return (values - zstart) / zinc


def _axis_index(values, origin, step, size, name, allow_outside=False):
    indices = (np.asarray(values, dtype=np.float64) - origin) / step
    rounded = np.rint(indices)
    if not np.allclose(indices, rounded, rtol=0, atol=1e-5):
        raise ValueError(f"层位{name}坐标不在ZGY规则网格上")
    outside = (rounded < 0) | (rounded >= size)
    if np.any(outside) and not allow_outside:
        raise ValueError(f"层位{name}坐标超出ZGY范围")
    if allow_outside:
        rounded = rounded.astype(np.int64)
        rounded[outside] = -1
        return rounded
    return rounded.astype(np.int64)


def _surface_axis_indices(axes, surface_shape, zgy_origin, zgy_step, zgy_shape, label):
    surface_shape = tuple(int(value) for value in surface_shape[:2])
    if axes is None:
        if surface_shape != tuple(int(value) for value in zgy_shape[:2]):
            raise ValueError(f"{label}层位shape与ZGY不同，且没有提供层位坐标轴")
        axes = (
            float(zgy_origin[0]),
            float(zgy_origin[1]),
            float(zgy_step[0]),
            float(zgy_step[1]),
        )
    if len(axes) != 4 or any(value is None for value in axes):
        raise ValueError(f"{label}层位坐标轴必须为(inline_origin,crossline_origin,inline_step,crossline_step)")
    origin = (float(axes[0]), float(axes[1]))
    step = (float(axes[2]), float(axes[3]))
    if any(value <= 0 for value in step):
        raise ValueError(f"{label}层位坐标步长必须为正")
    inline_values = origin[0] + np.arange(surface_shape[0], dtype=np.float64) * step[0]
    crossline_values = origin[1] + np.arange(surface_shape[1], dtype=np.float64) * step[1]
    inline_indices = _axis_index(
        inline_values, zgy_origin[0], zgy_step[0], int(zgy_shape[0]), f"{label}inline", allow_outside=True
    )
    crossline_indices = _axis_index(
        crossline_values, zgy_origin[1], zgy_step[1], int(zgy_shape[1]), f"{label}crossline", allow_outside=True
    )
    return inline_indices, crossline_indices, origin, step


def _axis_range(indices, name):
    indices = np.asarray(indices, dtype=np.int64)
    valid = indices >= 0
    if not valid.any():
        raise ValueError(f"{name}层位没有落在ZGY空间范围内的坐标")
    return int(indices[valid].min()), int(indices[valid].max())


def _align_surface_to_crop(surface, inline_indices, crossline_indices, crop):
    surface = np.asarray(surface, dtype=np.float64)
    if surface.ndim != 2:
        raise ValueError("层位必须是二维数组")
    inline_start, inline_stop, crossline_start, crossline_stop = (int(value) for value in crop)
    rows = np.flatnonzero((inline_indices >= inline_start) & (inline_indices < inline_stop))
    cols = np.flatnonzero((crossline_indices >= crossline_start) & (crossline_indices < crossline_stop))
    row_targets = np.asarray(inline_indices[rows] - inline_start, dtype=np.int64)
    col_targets = np.asarray(crossline_indices[cols] - crossline_start, dtype=np.int64)
    if np.unique(row_targets).size != row_targets.size or np.unique(col_targets).size != col_targets.size:
        raise ValueError("层位坐标映射到ZGY后存在重复网格位置")
    aligned = np.full((inline_stop - inline_start, crossline_stop - crossline_start), np.nan, dtype=np.float64)
    aligned[np.ix_(row_targets, col_targets)] = surface[np.ix_(rows, cols)]
    return aligned


def _fill_surface_gaps(surface, method, max_fill_distance_factor, low_confidence_distance_factor):
    surface = np.asarray(surface, dtype=np.float64)
    original_valid = np.isfinite(surface)
    result = surface.copy()
    diagnostics = {
        "original_valid_mask": original_valid.copy(),
        "linear_filled_mask": np.zeros(surface.shape, dtype=bool),
        "nearest_filled_mask": np.zeros(surface.shape, dtype=bool),
        "unsupported_mask": ~original_valid,
        "low_confidence_mask": np.zeros(surface.shape, dtype=bool),
        "source_distance": np.full(surface.shape, np.inf, dtype=np.float32),
        "typical_spacing": 1.0,
    }
    if original_valid.all() or int(original_valid.sum()) < 3:
        return result, diagnostics
    interpolated, raw_diagnostics = _interpolate_horizon_to_zgy(
        surface,
        (0.0, 0.0),
        (1.0, 1.0),
        (0.0, 0.0),
        (1.0, 1.0),
        surface.shape,
        method=method,
        max_fill_distance_factor=max_fill_distance_factor,
        low_confidence_distance_factor=low_confidence_distance_factor,
        return_diagnostics=True,
    )
    distance = np.asarray(raw_diagnostics["source_distance"], dtype=np.float64)
    spacing = float(raw_diagnostics.get("typical_spacing", 1.0))
    max_distance = spacing * float(max_fill_distance_factor)
    candidate = ~original_valid & np.isfinite(interpolated) & (distance <= max_distance)
    result[candidate] = interpolated[candidate]
    linear_mask = candidate & np.asarray(raw_diagnostics["interpolated_mask"], dtype=bool)
    nearest_mask = candidate & np.asarray(raw_diagnostics["nearest_filled_mask"], dtype=bool)
    diagnostics.update(
        {
            "linear_filled_mask": linear_mask,
            "nearest_filled_mask": nearest_mask,
            "unsupported_mask": ~np.isfinite(result),
            "low_confidence_mask": np.asarray(raw_diagnostics["low_confidence_mask"], dtype=bool) & np.isfinite(result),
            "source_distance": distance.astype(np.float32),
            "typical_spacing": spacing,
        }
    )
    return result, diagnostics


def _surface_fill_diagnostics(surface):
    surface = np.asarray(surface, dtype=np.float64)
    valid = np.isfinite(surface)
    return {
        "original_valid_mask": valid.copy(),
        "linear_filled_mask": np.zeros(surface.shape, dtype=bool),
        "nearest_filled_mask": np.zeros(surface.shape, dtype=bool),
        "unsupported_mask": ~valid,
        "low_confidence_mask": np.zeros(surface.shape, dtype=bool),
        "source_distance": np.full(surface.shape, np.inf, dtype=np.float32),
        "typical_spacing": 1.0,
    }



def _fill_remaining_common_nearest(surface):
    """Fill every remaining hole inside the already aligned common crop.

    This is deliberately applied only after both horizons have been aligned to
    their common ZGY crop. The outer ZGY area is never passed here and remains
    invalid in the output grid.
    """
    surface = np.asarray(surface, dtype=np.float64).copy()
    valid = np.isfinite(surface)
    forced = np.zeros(surface.shape, dtype=bool)
    if valid.all() or not valid.any():
        return surface, forced
    missing = ~valid
    source_coords = np.column_stack(np.nonzero(valid)).astype(np.float64)
    target_coords = np.column_stack(np.nonzero(missing)).astype(np.float64)
    from scipy.spatial import cKDTree
    tree = cKDTree(source_coords)
    try:
        _, nearest = tree.query(target_coords, k=1, workers=-1)
    except TypeError:
        _, nearest = tree.query(target_coords, k=1)
    nearest = np.asarray(nearest, dtype=np.int64)
    source_values = surface[valid]
    rows = target_coords[:, 0].astype(np.int64)
    cols = target_coords[:, 1].astype(np.int64)
    surface[rows, cols] = source_values[nearest]
    forced[rows, cols] = True
    return surface, forced

def _crop_and_fill_interval_surfaces(
    upper,
    lower,
    upper_axes,
    lower_axes,
    zgy_shape,
    zgy_origin,
    zgy_step,
    fill_horizon_nans,
    interpolation_method,
    max_fill_distance_factor,
    low_confidence_distance_factor,
    upper_world_x=None,
    upper_world_y=None,
    lower_world_x=None,
    lower_world_y=None,
    target_world_x=None,
    target_world_y=None,
):
    upper = np.asarray(upper, dtype=np.float64)
    lower = np.asarray(lower, dtype=np.float64)
    if upper.ndim != 2 or lower.ndim != 2:
        raise ValueError("上下层位必须是二维数组")
    upper_i, upper_x, upper_origin, upper_step = _surface_axis_indices(
        upper_axes, upper.shape, zgy_origin, zgy_step, zgy_shape, "上"
    )
    lower_i, lower_x, lower_origin, lower_step = _surface_axis_indices(
        lower_axes, lower.shape, zgy_origin, zgy_step, zgy_shape, "下"
    )
    upper_i0, upper_i1 = _axis_range(upper_i, "上inline")
    lower_i0, lower_i1 = _axis_range(lower_i, "下inline")
    upper_x0, upper_x1 = _axis_range(upper_x, "上crossline")
    lower_x0, lower_x1 = _axis_range(lower_x, "下crossline")
    crop = (
        max(upper_i0, lower_i0),
        min(upper_i1, lower_i1) + 1,
        max(upper_x0, lower_x0),
        min(upper_x1, lower_x1) + 1,
    )
    if crop[0] >= crop[1] or crop[2] >= crop[3]:
        raise ValueError("上下层位与ZGY没有共同的物理坐标范围")
    upper_aligned = _align_surface_to_crop(upper, upper_i, upper_x, crop)
    lower_aligned = _align_surface_to_crop(lower, lower_i, lower_x, crop)
    upper_before = np.isfinite(upper_aligned)
    lower_before = np.isfinite(lower_aligned)
    if fill_horizon_nans:
        target_origin = (
            float(zgy_origin[0] + crop[0] * zgy_step[0]),
            float(zgy_origin[1] + crop[2] * zgy_step[1]),
        )
        target_shape = upper_aligned.shape

        upper_original_values = upper_aligned.copy()
        lower_original_values = lower_aligned.copy()

        def interpolate_source(surface, source_axes, source_world_x, source_world_y, original_values):
            source_origin = (float(source_axes[0]), float(source_axes[1]))
            source_step = (float(source_axes[2]), float(source_axes[3]))
            source_x = None if source_world_x is None else np.asarray(source_world_x, dtype=np.float64)
            source_y = None if source_world_y is None else np.asarray(source_world_y, dtype=np.float64)
            target_x = None if target_world_x is None else np.asarray(target_world_x, dtype=np.float64)[crop[0]:crop[1], crop[2]:crop[3]]
            target_y = None if target_world_y is None else np.asarray(target_world_y, dtype=np.float64)[crop[0]:crop[1], crop[2]:crop[3]]
            if source_x is not None or source_y is not None:
                if source_x is None or source_y is None:
                    raise ValueError("上下层位物理X/Y坐标必须成对提供")
                if target_x is None or target_y is None:
                    raise ValueError("使用物理X/Y层位插值时必须提供ZGY目标物理网格")
                world_valid = np.isfinite(surface) & np.isfinite(source_x) & np.isfinite(source_y)
                world_points = np.column_stack((source_x[world_valid], source_y[world_valid]))
                unique_world_points = np.unique(world_points, axis=0)
                rank = np.linalg.matrix_rank(unique_world_points - unique_world_points.mean(axis=0)) if unique_world_points.shape[0] >= 2 else 0
                if world_points.shape[0] < 3 or unique_world_points.shape[0] < 3 or rank < 2:
                    source_x = source_y = target_x = target_y = None
            interpolated, raw = _interpolate_horizon_to_zgy(
                surface,
                source_origin,
                source_step,
                target_origin,
                zgy_step,
                target_shape,
                method=interpolation_method,
                source_world_x=source_x,
                source_world_y=source_y,
                target_world_x=target_x,
                target_world_y=target_y,
                max_fill_distance_factor=max_fill_distance_factor,
                low_confidence_distance_factor=low_confidence_distance_factor,
                return_diagnostics=True,
            )
            interpolated = np.asarray(interpolated, dtype=np.float64)
            original_values = np.asarray(original_values, dtype=np.float64)
            original = np.isfinite(original_values)
            interpolated[original] = original_values[original]
            linear_mask = np.asarray(raw["interpolated_mask"], dtype=bool) & ~original
            nearest_mask = np.asarray(raw["nearest_filled_mask"], dtype=bool) & ~original
            common_nearest_mask = np.zeros(interpolated.shape, dtype=bool)
            if fill_horizon_nans:
                interpolated, common_nearest_mask = _fill_remaining_common_nearest(interpolated)
                nearest_mask |= common_nearest_mask
            diagnostics = {
                "linear_filled_mask": linear_mask,
                "nearest_filled_mask": nearest_mask,
                "common_nearest_filled_mask": common_nearest_mask,
                "unsupported_mask": ~np.isfinite(interpolated),
                "low_confidence_mask": np.asarray(raw["low_confidence_mask"], dtype=bool) & np.isfinite(interpolated),
                "source_distance": np.asarray(raw["source_distance"], dtype=np.float32),
                "typical_spacing": float(raw.get("typical_spacing", 1.0)),
            }
            return interpolated.astype(np.float32), diagnostics

        upper_aligned, upper_fill = interpolate_source(
            upper, (upper_origin[0], upper_origin[1], upper_step[0], upper_step[1]),
            upper_world_x, upper_world_y, upper_original_values,
        )
        lower_aligned, lower_fill = interpolate_source(
            lower, (lower_origin[0], lower_origin[1], lower_step[0], lower_step[1]),
            lower_world_x, lower_world_y, lower_original_values,
        )
    else:
        upper_fill = _surface_fill_diagnostics(upper_aligned)
        lower_fill = _surface_fill_diagnostics(lower_aligned)
    aligned_axes = (
        float(zgy_origin[0] + crop[0] * zgy_step[0]),
        float(zgy_origin[1] + crop[2] * zgy_step[1]),
        float(zgy_step[0]),
        float(zgy_step[1]),
    )
    metadata = {
        "mode": "crop_then_fill" if fill_horizon_nans else "crop_only",
        "zgy_shape": [int(value) for value in zgy_shape[:2]],
        "crop_index": [int(value) for value in crop],
        "crop_shape": [int(upper_aligned.shape[0]), int(upper_aligned.shape[1])],
        "aligned_axes": [float(value) for value in aligned_axes],
        "upper_source_shape": [int(value) for value in upper.shape],
        "lower_source_shape": [int(value) for value in lower.shape],
        "upper_source_axes": [float(value) for value in (*upper_origin, *upper_step)],
        "lower_source_axes": [float(value) for value in (*lower_origin, *lower_step)],
        "upper_original_valid": int(upper_before.sum()),
        "lower_original_valid": int(lower_before.sum()),
        "upper_filled_linear": int(upper_fill["linear_filled_mask"].sum()),
        "upper_filled_nearest": int(upper_fill["nearest_filled_mask"].sum()),
        "upper_filled_common_nearest": int(upper_fill.get("common_nearest_filled_mask", np.zeros_like(upper_aligned, dtype=bool)).sum()),
        "upper_remaining_invalid": int((~np.isfinite(upper_aligned)).sum()),
        "lower_filled_linear": int(lower_fill["linear_filled_mask"].sum()),
        "lower_filled_nearest": int(lower_fill["nearest_filled_mask"].sum()),
        "lower_filled_common_nearest": int(lower_fill.get("common_nearest_filled_mask", np.zeros_like(lower_aligned, dtype=bool)).sum()),
        "lower_remaining_invalid": int((~np.isfinite(lower_aligned)).sum()),
        "upper_typical_spacing": float(upper_fill["typical_spacing"]),
        "lower_typical_spacing": float(lower_fill["typical_spacing"]),
    }
    return upper_aligned, lower_aligned, aligned_axes, metadata


def _query_tree(tree, points, k=1):
    try:
        return tree.query(points, k=k, workers=-1)
    except TypeError:
        return tree.query(points, k=k)


def _is_close_grid(values, reference):
    finite = np.isfinite(values) & np.isfinite(reference)
    if not finite.any():
        return False
    scale = max(float(np.nanmax(np.abs(reference[finite]))), 1.0)
    return bool(np.allclose(values[finite], reference[finite], rtol=1e-7, atol=scale * 1e-8))


def _rectilinear_axes(x, y, values):
    x_reference = np.broadcast_to(x[0:1, :], x.shape)
    y_reference = np.broadcast_to(y[:, 0:1], y.shape)
    if not _is_close_grid(x, x_reference) or not _is_close_grid(y, y_reference):
        return None
    x_axis = np.asarray(x[0, :], dtype=float)
    y_axis = np.asarray(y[:, 0], dtype=float)
    rect_values = np.asarray(values, dtype=float)
    if np.any(np.diff(x_axis) == 0) or np.any(np.diff(y_axis) == 0):
        return None
    if x_axis[0] > x_axis[-1]:
        x_axis = x_axis[::-1]
        rect_values = rect_values[:, ::-1]
    if y_axis[0] > y_axis[-1]:
        y_axis = y_axis[::-1]
        rect_values = rect_values[::-1, :]
    return y_axis, x_axis, rect_values


def _nearest_axis_indices(axis, values):
    upper = np.searchsorted(axis, values, side="left")
    upper = np.clip(upper, 0, axis.size - 1)
    lower = np.clip(upper - 1, 0, axis.size - 1)
    choose_upper = np.abs(axis[upper] - values) < np.abs(axis[lower] - values)
    return np.where(choose_upper, upper, lower)


def _interpolate_horizon_to_zgy(
    horizon,
    horizon_origin,
    horizon_step,
    zgy_origin,
    zgy_step,
    target_shape,
    method="linear_nearest",
    source_world_x=None,
    source_world_y=None,
    target_world_x=None,
    target_world_y=None,
    max_fill_distance_factor=2.0,
    low_confidence_distance_factor=1.0,
    return_diagnostics=False,
):
    horizon = np.asarray(horizon, dtype=np.float64)
    target_shape = tuple(int(value) for value in target_shape[:2])
    if source_world_x is not None or source_world_y is not None:
        if source_world_x is None or source_world_y is None:
            raise ValueError("source_world_x和source_world_y必须同时提供")
        source_world_x = np.asarray(source_world_x, dtype=np.float64)
        source_world_y = np.asarray(source_world_y, dtype=np.float64)
        if source_world_x.shape != horizon.shape or source_world_y.shape != horizon.shape:
            raise ValueError("层位物理X/Y坐标shape必须与层位shape一致")
    world_mode = source_world_x is not None
    if world_mode:
        finite = np.isfinite(horizon) & np.isfinite(source_world_x) & np.isfinite(source_world_y)
        if not finite.any():
            raise ValueError("层位没有有效的物理X/Y和值")
    else:
        inline_values = horizon_origin[0] + np.arange(horizon.shape[0], dtype=np.float64) * horizon_step[0]
        crossline_values = horizon_origin[1] + np.arange(horizon.shape[1], dtype=np.float64) * horizon_step[1]
        inline_indices = _axis_index(
            inline_values, zgy_origin[0], zgy_step[0], target_shape[0], "inline",
            allow_outside=True,
        )
        crossline_indices = _axis_index(
            crossline_values, zgy_origin[1], zgy_step[1], target_shape[1], "crossline",
            allow_outside=True,
        )
        finite = np.isfinite(horizon)
        finite &= inline_indices[:, None] >= 0
        finite &= crossline_indices[None, :] >= 0
        if not finite.any():
            raise ValueError("层位在ZGY网格内没有可插值的有效点")
        total = np.zeros(target_shape, dtype=np.float64)
        count = np.zeros(target_shape, dtype=np.int32)
        source_inline = np.broadcast_to(inline_indices[:, None], horizon.shape)[finite]
        source_crossline = np.broadcast_to(crossline_indices[None, :], horizon.shape)[finite]
        np.add.at(total, (source_inline, source_crossline), horizon[finite])
        np.add.at(count, (source_inline, source_crossline), 1)
    method = str(method).lower()
    if method not in {"nearest", "linear_nearest"}:
        raise ValueError("horizon interpolation method must be nearest or linear_nearest")
    result = np.full(target_shape, np.nan, dtype=np.float64)
    if world_mode:
        points = np.column_stack((source_world_x[finite], source_world_y[finite]))
        values = horizon[finite].astype(np.float64)
    else:
        valid = count > 0
        result[valid] = total[valid] / count[valid]
        if not valid.any():
            raise ValueError("层位在ZGY网格内没有可插值的有效点")
        valid_inline, valid_crossline = np.nonzero(valid)
        points = np.column_stack((valid_inline, valid_crossline)).astype(np.float64)
        values = result[valid].astype(np.float64)

    if target_world_x is not None or target_world_y is not None:
        if target_world_x is None or target_world_y is None:
            raise ValueError("target_world_x和target_world_y必须同时提供")
        target_world_x = np.asarray(target_world_x, dtype=np.float64)
        target_world_y = np.asarray(target_world_y, dtype=np.float64)
        if target_world_x.shape != target_shape or target_world_y.shape != target_shape:
            raise ValueError("目标物理X/Y坐标shape必须与ZGY空间shape一致")
        target_points = np.column_stack((target_world_x.ravel(), target_world_y.ravel()))
    else:
        target_inline, target_crossline = np.meshgrid(
            np.arange(target_shape[0], dtype=np.float64),
            np.arange(target_shape[1], dtype=np.float64),
            indexing="ij",
        )
        target_points = np.column_stack((target_inline.ravel(), target_crossline.ravel()))

    from scipy.interpolate import LinearNDInterpolator, RegularGridInterpolator
    from scipy.spatial import cKDTree

    if points.shape[0] < 3:
        raise ValueError("层位有效点少于三个，无法进行二维空间插值")
    rectilinear = None
    if world_mode:
        rectilinear = _rectilinear_axes(source_world_x, source_world_y, horizon)
    if rectilinear is not None:
        y_axis, x_axis, rect_values = rectilinear
        try:
            linear_interpolator = RegularGridInterpolator(
                (y_axis, x_axis),
                rect_values,
                method="linear",
                bounds_error=False,
                fill_value=np.nan,
            )
            linear_values = np.asarray(
                linear_interpolator(target_points[:, ::-1]), dtype=np.float64
            )
            if target_world_x is not None:
                inside_support = (
                    (target_world_x >= x_axis[0])
                    & (target_world_x <= x_axis[-1])
                    & (target_world_y >= y_axis[0])
                    & (target_world_y <= y_axis[-1])
                ).ravel()
            else:
                inside_support = (
                    (target_points[:, 0] >= x_axis[0])
                    & (target_points[:, 0] <= x_axis[-1])
                    & (target_points[:, 1] >= y_axis[0])
                    & (target_points[:, 1] <= y_axis[-1])
                )
        except (ValueError, RuntimeError) as exc:
            if method == "nearest":
                linear_values = np.full(target_points.shape[0], np.nan, dtype=np.float64)
                inside_support = np.ones(target_points.shape[0], dtype=bool)
            else:
                raise ValueError(f"层位规则网格线性插值失败：{exc}") from exc
        spacings = np.concatenate([np.abs(np.diff(x_axis)), np.abs(np.diff(y_axis))])
        spacings = spacings[np.isfinite(spacings) & (spacings > 0)]
        typical_spacing = float(np.median(spacings)) if spacings.size else 1.0
    else:
        try:
            linear_interpolator = LinearNDInterpolator(points, values, fill_value=np.nan)
            linear_values = np.asarray(linear_interpolator(target_points), dtype=np.float64)
            inside_support = linear_interpolator.tri.find_simplex(target_points) >= 0
        except (ValueError, RuntimeError) as exc:
            if method == "nearest":
                linear_values = np.full(target_points.shape[0], np.nan, dtype=np.float64)
                inside_support = np.ones(target_points.shape[0], dtype=bool)
            else:
                raise ValueError(f"层位线性空间插值失败：{exc}") from exc
        tree = cKDTree(points)
        source_distance, nearest_index = _query_tree(tree, target_points, k=1)
        spacing_query_k = min(2, points.shape[0])
        spacing_distances, _ = _query_tree(tree, points, k=spacing_query_k)
        if spacing_query_k == 1:
            positive_spacing = np.asarray(spacing_distances, dtype=np.float64)
        else:
            positive_spacing = np.asarray(spacing_distances[:, -1], dtype=np.float64)
        positive_spacing = positive_spacing[np.isfinite(positive_spacing) & (positive_spacing > 0)]
        typical_spacing = float(np.median(positive_spacing)) if positive_spacing.size else 1.0
    if rectilinear is not None and np.isfinite(rect_values).all() and np.isfinite(target_points).all():
        x_indices = _nearest_axis_indices(x_axis, target_points[:, 0])
        y_indices = _nearest_axis_indices(y_axis, target_points[:, 1])
        source_distance = np.hypot(
            target_points[:, 0] - x_axis[x_indices],
            target_points[:, 1] - y_axis[y_indices],
        )
        nearest_index = y_indices * x_axis.size + x_indices
        nearest_values = rect_values.ravel()
    elif rectilinear is not None:
        tree = cKDTree(points)
        source_distance, nearest_index = _query_tree(tree, target_points, k=1)
        nearest_values = values
    else:
        nearest_values = values
    linear_values = linear_values.reshape(target_shape)
    inside_support = inside_support.reshape(target_shape)
    source_distance = np.asarray(source_distance, dtype=np.float64).reshape(target_shape)
    nearest_index = np.asarray(nearest_index, dtype=np.int64).reshape(target_shape)
    nearest_filled = np.zeros(target_shape, dtype=bool)
    max_fill_distance = typical_spacing * float(max_fill_distance_factor)
    if method == "nearest":
        fillable = inside_support & (source_distance <= max_fill_distance)
        result = np.full(target_shape, np.nan, dtype=np.float64)
        result[fillable] = nearest_values[nearest_index[fillable]]
        nearest_filled[fillable] = True
    else:
        result = linear_values.copy()
        fillable = (~np.isfinite(result)) & inside_support & (source_distance <= max_fill_distance)
        if fillable.any():
            result[fillable] = nearest_values[nearest_index[fillable]]
            nearest_filled[fillable] = True
    result[~inside_support] = np.nan
    valid_result = np.isfinite(result)
    interpolated_mask = np.isfinite(linear_values) & inside_support
    low_confidence = valid_result & (
        nearest_filled
        | (source_distance > typical_spacing * float(low_confidence_distance_factor))
    )
    diagnostics = {
        "interpolated_mask": interpolated_mask,
        "nearest_filled_mask": nearest_filled,
        "extrapolated_mask": ~inside_support,
        "source_distance": source_distance.astype(np.float32),
        "valid_mask": valid_result,
        "low_confidence_mask": low_confidence,
        "typical_spacing": typical_spacing,
    }
    output = np.asarray(result, dtype=np.float32)
    if return_diagnostics:
        return output, diagnostics
    return output


def _window(trace, center, window, sampling):
    positions = float(center) + np.arange(-window, window + 1, dtype=np.float64)
    if positions[0] < 0 or positions[-1] >= trace.size:
        return None
    if sampling == "integer":
        if not np.allclose(positions, np.rint(positions), rtol=0, atol=1e-6):
            raise ValueError("integer取样要求层位换算后为整数采样点")
        return np.asarray(trace[np.rint(positions).astype(np.int64)], dtype=np.float32)
    if sampling != "linear":
        raise ValueError("sampling必须是integer或linear")
    left = np.floor(positions).astype(np.int64)
    right = np.minimum(left + 1, trace.size - 1)
    fraction = positions - left
    return np.asarray(trace[left] * (1 - fraction) + trace[right] * fraction, dtype=np.float32)


def _one_sided_window(trace, start, span, z0, sampling="linear", padding_mode="edge"):
    trace = np.asarray(trace, dtype=np.float32)
    span = int(span)
    if span < 0:
        raise ValueError("单向窗口跨度不能为负数")
    positions = float(start) + np.arange(span + 1, dtype=np.float64)
    global_first = float(z0)
    global_last = float(z0 + trace.size - 1)
    outside = (positions < global_first) | (positions > global_last)
    mode = str(padding_mode).lower()
    if mode not in {"edge", "zero"}:
        raise ValueError("padding_mode目前必须是edge或zero")
    if sampling == "integer":
        rounded = np.rint(positions).astype(np.int64)
        if not np.allclose(positions, rounded, rtol=0, atol=1e-6):
            raise ValueError("integer取样要求层位换算后为整数采样点")
        local = rounded - int(z0)
        clipped = np.clip(local, 0, trace.size - 1)
        sample = trace[clipped]
    elif sampling == "linear":
        left_global = np.floor(positions).astype(np.int64)
        right_global = left_global + 1
        fraction = positions - left_global
        left = np.clip(left_global - int(z0), 0, trace.size - 1)
        right = np.clip(right_global - int(z0), 0, trace.size - 1)
        sample = trace[left] * (1.0 - fraction) + trace[right] * fraction
    else:
        raise ValueError("sampling必须是integer或linear")
    sample = np.asarray(sample, dtype=np.float32)
    if mode == "zero" and outside.any():
        sample[outside] = 0.0
    return sample, bool(outside.any())


def _interval_center(upper, lower, mode="equal", fraction=0.5):
    mode = str(mode).lower()
    if mode in {"equal", "midpoint", "middle"}:
        lower_weight = 0.5
    elif mode in {"weighted", "fraction"}:
        lower_weight = float(fraction)
    elif mode in {"upper_biased", "upper"}:
        lower_weight = 0.25
    elif mode in {"lower_biased", "lower"}:
        lower_weight = 0.75
    else:
        raise ValueError(
            "interval_center_mode必须是equal、weighted、upper_biased或lower_biased"
        )
    if not 0.0 < lower_weight < 1.0:
        raise ValueError("interval_fraction必须在0和1之间")
    return (
        np.asarray(upper, dtype=np.float64)
        + lower_weight * (
            np.asarray(lower, dtype=np.float64) - np.asarray(upper, dtype=np.float64)
        ),
        lower_weight,
    )


def _interval_window(
    centers,
    lower_centers,
    shape,
    inline_indices,
    crossline_indices,
    window,
    margin=1.0,
    mode="global_min",
):
    mode = str(mode).lower()
    if mode in {"local", "per_position", "adaptive"}:
        raise ValueError(
            "当前MAMCL要求所有样本窗口长度一致，不能使用per_position/local取窗"
        )
    if mode not in {"global", "global_min", "fixed", "fixed_skip"}:
        raise ValueError("interval_window_mode必须是global_min或fixed")
    if window is not None:
        window = int(window)
        if window < 1:
            raise ValueError("window必须为正整数")
    interval_clearance = lower_centers - centers
    boundary_clearance = np.minimum(
        centers,
        float(shape[2] - 1) - centers,
    )
    safe_clearance = np.minimum(
        interval_clearance - float(margin),
        boundary_clearance,
    )
    window_grid = np.full(centers.shape, -1, dtype=np.int64)
    finite = np.isfinite(centers) & np.isfinite(lower_centers)
    finite &= lower_centers > centers
    finite &= np.isfinite(safe_clearance)
    window_grid[finite] = np.floor(safe_clearance[finite] + 1e-6).astype(np.int64)
    spatial_valid = (
        (inline_indices[:, None] >= 0)
        & (crossline_indices[None, :] >= 0)
    )
    candidate = finite & spatial_valid & (window_grid >= 1)
    if not candidate.any():
        if mode in {"fixed", "fixed_skip"} and window is not None:
            # 仍然生成共同裁剪区内的样本；安全性由interval_valid/unsafe_mask记录，
            # 训练和K-Means是否使用这些样本由TRAIN_SAFE_ONLY/KMEANS_SAFE_ONLY控制。
            selected = int(window)
            valid = np.zeros(centers.shape, dtype=bool)
            return selected, window_grid, valid
        raise ValueError("上下层位之间没有可用的安全窗口")
    if mode in {"fixed", "fixed_skip"}:
        if window is None:
            raise ValueError("fixed取窗必须提供window")
        selected = window
    else:
        selected = int(window_grid[candidate].min())
        if window is not None:
            selected = min(selected, window)
    if selected < 1:
        raise ValueError("上下层位之间的安全窗口小于一个采样点")
    valid = candidate & (window_grid >= selected)
    return int(selected), window_grid, valid


def prepare_zgy_samples(
    input_paths,
    horizon,
    window,
    stride,
    sampling,
    normalize,
    horizon_unit,
    horizon_shift,
    skip_invalid_horizon,
    axes=None,
    normalization_stats=None,
    inline_slice=None,
    crossline_slice=None,
    interpolate_horizon=False,
    interpolation_method="linear_nearest",
    horizon_coordinates="inline_crossline",
    horizon_world_x=None,
    horizon_world_y=None,
    max_fill_distance_factor=2.0,
    low_confidence_distance_factor=1.0,
    lower_horizon=None,
    lower_horizon_world_x=None,
    lower_horizon_world_y=None,
    lower_axes=None,
    crop_to_common=False,
    fill_horizon_nans=False,
    interval_center_mode="equal",
    interval_fraction=0.5,
    interval_margin=1.0,
    interval_window_mode="global_min",
    interval_coverage=0.90,
    interval_anchor_offset=0.0,
    interval_padding_mode="edge",
    return_masks=False,
):
    if not input_paths or not all(Path(p).suffix.lower() == ".zgy" for p in input_paths):
        raise ValueError("prepare_zgy_samples只接受.zgy属性体")
    horizon = np.asarray(horizon, dtype=np.float64)
    if horizon.ndim != 2:
        raise ValueError("层位必须是二维数组")
    alignment_metadata = None
    if lower_horizon is not None:
        lower_horizon = np.asarray(lower_horizon, dtype=np.float64)
        if crop_to_common:
            target_world_x = None
            target_world_y = None
            with _reader(input_paths[0]) as reader:
                zgy_shape, zgy_origin, zgy_step, _, _, _ = _metadata(reader)
                if str(horizon_coordinates).lower() == "world":
                    target_world_x, target_world_y = _world_grid(reader, zgy_shape)
            horizon, lower_horizon, axes, alignment_metadata = _crop_and_fill_interval_surfaces(
                horizon,
                lower_horizon,
                axes,
                lower_axes,
                zgy_shape,
                zgy_origin,
                zgy_step,
                bool(fill_horizon_nans),
                interpolation_method,
                max_fill_distance_factor,
                low_confidence_distance_factor,
                upper_world_x=horizon_world_x,
                upper_world_y=horizon_world_y,
                lower_world_x=lower_horizon_world_x,
                lower_world_y=lower_horizon_world_y,
                target_world_x=target_world_x,
                target_world_y=target_world_y,
            )
            lower_horizon_world_x = None
            lower_horizon_world_y = None
            horizon_world_x = None
            horizon_world_y = None
            horizon_coordinates = "inline_crossline"
            interpolate_horizon = False
        elif lower_horizon.shape != horizon.shape:
            raise ValueError("上下层位shape必须一致；开启crop_to_common可处理不同源网格")
        if not 0.0 < float(interval_fraction) < 1.0:
            raise ValueError("interval_fraction必须在0和1之间")
        if float(interval_margin) < 0:
            raise ValueError("interval_margin不能为负数")
        if not 0.0 < float(interval_coverage) <= 1.0:
            raise ValueError("interval_coverage必须在0和1之间")
        if float(interval_anchor_offset) < 0:
            raise ValueError("interval_anchor_offset不能为负数")
        if str(interval_window_mode).lower() in {
            "upper_anchor_coverage", "upper_anchor_down", "downward_coverage",
        }:
            return _prepare_zgy_samples_one_sided(
                input_paths=input_paths,
                horizon=horizon,
                window=window,
                stride=stride,
                sampling=sampling,
                normalize=normalize,
                horizon_unit=horizon_unit,
                horizon_shift=horizon_shift,
                skip_invalid_horizon=skip_invalid_horizon,
                axes=axes,
                normalization_stats=normalization_stats,
                inline_slice=inline_slice,
                crossline_slice=crossline_slice,
                interpolate_horizon=interpolate_horizon,
                interpolation_method=interpolation_method,
                horizon_coordinates=horizon_coordinates,
                horizon_world_x=horizon_world_x,
                horizon_world_y=horizon_world_y,
                max_fill_distance_factor=max_fill_distance_factor,
                low_confidence_distance_factor=low_confidence_distance_factor,
                lower_horizon=lower_horizon,
                lower_horizon_world_x=lower_horizon_world_x,
                lower_horizon_world_y=lower_horizon_world_y,
                lower_axes=lower_axes,
                alignment_metadata=alignment_metadata,
                interval_margin=interval_margin,
                interval_coverage=interval_coverage,
                interval_anchor_offset=interval_anchor_offset,
                interval_padding_mode=interval_padding_mode,
                return_masks=return_masks,
            )
    horizon_coordinates = str(horizon_coordinates).lower()
    if horizon_coordinates not in {"inline_crossline", "world"}:
        raise ValueError("horizon_coordinates必须是inline_crossline或world")
    if horizon_coordinates == "world":
        if horizon_world_x is None or horizon_world_y is None:
            raise ValueError("使用world层位坐标时必须提供horizon_world_x和horizon_world_y")
        if not interpolate_horizon:
            raise ValueError("world层位坐标必须开启interpolate_horizon")
    with _reader(input_paths[0]) as reader:
        shape, zgy_origin, zgy_step, zstart, zinc, zunit = _metadata(reader)
        target_world_x = None
        target_world_y = None
        if str(horizon_coordinates).lower() == "world":
            target_world_x, target_world_y = _world_grid(reader, shape)
    if axes is not None:
        if len(axes) != 4 or any(x is None for x in axes):
            raise ValueError("zgy_axes必须为(inline_origin,crossline_origin,inline_step,crossline_step)")
        horizon_origin = (float(axes[0]), float(axes[1]))
        horizon_step = (float(axes[2]), float(axes[3]))
    else:
        horizon_origin = zgy_origin
        horizon_step = zgy_step
    if interpolate_horizon:
        interpolation_started = time.perf_counter()
        horizon = _interpolate_horizon_to_zgy(
            horizon,
            horizon_origin,
            horizon_step,
            zgy_origin,
            zgy_step,
            shape,
            method=interpolation_method,
            source_world_x=horizon_world_x if str(horizon_coordinates).lower() == "world" else None,
            source_world_y=horizon_world_y if str(horizon_coordinates).lower() == "world" else None,
            target_world_x=target_world_x,
            target_world_y=target_world_y,
            max_fill_distance_factor=max_fill_distance_factor,
            low_confidence_distance_factor=low_confidence_distance_factor,
        )
        if lower_horizon is not None:
            lower_horizon = _interpolate_horizon_to_zgy(
                lower_horizon,
                horizon_origin,
                horizon_step,
                zgy_origin,
                zgy_step,
                shape,
                method=interpolation_method,
                source_world_x=lower_horizon_world_x if str(horizon_coordinates).lower() == "world" else None,
                source_world_y=lower_horizon_world_y if str(horizon_coordinates).lower() == "world" else None,
                target_world_x=target_world_x,
                target_world_y=target_world_y,
                max_fill_distance_factor=max_fill_distance_factor,
                low_confidence_distance_factor=low_confidence_distance_factor,
            )
        horizon_origin = zgy_origin
        horizon_step = zgy_step
        print(
            "horizon interpolation:",
            "method=" + str(interpolation_method),
            "target_shape=" + str(tuple(shape[:2])),
            "valid=" + str(int(np.isfinite(horizon).sum())),
            "seconds=" + f"{time.perf_counter() - interpolation_started:.3f}",
        )
    inline_values = horizon_origin[0] + np.arange(horizon.shape[0], dtype=np.float64) * horizon_step[0]
    crossline_values = horizon_origin[1] + np.arange(horizon.shape[1], dtype=np.float64) * horizon_step[1]
    inline_indices = _axis_index(
        inline_values, zgy_origin[0], zgy_step[0], shape[0], "inline",
        allow_outside=skip_invalid_horizon,
    )
    crossline_indices = _axis_index(
        crossline_values, zgy_origin[1], zgy_step[1], shape[1], "crossline",
        allow_outside=skip_invalid_horizon,
    )
    inline_step, crossline_step = (int(stride), int(stride)) if isinstance(stride, (int, np.integer)) else (int(stride[0]), int(stride[1]))
    if inline_step <= 0 or crossline_step <= 0:
        raise ValueError("stride必须为正")
    inline_start, inline_stop = inline_slice or (0, horizon.shape[0])
    crossline_start, crossline_stop = crossline_slice or (0, horizon.shape[1])
    effective_shift = float(horizon_shift)
    if lower_horizon is not None:
        if abs(effective_shift) > 1e-12:
            print("interval mode: horizon_shift ignored")
        effective_shift = 0.0
    centers = _vertical_indices(horizon, horizon_unit, zstart, zinc, zunit) + effective_shift
    interval_window = None
    interval_window_grid = None
    interval_valid = None
    if lower_horizon is not None:
        lower_centers = _vertical_indices(
            lower_horizon, horizon_unit, zstart, zinc, zunit,
        ) + effective_shift
        interval_centers, lower_weight = _interval_center(
            centers,
            lower_centers,
            mode=interval_center_mode,
            fraction=interval_fraction,
        )
        interval_window, interval_window_grid, interval_valid = _interval_window(
            interval_centers,
            lower_centers,
            shape,
            inline_indices,
            crossline_indices,
            window,
            margin=interval_margin,
            mode=interval_window_mode,
        )
        interval_valid &= np.arange(horizon.shape[0])[:, None] >= inline_start
        interval_valid &= np.arange(horizon.shape[0])[:, None] < inline_stop
        interval_valid &= np.arange(horizon.shape[1])[None, :] >= crossline_start
        interval_valid &= np.arange(horizon.shape[1])[None, :] < crossline_stop
        interval_valid &= (
            (np.arange(horizon.shape[0])[:, None] - inline_start) % inline_step == 0
        )
        interval_valid &= (
            (np.arange(horizon.shape[1])[None, :] - crossline_start) % crossline_step == 0
        )
        if not interval_valid.any():
            print("warning: 当前共同区域没有满足固定窗口安全约束的位置；仍保留全部可读位置，unsafe_mask会标记这些样本")
        centers = interval_centers
        window_max_text = "None" if window is None else str(int(window))
        print(
            "interval mode:",
            "center_mode=" + str(interval_center_mode),
            "lower_weight=" + str(float(lower_weight)),
            "window_mode=" + str(interval_window_mode),
            "fraction=" + str(float(interval_fraction)),
            "margin=" + str(float(interval_margin)),
            "window_max=" + window_max_text,
            "window=" + str(int(interval_window)),
            "valid=" + str(int(interval_valid.sum())),
        )
        window = interval_window
    horizon_positions = []
    zgy_positions = []
    for inline in range(inline_start, inline_stop, inline_step):
        for crossline in range(crossline_start, crossline_stop, crossline_step):
            if inline_indices[inline] < 0 or crossline_indices[crossline] < 0:
                if skip_invalid_horizon:
                    continue
                raise ValueError(f"层位坐标超出ZGY范围：position=({inline},{crossline})")
            center = centers[inline, crossline]
            if not np.isfinite(center):
                if skip_invalid_horizon:
                    continue
                raise ValueError("层位包含NaN或Inf")
            if interval_valid is not None and not interval_valid[inline, crossline]:
                # 层间共同网格内强制取窗；该位置仍会写入样本和聚类图，
                # 只通过unsafe_mask从安全训练/K-Means拟合集中排除。
                pass
            if center - window < 0 or center + window >= shape[2]:
                if skip_invalid_horizon:
                    continue
                raise ValueError(f"层位窗口越界：position=({inline},{crossline})")
            horizon_positions.append((inline, crossline))
            zgy_positions.append((int(inline_indices[inline]), int(crossline_indices[crossline])))
    if not horizon_positions:
        raise ValueError("没有可用的ZGY层位窗口")
    horizon_positions = np.asarray(horizon_positions, dtype=np.int64)
    zgy_positions = np.asarray(zgy_positions, dtype=np.int64)
    print(
        "prediction positions:",
        int(horizon_positions.shape[0]),
        "stride=" + str((inline_step, crossline_step)),
        "window=" + str(int(window)),
    )
    raw = np.empty((horizon_positions.shape[0], len(input_paths), 1, 2 * int(window) + 1), dtype=np.float32)
    block_groups = {}
    for row, (hi, hj) in enumerate(horizon_positions):
        zi, zj = zgy_positions[row]
        key = (int(zi) // 8, int(zj) // 32, int(centers[hi, hj]) // 64)
        block_groups.setdefault(key, []).append(row)
    block_items = tuple(block_groups.values())
    print("ZGY read blocks per attribute:", len(block_items))
    for attribute, path in enumerate(input_paths):
        attribute_started = time.perf_counter()
        print(f"attribute {attribute + 1}/{len(input_paths)} start: {Path(path).name}")
        with _reader(path) as reader:
            current = _metadata(reader)
            if current[0] != shape or current[1] != zgy_origin or current[2] != zgy_step:
                raise ValueError(f"ZGY几何不一致：{path}")
            if not np.isclose(current[3], zstart) or not np.isclose(current[4], zinc) or current[5] != zunit:
                raise ValueError(f"ZGY垂向采样轴不一致：{path}")
            progress_step = max(1, len(block_items) // 10)
            for block_index, rows in enumerate(block_items, 1):
                group_positions = zgy_positions[rows]
                i0, j0 = group_positions.min(axis=0)
                i1, j1 = group_positions.max(axis=0) + 1
                group_horizon = horizon_positions[rows]
                group_centers = centers[group_horizon[:, 0], group_horizon[:, 1]]
                z0 = int(np.floor(group_centers.min() - window))
                z1 = int(np.ceil(group_centers.max() + window)) + 1
                block = reader.read_subvolume(int(i0), int(i1), int(j0), int(j1), z0, z1)
                for row in rows:
                    inline, crossline = horizon_positions[row]
                    zi, zj = zgy_positions[row]
                    sample = _window(block[zi-i0, zj-j0], centers[inline, crossline]-z0, window, sampling)
                    if sample is None or not np.isfinite(sample).all():
                        raise ValueError(f"ZGY窗口数值无效：{path} position=({inline},{crossline})")
                    raw[row, attribute, 0] = sample
                if block_index == len(block_items) or block_index % progress_step == 0:
                    print(
                        f"attribute {attribute + 1}/{len(input_paths)} blocks "
                        f"{block_index}/{len(block_items)} "
                        f"seconds={time.perf_counter() - attribute_started:.3f}"
                    )
    from normalize import fit_normalization, apply_normalization
    stats = normalization_stats or fit_normalization(raw, normalize)
    if alignment_metadata is not None:
        stats = dict(stats)
        stats["_horizon_alignment"] = alignment_metadata
    if interval_window is not None:
        stats = dict(stats)
        stats["_selected_window"] = int(interval_window)
    normalized = apply_normalization(raw, stats)
    if return_masks:
        sample_count = int(horizon_positions.shape[0])
        if interval_valid is None:
            interval_safe_mask = np.ones(sample_count, dtype=bool)
            interval_unsafe_mask = np.zeros(sample_count, dtype=bool)
            direction_unsafe_mask = np.zeros(sample_count, dtype=bool)
            lower_invalid_mask = np.zeros(sample_count, dtype=bool)
        else:
            interval_safe_mask = np.zeros(sample_count, dtype=bool)
            direction_unsafe_mask = np.zeros(sample_count, dtype=bool)
            lower_invalid_mask = np.zeros(sample_count, dtype=bool)
            for row, (hi, hj) in enumerate(horizon_positions):
                interval_safe_mask[row] = bool(interval_valid[hi, hj])
                lower_value = lower_centers[hi, hj]
                upper_value = centers[hi, hj]
                lower_invalid_mask[row] = not np.isfinite(lower_value)
                direction_unsafe_mask[row] = (
                    np.isfinite(lower_value) and np.isfinite(upper_value)
                    and lower_value <= upper_value
                )
            interval_unsafe_mask = ~interval_safe_mask
        array_oob_mask = np.zeros(sample_count, dtype=bool)
        for row, (hi, hj) in enumerate(horizon_positions):
            center_value = centers[hi, hj]
            array_oob_mask[row] = (
                not np.isfinite(center_value)
                or center_value - int(window) < 0
                or center_value + int(window) >= shape[2]
            )
        padding_mask = np.zeros(sample_count, dtype=bool)
        invalid_attribute_mask = ~np.isfinite(raw).all(axis=(1, 2, 3))
        unsafe_mask = (
            interval_unsafe_mask
            | direction_unsafe_mask
            | lower_invalid_mask
            | array_oob_mask
            | padding_mask
            | invalid_attribute_mask
        )
        masks = {
            "interval_safe_mask": interval_safe_mask,
            "interval_unsafe_mask": interval_unsafe_mask,
            "direction_unsafe_mask": direction_unsafe_mask,
            "lower_invalid_mask": lower_invalid_mask,
            "array_oob_mask": array_oob_mask,
            "padding_mask": padding_mask,
            "invalid_attribute_mask": invalid_attribute_mask,
            "unsafe_mask": unsafe_mask,
            "train_mask": ~unsafe_mask,
        }
        stats = dict(stats)
        stats["_unsafe_count"] = int(unsafe_mask.sum())
        stats["_interval_unsafe_count"] = int(interval_unsafe_mask.sum())
        stats["_array_oob_count"] = int(array_oob_mask.sum())
        stats["invalid_attribute_count"] = int(invalid_attribute_mask.sum())
        return normalized, zgy_positions, shape, stats, masks
    return normalized, zgy_positions, shape, stats


def _prepare_zgy_samples_one_sided(
    input_paths,
    horizon,
    window,
    stride,
    sampling,
    normalize,
    horizon_unit,
    horizon_shift,
    skip_invalid_horizon,
    axes,
    normalization_stats,
    inline_slice,
    crossline_slice,
    interpolate_horizon,
    interpolation_method,
    horizon_coordinates,
    horizon_world_x,
    horizon_world_y,
    max_fill_distance_factor,
    low_confidence_distance_factor,
    lower_horizon,
    lower_horizon_world_x,
    lower_horizon_world_y,
    lower_axes,
    alignment_metadata,
    interval_margin,
    interval_coverage,
    interval_anchor_offset,
    interval_padding_mode,
    return_masks,
):
    if not input_paths or not all(Path(p).suffix.lower() == ".zgy" for p in input_paths):
        raise ValueError("单向层间模式只接受.zgy属性体")
    window = int(window)
    if window < 1:
        raise ValueError("单向窗口跨度window必须为正整数")
    interval_margin = float(interval_margin)
    interval_coverage = float(interval_coverage)
    interval_anchor_offset = float(interval_anchor_offset)
    if interval_margin < 0 or interval_anchor_offset < 0:
        raise ValueError("interval_margin和interval_anchor_offset不能为负数")
    if not 0.0 < interval_coverage <= 1.0:
        raise ValueError("interval_coverage必须在0和1之间")
    upper = np.asarray(horizon, dtype=np.float64)
    lower = np.asarray(lower_horizon, dtype=np.float64)
    if upper.ndim != 2 or lower.ndim != 2 or upper.shape != lower.shape:
        raise ValueError("上下层位必须是相同shape的二维数组")
    horizon_coordinates = str(horizon_coordinates).lower()
    if horizon_coordinates not in {"inline_crossline", "world"}:
        raise ValueError("horizon_coordinates必须是inline_crossline或world")
    if horizon_coordinates == "world" and (
        horizon_world_x is None or horizon_world_y is None
    ):
        raise ValueError("使用world层位坐标时必须提供horizon_world_x和horizon_world_y")
    if horizon_coordinates == "world" and not interpolate_horizon:
        raise ValueError("world层位坐标必须开启interpolate_horizon")
    with _reader(input_paths[0]) as reader:
        shape, zgy_origin, zgy_step, zstart, zinc, zunit = _metadata(reader)
        target_world_x = None
        target_world_y = None
        if horizon_coordinates == "world":
            target_world_x, target_world_y = _world_grid(reader, shape)
    if axes is not None:
        if len(axes) != 4 or any(x is None for x in axes):
            raise ValueError("zgy_axes必须为(inline_origin,crossline_origin,inline_step,crossline_step)")
        horizon_origin = (float(axes[0]), float(axes[1]))
        horizon_step = (float(axes[2]), float(axes[3]))
    else:
        horizon_origin = zgy_origin
        horizon_step = zgy_step
    if interpolate_horizon:
        started = time.perf_counter()
        upper = _interpolate_horizon_to_zgy(
            upper,
            horizon_origin,
            horizon_step,
            zgy_origin,
            zgy_step,
            shape,
            method=interpolation_method,
            source_world_x=horizon_world_x if horizon_coordinates == "world" else None,
            source_world_y=horizon_world_y if horizon_coordinates == "world" else None,
            target_world_x=target_world_x,
            target_world_y=target_world_y,
            max_fill_distance_factor=max_fill_distance_factor,
            low_confidence_distance_factor=low_confidence_distance_factor,
        )
        lower = _interpolate_horizon_to_zgy(
            lower,
            horizon_origin,
            horizon_step,
            zgy_origin,
            zgy_step,
            shape,
            method=interpolation_method,
            source_world_x=lower_horizon_world_x if horizon_coordinates == "world" else None,
            source_world_y=lower_horizon_world_y if horizon_coordinates == "world" else None,
            target_world_x=target_world_x,
            target_world_y=target_world_y,
            max_fill_distance_factor=max_fill_distance_factor,
            low_confidence_distance_factor=low_confidence_distance_factor,
        )
        horizon_origin = zgy_origin
        horizon_step = zgy_step
        print(
            "one-sided horizon interpolation:",
            "method=" + str(interpolation_method),
            "target_shape=" + str(tuple(shape[:2])),
            "upper_valid=" + str(int(np.isfinite(upper).sum())),
            "lower_valid=" + str(int(np.isfinite(lower).sum())),
            "seconds=" + f"{time.perf_counter() - started:.3f}",
        )
    inline_values = horizon_origin[0] + np.arange(upper.shape[0], dtype=np.float64) * horizon_step[0]
    crossline_values = horizon_origin[1] + np.arange(upper.shape[1], dtype=np.float64) * horizon_step[1]
    inline_indices = _axis_index(
        inline_values, zgy_origin[0], zgy_step[0], shape[0], "inline", allow_outside=True,
    )
    crossline_indices = _axis_index(
        crossline_values, zgy_origin[1], zgy_step[1], shape[1], "crossline", allow_outside=True,
    )
    if isinstance(stride, (int, np.integer)):
        inline_step = crossline_step = int(stride)
    else:
        inline_step, crossline_step = int(stride[0]), int(stride[1])
    if inline_step <= 0 or crossline_step <= 0:
        raise ValueError("stride必须为正")
    inline_start, inline_stop = inline_slice or (0, upper.shape[0])
    crossline_start, crossline_stop = crossline_slice or (0, upper.shape[1])
    if inline_start < 0 or crossline_start < 0 or inline_stop > upper.shape[0] or crossline_stop > upper.shape[1]:
        raise ValueError("inline/crossline范围超出层位shape")
    effective_shift = float(horizon_shift)
    if abs(effective_shift) > 1e-12:
        print("one-sided interval mode: horizon_shift ignored")
    effective_shift = 0.0
    upper_idx = _vertical_indices(upper, horizon_unit, zstart, zinc, zunit) + effective_shift
    lower_idx = _vertical_indices(lower, horizon_unit, zstart, zinc, zunit) + effective_shift
    spatial_valid = (
        (inline_indices[:, None] >= 0)
        & (crossline_indices[None, :] >= 0)
        & (inline_indices[:, None] < shape[0])
        & (crossline_indices[None, :] < shape[1])
    )
    upper_valid = np.isfinite(upper_idx) & spatial_valid
    matched = upper_valid & np.isfinite(lower_idx)
    if not np.any(upper_valid):
        raise ValueError("上层位在ZGY空间网格内没有可用位置")
    denominator = int(matched.sum())
    if denominator <= 0:
        raise ValueError("上下层位没有可用于90%覆盖率计算的匹配位置")
    anchors = upper_idx + interval_anchor_offset
    coverage_curve = []
    selected = None
    for span in range(window, -1, -1):
        end_grid = anchors + float(span)
        safe_grid = matched & (lower_idx > upper_idx)
        safe_grid &= end_grid <= (lower_idx - interval_margin - 1.0 + 1e-6)
        safe_count = int(safe_grid[matched].sum())
        coverage = float(safe_count / denominator)
        coverage_curve.append(
            {
                "span": int(span),
                "points": int(span + 1),
                "safe_count": safe_count,
                "denominator": denominator,
                "coverage": coverage,
            }
        )
        if selected is None and span >= 1 and coverage >= interval_coverage:
            selected = int(span)
    if selected is None:
        best = max(coverage_curve, key=lambda item: (item["coverage"], item["span"]))
        selected = int(best["span"])
        print(
            "warning: no span reached target coverage; using best coverage:",
            "target=" + str(interval_coverage),
            "selected=" + str(selected),
            "coverage=" + str(best["coverage"]),
        )
        coverage_met = False
    else:
        coverage_met = True
    selected_end = anchors + float(selected)
    interval_safe_grid = matched & (lower_idx > upper_idx)
    interval_safe_grid &= selected_end <= (lower_idx - interval_margin - 1.0 + 1e-6)
    direction_unsafe_grid = matched & (lower_idx <= upper_idx)
    lower_invalid_grid = upper_valid & ~np.isfinite(lower_idx)
    array_oob_grid = upper_valid & (
        (anchors < 0.0) | (selected_end > float(shape[2] - 1))
    )
    requested = []
    for inline in range(int(inline_start), int(inline_stop), inline_step):
        for crossline in range(int(crossline_start), int(crossline_stop), crossline_step):
            if not upper_valid[inline, crossline]:
                if skip_invalid_horizon:
                    continue
                raise ValueError(f"上层位无效或空间越界：position=({inline},{crossline})")
            requested.append((inline, crossline))
    if not requested:
        raise ValueError("没有可用的上层位空间位置")
    horizon_positions = np.asarray(requested, dtype=np.int64)
    zgy_positions = np.asarray(
        [(int(inline_indices[i]), int(crossline_indices[j])) for i, j in requested],
        dtype=np.int64,
    )
    sample_count = int(horizon_positions.shape[0])
    sample_length = int(selected + 1)
    raw = np.empty((sample_count, len(input_paths), 1, sample_length), dtype=np.float32)
    interval_safe_mask = np.zeros(sample_count, dtype=bool)
    interval_unsafe_mask = np.zeros(sample_count, dtype=bool)
    direction_unsafe_mask = np.zeros(sample_count, dtype=bool)
    lower_invalid_mask = np.zeros(sample_count, dtype=bool)
    array_oob_mask = np.zeros(sample_count, dtype=bool)
    padding_mask = np.zeros(sample_count, dtype=bool)
    invalid_attribute_mask = np.zeros(sample_count, dtype=bool)
    for row, (inline, crossline) in enumerate(requested):
        interval_safe_mask[row] = bool(interval_safe_grid[inline, crossline])
        interval_unsafe_mask[row] = not interval_safe_mask[row]
        direction_unsafe_mask[row] = bool(direction_unsafe_grid[inline, crossline])
        lower_invalid_mask[row] = bool(lower_invalid_grid[inline, crossline])
        array_oob_mask[row] = bool(array_oob_grid[inline, crossline])
    block_groups = {}
    for row, (inline, crossline) in enumerate(requested):
        zi, zj = zgy_positions[row]
        key = (
            int(zi) // 8,
            int(zj) // 32,
            int(np.floor(anchors[inline, crossline])) // 64,
        )
        block_groups.setdefault(key, []).append(row)
    block_items = tuple(block_groups.values())
    print(
        "one-sided interval selection:",
        "span=" + str(selected),
        "points=" + str(sample_length),
        "target_coverage=" + str(interval_coverage),
        "coverage_met=" + str(coverage_met),
        "coverage=" + str(next(item["coverage"] for item in coverage_curve if item["span"] == selected)),
        "matched=" + str(denominator),
        "positions=" + str(sample_count),
    )
    print("one-sided ZGY read blocks per attribute:", len(block_items))
    for attribute, path in enumerate(input_paths):
        started = time.perf_counter()
        print(f"attribute {attribute + 1}/{len(input_paths)} start: {Path(path).name}")
        with _reader(path) as reader:
            current = _metadata(reader)
            if current[0] != shape or current[1] != zgy_origin or current[2] != zgy_step:
                raise ValueError(f"ZGY几何不一致：{path}")
            if not np.isclose(current[3], zstart) or not np.isclose(current[4], zinc) or current[5] != zunit:
                raise ValueError(f"ZGY垂向采样轴不一致：{path}")
            progress_step = max(1, len(block_items) // 10)
            for block_index, rows in enumerate(block_items, 1):
                group_positions = zgy_positions[rows]
                i0, j0 = group_positions.min(axis=0)
                i1, j1 = group_positions.max(axis=0) + 1
                group_horizon = horizon_positions[rows]
                group_anchors = anchors[group_horizon[:, 0], group_horizon[:, 1]]
                z0 = int(np.floor(np.nanmin(group_anchors)))
                z1 = int(np.ceil(np.nanmax(group_anchors) + selected)) + 1
                z0 = max(0, z0)
                z1 = min(shape[2], z1)
                if z1 <= z0:
                    z0 = min(max(0, int(np.floor(np.nanmin(group_anchors)))), shape[2] - 1)
                    z1 = z0 + 1
                block = reader.read_subvolume(int(i0), int(i1), int(j0), int(j1), z0, z1)
                for row in rows:
                    inline, crossline = horizon_positions[row]
                    zi, zj = zgy_positions[row]
                    sample, padded = _one_sided_window(
                        block[zi - i0, zj - j0],
                        anchors[inline, crossline],
                        selected,
                        z0,
                        sampling=sampling,
                        padding_mode=interval_padding_mode,
                    )
                    padding_mask[row] |= bool(padded)
                    if not np.isfinite(sample).all():
                        invalid_attribute_mask[row] = True
                        sample = np.nan_to_num(sample, nan=0.0, posinf=0.0, neginf=0.0)
                    raw[row, attribute, 0] = sample
                if block_index == len(block_items) or block_index % progress_step == 0:
                    print(
                        f"attribute {attribute + 1}/{len(input_paths)} blocks "
                        f"{block_index}/{len(block_items)} "
                        f"seconds={time.perf_counter() - started:.3f}"
                    )
    unsafe_mask = (
        interval_unsafe_mask
        | direction_unsafe_mask
        | lower_invalid_mask
        | array_oob_mask
        | padding_mask
        | invalid_attribute_mask
    )
    train_mask = ~unsafe_mask
    from normalize import fit_normalization, apply_normalization
    if normalization_stats is None:
        if not train_mask.any():
            raise ValueError("没有可用于训练归一化的安全样本")
        stats = fit_normalization(raw[train_mask], normalize)
    else:
        stats = dict(normalization_stats)
    if alignment_metadata is not None:
        stats["_horizon_alignment"] = alignment_metadata
    stats["_selected_window"] = int(selected)
    stats["_selected_window_points"] = int(sample_length)
    stats["_interval_coverage"] = float(next(item["coverage"] for item in coverage_curve if item["span"] == selected))
    stats["_interval_target_coverage"] = float(interval_coverage)
    stats["_interval_coverage_met"] = bool(coverage_met)
    stats["_interval_coverage_curve"] = coverage_curve
    stats["_interval_denominator"] = int(denominator)
    stats["_sample_count"] = int(sample_count)
    stats["_unsafe_count"] = int(unsafe_mask.sum())
    stats["_padding_count"] = int(padding_mask.sum())
    stats["_array_oob_count"] = int(array_oob_mask.sum())
    stats["_interval_unsafe_count"] = int(interval_unsafe_mask.sum())
    stats["direction_unsafe_count"] = int(direction_unsafe_mask.sum())
    stats["lower_invalid_count"] = int(lower_invalid_mask.sum())
    stats["invalid_attribute_count"] = int(invalid_attribute_mask.sum())
    normalized = apply_normalization(raw, stats)
    masks = {
        "interval_safe_mask": interval_safe_mask,
        "interval_unsafe_mask": interval_unsafe_mask,
        "direction_unsafe_mask": direction_unsafe_mask,
        "lower_invalid_mask": lower_invalid_mask,
        "array_oob_mask": array_oob_mask,
        "padding_mask": padding_mask,
        "invalid_attribute_mask": invalid_attribute_mask,
        "unsafe_mask": unsafe_mask,
        "train_mask": train_mask,
    }
    if return_masks:
        return normalized, zgy_positions, shape, stats, masks
    return normalized, zgy_positions, shape, stats
